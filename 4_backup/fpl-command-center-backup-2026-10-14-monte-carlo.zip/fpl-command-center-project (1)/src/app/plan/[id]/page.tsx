import { PlanDashboard } from "@/components/plan/PlanDashboard";

export const metadata = { title: "Transfer Plan" };

export default async function PlanPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return <PlanDashboard teamId={id} />;
}
