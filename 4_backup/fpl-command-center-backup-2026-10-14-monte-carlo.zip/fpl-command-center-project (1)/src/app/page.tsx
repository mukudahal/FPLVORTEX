"use client";

import { useEffect, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Card, Pill } from "@/components/ui";
import { Logo } from "@/components/Logo";
import { useJson } from "@/lib/useJson";
import { formatRank, getSavedTeamId, saveTeamId } from "@/lib/helpers";
import type { RecentManager, SlimBootstrap } from "@/lib/types";

export default function HomePage() {
  const router = useRouter();
  const [teamId, setTeamId] = useState("");
  const [savedId, setSavedId] = useState<string | null>(null);
  const [inputError, setInputError] = useState<string | null>(null);
  const { data: recent } = useJson<RecentManager[]>("/api/recent");
  const { data: bootstrap } = useJson<SlimBootstrap>("/api/fpl/bootstrap");

  useEffect(() => {
    setSavedId(getSavedTeamId());
  }, []);

  function submit(e: FormEvent) {
    e.preventDefault();
    const cleaned = teamId.trim().replace(/\D/g, "");
    if (!cleaned || Number(cleaned) < 1) {
      setInputError("Enter your numeric FPL Team ID, e.g. 145784");
      return;
    }
    saveTeamId(cleaned);
    router.push(`/team/${cleaned}`);
  }

  const currentEvent = bootstrap?.events.find((ev) => ev.is_current);
  const nextEvent = bootstrap?.events.find((ev) => ev.is_next);

  return (
    <main className="px-4 pt-6">
      <div className="mb-6 flex flex-col items-center text-center">
        <Logo size="hero" className="mb-3" />
        <p className="mx-auto max-w-xs text-sm text-slate-300">
          Live points, MILP transfer &amp; chip optimizer, price watch &amp; 5-GW squad planner — just enter your FPL Team ID.
        </p>
      </div>

      {currentEvent ? (
        <div className="mb-5 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-300">
          <Pill className="border border-[#cda228]/30 bg-[#cda228]/10 text-[#cda228]">
            <span className="live-dot h-1.5 w-1.5 rounded-full bg-[#84d21c]" />
            {currentEvent.name}
            {currentEvent.finished ? " · finished" : " · in play"}
          </Pill>
          {currentEvent.average_entry_score ? (
            <Pill className="bg-white/10">
              Avg {currentEvent.average_entry_score} pts
            </Pill>
          ) : null}
          {nextEvent ? (
            <Pill className="bg-white/10">
              {nextEvent.name} deadline{" "}
              {new Date(nextEvent.deadline_time).toLocaleDateString(undefined, {
                day: "numeric",
                month: "short",
              })}
            </Pill>
          ) : null}
        </div>
      ) : null}

      <Card className="border-[#cda228]/25">
        <form onSubmit={submit} className="flex flex-col gap-3">
          <label
            htmlFor="team-id"
            className="text-xs font-semibold uppercase tracking-wider text-[#cda228]"
          >
            Your FPL Team ID
          </label>
          <div className="flex gap-2">
            <input
              id="team-id"
              inputMode="numeric"
              placeholder="e.g. 145784"
              value={teamId}
              onChange={(e) => {
                setTeamId(e.target.value);
                setInputError(null);
              }}
              className="min-w-0 flex-1 rounded-xl border border-white/15 bg-black/40 px-4 py-3 text-lg font-semibold text-white placeholder:text-slate-500 focus:border-[#cda228] focus:outline-none"
            />
            <button
              type="submit"
              className="rounded-xl bg-gradient-to-r from-[#cda228] to-[#84d21c] px-5 text-sm font-extrabold text-[#000000] shadow-lg shadow-[#cda228]/20 transition hover:brightness-110 active:scale-95"
            >
              Launch
            </button>
          </div>
          {inputError ? (
            <p className="text-xs text-rose-300">{inputError}</p>
          ) : (
            <p className="text-xs text-slate-400">
              Find it on fantasy.premierleague.com → Points page → the number
              in the URL: /entry/<span className="text-slate-200">XXXXXXX</span>
              /event/…
            </p>
          )}
        </form>
      </Card>

      {savedId ? (
        <Link
          href={`/team/${savedId}`}
          className="mt-4 flex items-center justify-between rounded-2xl border border-[#cda228]/35 bg-gradient-to-r from-[#cda228]/15 to-[#84d21c]/15 px-4 py-3 text-sm font-bold text-[#bbe682] transition hover:from-[#cda228]/25 hover:to-[#84d21c]/25"
        >
          <span>Continue to my team (#{savedId})</span>
          <span aria-hidden>→</span>
        </Link>
      ) : null}

      {recent && recent.length > 0 ? (
        <div className="mt-8">
          <h2 className="mb-3 px-1 text-xs font-semibold uppercase tracking-wider text-slate-400">
            Recently viewed teams on FPL Vortex
          </h2>
          <div className="flex flex-col gap-2">
            {recent.map((m) => (
              <Link
                key={m.id}
                href={`/team/${m.id}`}
                onClick={() => saveTeamId(String(m.id))}
                className="flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3 transition hover:border-[#cda228]/40 hover:bg-white/[0.08]"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold">{m.teamName}</p>
                  <p className="truncate text-xs text-slate-400">
                    {m.playerName} · #{m.id}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-[#84d21c]">
                    {m.totalPoints ?? "—"} pts
                  </p>
                  <p className="text-xs text-slate-400">
                    OR {formatRank(m.overallRank)}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      ) : null}
    </main>
  );
}
