import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { BottomNav } from "@/components/BottomNav";
import { SocialFooter, TopHeader } from "@/components/Logo";

const SITE_URL =
  process.env.NEXT_PUBLIC_SITE_URL ??
  (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "http://localhost:3000");

const DESCRIPTION =
  "FPL Vortex — Live Fantasy Premier League analytics, MILP transfer & chip optimizer, live points, fixtures, price watch and squad planner.";

// Every icon/social image below is generated from public/logo.png by scripts/logo-assets.mjs
export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "FPL Vortex",
    template: "%s · FPL Vortex",
  },
  description: DESCRIPTION,
  applicationName: "FPL Vortex",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "FPL Vortex",
  },
  icons: {
    icon: [
      { url: "/favicon-32.png", type: "image/png", sizes: "32x32" },
      { url: "/favicon.png", type: "image/png", sizes: "64x64" },
      { url: "/icons/icon-192.png", type: "image/png", sizes: "192x192" },
      { url: "/icons/icon-512.png", type: "image/png", sizes: "512x512" },
    ],
    shortcut: "/favicon.png",
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  openGraph: {
    title: "FPL Vortex",
    description: DESCRIPTION,
    siteName: "FPL Vortex",
    type: "website",
    url: SITE_URL,
    images: [{ url: "/og-image.png", width: 1200, height: 630, alt: "FPL Vortex" }],
  },
  twitter: {
    card: "summary_large_image",
    site: "@FPLVORTEXM",
    title: "FPL Vortex",
    description: DESCRIPTION,
    images: ["/og-image.png"],
  },
};

export const viewport: Viewport = {
  themeColor: "#000000",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="text-slate-100 antialiased">
        <TopHeader />
        <div className="mx-auto min-h-dvh w-full max-w-lg px-0 pb-28">
          {children}
          <div className="px-3">
            <SocialFooter />
          </div>
        </div>
        <BottomNav />
      </body>
    </html>
  );
}
