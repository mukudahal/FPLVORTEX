import { NextResponse } from "next/server";
import { fplFetch, FplError } from "@/lib/fpl";
import type {
  ChipDef,
  SlimBootstrap,
  SlimElement,
  SlimEvent,
  SlimTeam,
} from "@/lib/types";

export const dynamic = "force-dynamic";

interface RawBootstrap {
  events: (SlimEvent & Record<string, unknown>)[];
  teams: (SlimTeam & Record<string, unknown>)[];
  elements: (SlimElement & Record<string, unknown>)[];
  chips: (ChipDef & Record<string, unknown>)[];
  total_players: number;
}

export async function GET() {
  try {
    const raw = await fplFetch<RawBootstrap>("bootstrap-static/", 300);

    const events: SlimEvent[] = raw.events.map((e) => ({
      id: e.id,
      name: e.name,
      deadline_time: e.deadline_time,
      finished: e.finished,
      is_current: e.is_current,
      is_next: e.is_next,
      average_entry_score: e.average_entry_score,
      highest_score: e.highest_score,
      most_captained: e.most_captained,
      most_selected: e.most_selected,
    }));

    const teams: SlimTeam[] = raw.teams.map((t) => ({
      id: t.id,
      code: t.code,
      name: t.name,
      short_name: t.short_name,
      strength: t.strength,
    }));

    const elements: SlimElement[] = raw.elements.map((p) => ({
      id: p.id,
      code: p.code,
      web_name: p.web_name,
      first_name: p.first_name,
      second_name: p.second_name,
      team: p.team,
      element_type: p.element_type,
      now_cost: p.now_cost,
      cost_change_event: p.cost_change_event,
      total_points: p.total_points,
      event_points: p.event_points,
      form: p.form,
      points_per_game: p.points_per_game,
      selected_by_percent: p.selected_by_percent,
      status: p.status,
      news: p.news,
      news_added: p.news_added ?? null,
      chance_of_playing_next_round: p.chance_of_playing_next_round ?? null,
      chance_of_playing_this_round: p.chance_of_playing_this_round ?? null,
      ep_next: p.ep_next ?? "0.0",
      ep_this: p.ep_this ?? null,
      minutes: p.minutes ?? 0,
      starts: p.starts ?? 0,
      starts_per_90: Number(p.starts_per_90 ?? 0),
      goals_scored: p.goals_scored ?? 0,
      assists: p.assists ?? 0,
      clean_sheets: p.clean_sheets ?? 0,
      clean_sheets_per_90: Number(p.clean_sheets_per_90 ?? 0),
      saves: p.saves ?? 0,
      saves_per_90: Number(p.saves_per_90 ?? 0),
      bonus: p.bonus ?? 0,
      bps: p.bps ?? 0,
      defensive_contribution: Number(p.defensive_contribution ?? 0),
      defensive_contribution_per_90: Number(p.defensive_contribution_per_90 ?? 0),
      yellow_cards: p.yellow_cards ?? 0,
      red_cards: p.red_cards ?? 0,
      own_goals: p.own_goals ?? 0,
      penalties_saved: p.penalties_saved ?? 0,
      penalties_missed: p.penalties_missed ?? 0,
      cost_change_start: p.cost_change_start ?? 0,
      transfers_in_event: p.transfers_in_event ?? 0,
      transfers_out_event: p.transfers_out_event ?? 0,
      expected_goals: String(p.expected_goals ?? "0.0"),
      expected_assists: String(p.expected_assists ?? "0.0"),
      expected_goal_involvements: String(p.expected_goal_involvements ?? "0.0"),
      expected_goals_conceded: String(p.expected_goals_conceded ?? "0.0"),
      expected_goals_per_90: Number(p.expected_goals_per_90 ?? 0),
      expected_assists_per_90: Number(p.expected_assists_per_90 ?? 0),
      expected_goal_involvements_per_90: Number(
        p.expected_goal_involvements_per_90 ?? 0,
      ),
      expected_goals_conceded_per_90: Number(
        p.expected_goals_conceded_per_90 ?? 0,
      ),
      price_change_percent:
        p.price_change_percent != null && !Number.isNaN(Number(p.price_change_percent))
          ? Number(p.price_change_percent)
          : null,
      price_change_hourly_rate:
        p.price_change_hourly_rate != null && !Number.isNaN(Number(p.price_change_hourly_rate))
          ? Number(p.price_change_hourly_rate)
          : null,
      price_change_projections: p.price_change_projections ?? null,
      price_change_locked_until: p.price_change_locked_until ?? null,
    }));

    const currentEvent = events.find((e) => e.is_current)?.id ?? null;
    const nextEvent = events.find((e) => e.is_next)?.id ?? null;

    const chips: ChipDef[] = (raw.chips ?? []).map((c) => ({
      name: c.name,
      number: c.number,
      start_event: c.start_event,
      stop_event: c.stop_event,
    }));

    const body: SlimBootstrap = {
      events,
      teams,
      elements,
      chips,
      total_players: raw.total_players,
      currentEvent,
      nextEvent,
    };
    return NextResponse.json(body);
  } catch (err) {
    const status = err instanceof FplError ? err.status : 502;
    return NextResponse.json(
      { error: "Could not load FPL game data. Try again shortly." },
      { status: status === 404 ? 404 : 502 },
    );
  }
}
