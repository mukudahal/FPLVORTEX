import { NextResponse } from "next/server";
import { fplFetch } from "@/lib/fpl";
import type { Fixture } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const raw = await fplFetch<(Fixture & Record<string, unknown>)[]>(
      "fixtures/",
      300,
    );
    const fixtures: Fixture[] = raw.map((f) => ({
      id: f.id,
      event: f.event,
      team_h: f.team_h,
      team_a: f.team_a,
      team_h_score: f.team_h_score,
      team_a_score: f.team_a_score,
      team_h_difficulty: f.team_h_difficulty,
      team_a_difficulty: f.team_a_difficulty,
      kickoff_time: f.kickoff_time,
      started: f.started,
      finished: f.finished,
      minutes: f.minutes,
    }));
    return NextResponse.json(fixtures);
  } catch {
    return NextResponse.json(
      { error: "Could not load fixtures." },
      { status: 502 },
    );
  }
}
