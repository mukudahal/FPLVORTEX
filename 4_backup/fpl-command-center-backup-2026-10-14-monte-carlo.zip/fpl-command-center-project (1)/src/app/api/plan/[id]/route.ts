import { NextResponse } from "next/server";
import { fplFetch, FplError } from "@/lib/fpl";
import {
  computeFreeTransfers,
  computePlayerXPts,
  computePositionPriors,
  computeSellingPrices,
} from "@/lib/xpts";
import type {
  EntryHistory,
  EntrySummary,
  Fixture,
  PicksResponse,
  SlimElement,
  SlimEvent,
  SlimTeam,
  Transfer,
} from "@/lib/types";
import type { PlanPlayer, PlanResponse } from "@/lib/planTypes";

export const dynamic = "force-dynamic";

const MAX_GWS = 10;

interface RawBootstrap {
  events: SlimEvent[];
  teams: (SlimTeam & Record<string, unknown>)[];
  elements: Record<string, unknown>[];
}

const num = (v: unknown): number => Number(v ?? 0) || 0;
const order = (v: unknown): number | null => {
  const n = Number(v);
  return v != null && Number.isFinite(n) && n > 0 ? n : null;
};
const optNum = (v: unknown): number | null =>
  v != null && !Number.isNaN(Number(v)) ? Number(v) : null;

// Same coercions as /api/fpl/bootstrap so computePlayerXPts sees identical data.
function toSlim(p: Record<string, unknown>): SlimElement {
  return {
    ...(p as unknown as SlimElement),
    news_added: (p.news_added as string | null | undefined) ?? null,
    chance_of_playing_next_round: optNum(p.chance_of_playing_next_round),
    chance_of_playing_this_round: optNum(p.chance_of_playing_this_round),
    ep_next: String(p.ep_next ?? "0.0"),
    ep_this: p.ep_this == null ? null : String(p.ep_this),
    minutes: num(p.minutes),
    starts: num(p.starts),
    starts_per_90: num(p.starts_per_90),
    goals_scored: num(p.goals_scored),
    assists: num(p.assists),
    clean_sheets: num(p.clean_sheets),
    clean_sheets_per_90: num(p.clean_sheets_per_90),
    saves: num(p.saves),
    saves_per_90: num(p.saves_per_90),
    bonus: num(p.bonus),
    bps: num(p.bps),
    defensive_contribution: num(p.defensive_contribution),
    defensive_contribution_per_90: num(p.defensive_contribution_per_90),
    yellow_cards: num(p.yellow_cards),
    red_cards: num(p.red_cards),
    own_goals: num(p.own_goals),
    penalties_saved: num(p.penalties_saved),
    penalties_missed: num(p.penalties_missed),
    cost_change_start: num(p.cost_change_start),
    transfers_in_event: num(p.transfers_in_event),
    transfers_out_event: num(p.transfers_out_event),
    expected_goals: String(p.expected_goals ?? "0.0"),
    expected_assists: String(p.expected_assists ?? "0.0"),
    expected_goal_involvements: String(p.expected_goal_involvements ?? "0.0"),
    expected_goals_conceded: String(p.expected_goals_conceded ?? "0.0"),
    expected_goals_per_90: num(p.expected_goals_per_90),
    expected_assists_per_90: num(p.expected_assists_per_90),
    expected_goal_involvements_per_90: num(p.expected_goal_involvements_per_90),
    expected_goals_conceded_per_90: num(p.expected_goals_conceded_per_90),
    price_change_percent: optNum(p.price_change_percent),
    price_change_hourly_rate: optNum(p.price_change_hourly_rate),
    price_change_projections:
      (p.price_change_projections as SlimElement["price_change_projections"]) ??
      null,
    price_change_locked_until:
      (p.price_change_locked_until as string | null | undefined) ?? null,
  };
}

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const entryId = Number(id);
  if (!Number.isInteger(entryId) || entryId < 1) {
    return NextResponse.json({ error: "Invalid team ID." }, { status: 400 });
  }

  const url = new URL(req.url);
  const gwsParam = Number(url.searchParams.get("gws") ?? MAX_GWS);
  const horizon = Math.max(
    1,
    Math.min(MAX_GWS, Number.isInteger(gwsParam) ? gwsParam : MAX_GWS),
  );

  try {
    const [rawBs, fixtures, entry, history, transfers] = await Promise.all([
      fplFetch<RawBootstrap>("bootstrap-static/", 300),
      fplFetch<Fixture[]>("fixtures/", 300),
      fplFetch<EntrySummary>(`entry/${entryId}/`, 120),
      fplFetch<EntryHistory>(`entry/${entryId}/history/`, 120),
      fplFetch<Transfer[]>(`entry/${entryId}/transfers/`, 300),
    ]);

    const currentGw =
      entry.current_event ?? rawBs.events.find((e) => e.is_current)?.id ?? 1;
    const nextGw =
      rawBs.events.find((e) => e.is_next)?.id ?? Math.min(38, currentGw + 1);

    const picks = await fplFetch<PicksResponse>(
      `entry/${entryId}/event/${currentGw}/picks/`,
      60,
    );

    const elements = rawBs.elements.map(toSlim);
    const elementsMap = new Map<number, SlimElement>();
    elements.forEach((e) => elementsMap.set(e.id, e));
    const teamsMap = new Map<number, SlimTeam>();
    rawBs.teams.forEach((t) => teamsMap.set(t.id, t));

    const gws = Array.from({ length: horizon }, (_, i) => nextGw + i).filter(
      (g) => g <= 38,
    );
    if (gws.length === 0) gws.push(Math.min(38, nextGw));
    const lastGw = gws[gws.length - 1];
    const teamGamesPlayed = Math.max(currentGw, 1);

    const priors = computePositionPriors(elements);

    const rawById = new Map<number, Record<string, unknown>>();
    rawBs.elements.forEach((r) => rawById.set(Number(r.id), r));

    const players: PlanPlayer[] = elements
      .filter((e) => e.element_type <= 4)
      .map((el) => ({
        id: el.id,
        code: el.code,
        name: el.web_name,
        team: el.team,
        type: el.element_type,
        cost: el.now_cost,
        status: el.status,
        news: el.news,
        chance: el.chance_of_playing_next_round,
        owned: Number(el.selected_by_percent) || 0,
        form: Number(el.form) || 0,
        net: el.transfers_in_event - el.transfers_out_event,
        pen: order(rawById.get(el.id)?.penalties_order),
        fk: order(rawById.get(el.id)?.direct_freekicks_order),
        ck: order(rawById.get(el.id)?.corners_and_indirect_freekicks_order),
        xp: gws.map(
          (gw) =>
            Math.round(
              computePlayerXPts(
                el,
                gw,
                fixtures,
                teamsMap,
                teamGamesPlayed,
                Math.max(0, gw - nextGw),
                priors,
              ).xPts * 10,
            ) / 10,
        ),
      }));

    // Fixtures for the planning window plus 4 GWs, so a "next 5" strip
    // starting at the last planned GW is still complete.
    const planFixtures = fixtures
      .filter((f) => f.event != null && f.event >= nextGw && f.event <= lastGw + 4)
      .map((f) => ({
        gw: f.event as number,
        h: f.team_h,
        a: f.team_a,
        hd: f.team_h_difficulty,
        ad: f.team_a_difficulty,
      }));

    const deadlines: Record<number, string> = {};
    for (const ev of rawBs.events) deadlines[ev.id] = ev.deadline_time;

    const { sellingPrices } = computeSellingPrices(
      picks.picks,
      transfers,
      elementsMap,
    );

    const body: PlanResponse = {
      entryId,
      currentGw,
      nextGw,
      gws,
      deadlines,
      bank: picks.entry_history.bank,
      freeTransfers: computeFreeTransfers(history, entry.started_event ?? 1),
      picks: picks.picks.map((p) => ({
        element: p.element,
        position: p.position,
        isCaptain: p.is_captain,
        isVice: p.is_vice_captain,
      })),
      sellingPrices,
      teams: rawBs.teams.map((t) => ({
        id: t.id,
        code: t.code,
        short: t.short_name,
        name: t.name,
      })),
      fixtures: planFixtures,
      players,
      computedAt: new Date().toISOString(),
    };
    return NextResponse.json(body);
  } catch (err) {
    console.error(`[FPL Vortex /api/plan/${entryId} error]`, err);
    const status = err instanceof FplError ? err.status : 500;
    return NextResponse.json(
      {
        error:
          err instanceof Error
            ? err.message
            : "Could not build the plan for this team.",
      },
      { status },
    );
  }
}
