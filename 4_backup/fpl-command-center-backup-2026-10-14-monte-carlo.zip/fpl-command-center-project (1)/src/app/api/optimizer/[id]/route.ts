import { NextResponse } from "next/server";
import { fplFetch, FplError } from "@/lib/fpl";
import { runCoreOptimizer } from "@/lib/optimizer";
import type {
  ChipDef,
  EntryHistory,
  EntrySummary,
  Fixture,
  LiveResponse,
  PicksResponse,
  SlimElement,
  SlimEvent,
  SlimTeam,
  Transfer,
} from "@/lib/types";

export const dynamic = "force-dynamic";

interface RawBootstrap {
  events: (SlimEvent & Record<string, unknown>)[];
  teams: (SlimTeam & Record<string, unknown>)[];
  elements: (SlimElement & Record<string, unknown>)[];
  chips: (ChipDef & Record<string, unknown>)[];
}

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const entryId = Number(id);
  if (!Number.isInteger(entryId) || entryId < 1) {
    return NextResponse.json({ error: "Invalid team ID." }, { status: 400 });
  }

  const url = new URL(req.url);
  const horizonParam = Number(url.searchParams.get("horizon") ?? 5);
  const horizon = Math.max(1, Math.min(10, Number.isInteger(horizonParam) ? horizonParam : 5));

  try {
    const [rawBs, fixtures, entry, history, transfers] = await Promise.all([
      fplFetch<RawBootstrap>("bootstrap-static/", 300),
      fplFetch<Fixture[]>("fixtures/", 300),
      fplFetch<EntrySummary>(`entry/${entryId}/`, 120),
      fplFetch<EntryHistory>(`entry/${entryId}/history/`, 120),
      fplFetch<Transfer[]>(`entry/${entryId}/transfers/`, 300),
    ]);

    const currentGw =
      entry.current_event ??
      rawBs.events.find((e) => e.is_current)?.id ??
      1;
    const nextGw =
      rawBs.events.find((e) => e.is_next)?.id ??
      Math.min(38, currentGw + 1);

    const picks = await fplFetch<PicksResponse>(
      `entry/${entryId}/event/${currentGw}/picks/`,
      60,
    );

    // Load live stats for up to the 3 most recent completed/current GWs for backtesting
    const completedGws = rawBs.events
      .filter((e) => e.finished || e.is_current)
      .map((e) => e.id)
      .slice(-3);

    const liveByGw = new Map<number, LiveResponse>();
    for (const gw of completedGws) {
      try {
        const live = await fplFetch<LiveResponse>(`event/${gw}/live/`, 300);
        liveByGw.set(gw, live);
      } catch (liveErr) {
        console.error(
          `[FPL Vortex /api/optimizer/${entryId} live GW${gw} fetch warning]`,
          liveErr instanceof Error ? liveErr.message : liveErr,
        );
      }
    }

    const elements: SlimElement[] = rawBs.elements.map((p) => ({
      id: p.id,
      code: p.code,
      web_name: p.web_name,
      first_name: p.first_name,
      second_name: p.second_name,
      team: p.team,
      element_type: p.element_type,
      now_cost: p.now_cost,
      cost_change_event: p.cost_change_event,
      total_points: p.total_points,
      event_points: p.event_points,
      form: p.form,
      points_per_game: p.points_per_game,
      selected_by_percent: p.selected_by_percent,
      status: p.status,
      news: p.news,
      news_added: p.news_added ?? null,
      chance_of_playing_next_round: p.chance_of_playing_next_round ?? null,
      chance_of_playing_this_round: p.chance_of_playing_this_round ?? null,
      ep_next: p.ep_next ?? "0.0",
      ep_this: p.ep_this ?? null,
      minutes: p.minutes ?? 0,
      starts: p.starts ?? 0,
      starts_per_90: Number(p.starts_per_90 ?? 0),
      goals_scored: p.goals_scored ?? 0,
      assists: p.assists ?? 0,
      clean_sheets: p.clean_sheets ?? 0,
      clean_sheets_per_90: Number(p.clean_sheets_per_90 ?? 0),
      saves: p.saves ?? 0,
      saves_per_90: Number(p.saves_per_90 ?? 0),
      bonus: p.bonus ?? 0,
      bps: p.bps ?? 0,
      defensive_contribution: Number(p.defensive_contribution ?? 0),
      defensive_contribution_per_90: Number(p.defensive_contribution_per_90 ?? 0),
      yellow_cards: p.yellow_cards ?? 0,
      red_cards: p.red_cards ?? 0,
      own_goals: p.own_goals ?? 0,
      penalties_saved: p.penalties_saved ?? 0,
      penalties_missed: p.penalties_missed ?? 0,
      cost_change_start: p.cost_change_start ?? 0,
      transfers_in_event: p.transfers_in_event ?? 0,
      transfers_out_event: p.transfers_out_event ?? 0,
      expected_goals: String(p.expected_goals ?? "0.0"),
      expected_assists: String(p.expected_assists ?? "0.0"),
      expected_goal_involvements: String(p.expected_goal_involvements ?? "0.0"),
      expected_goals_conceded: String(p.expected_goals_conceded ?? "0.0"),
      expected_goals_per_90: Number(p.expected_goals_per_90 ?? 0),
      expected_assists_per_90: Number(p.expected_assists_per_90 ?? 0),
      expected_goal_involvements_per_90: Number(
        p.expected_goal_involvements_per_90 ?? 0,
      ),
      expected_goals_conceded_per_90: Number(
        p.expected_goals_conceded_per_90 ?? 0,
      ),
      price_change_percent:
        p.price_change_percent != null && !Number.isNaN(Number(p.price_change_percent))
          ? Number(p.price_change_percent)
          : null,
      price_change_hourly_rate:
        p.price_change_hourly_rate != null && !Number.isNaN(Number(p.price_change_hourly_rate))
          ? Number(p.price_change_hourly_rate)
          : null,
      price_change_projections: p.price_change_projections ?? null,
      price_change_locked_until: p.price_change_locked_until ?? null,
    }));

    const result = await runCoreOptimizer({
      entryId,
      currentGw,
      nextGw,
      horizon,
      picks,
      transfers,
      history,
      elements,
      teams: rawBs.teams,
      events: rawBs.events,
      fixtures,
      chips: rawBs.chips ?? [],
      liveByGw,
      startedEvent: entry.started_event ?? 1,
    });

    return NextResponse.json(result);
  } catch (err) {
    console.error(`[FPL Vortex /api/optimizer/${entryId} error]`, err);
    const status = err instanceof FplError ? err.status : 500;
    return NextResponse.json(
      {
        error:
          err instanceof Error
            ? err.message
            : "Could not run optimizer for this team.",
      },
      { status },
    );
  }
}
