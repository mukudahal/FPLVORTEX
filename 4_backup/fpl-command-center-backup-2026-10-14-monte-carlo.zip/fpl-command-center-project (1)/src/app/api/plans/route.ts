import { NextResponse } from "next/server";
import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { savedPlans } from "@/db/schema";

export const dynamic = "force-dynamic";

const MAX_PLANS = 3;

export async function GET(req: Request) {
  const url = new URL(req.url);
  const entryId = Number(url.searchParams.get("entry"));
  if (!Number.isInteger(entryId) || entryId < 1) {
    return NextResponse.json({ error: "Invalid entry." }, { status: 400 });
  }
  const rows = await db
    .select()
    .from(savedPlans)
    .where(and(eq(savedPlans.entryId, entryId), eq(savedPlans.active, true)))
    .orderBy(asc(savedPlans.createdAt));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  let body: {
    entryId?: number;
    name?: string;
    data?: unknown;
    projectedPoints?: number;
    id?: number;
  };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON." }, { status: 400 });
  }
  const entryId = Number(body.entryId);
  const name = String(body.name ?? "").trim().slice(0, 60);
  if (!Number.isInteger(entryId) || entryId < 1 || !name || body.data == null) {
    return NextResponse.json(
      { error: "entryId, name and data are required." },
      { status: 400 },
    );
  }
  const projected = Number(body.projectedPoints) || 0;

  if (body.id) {
    const updated = await db
      .update(savedPlans)
      .set({ name, data: body.data, projectedPoints: projected, updatedAt: new Date() })
      .where(and(eq(savedPlans.id, Number(body.id)), eq(savedPlans.entryId, entryId)))
      .returning();
    return NextResponse.json(updated[0] ?? { error: "Not found" });
  }

  const existing = await db
    .select({ id: savedPlans.id })
    .from(savedPlans)
    .where(and(eq(savedPlans.entryId, entryId), eq(savedPlans.active, true)));
  if (existing.length >= MAX_PLANS) {
    return NextResponse.json(
      { error: `Maximum ${MAX_PLANS} saved plans. Delete one first.` },
      { status: 409 },
    );
  }
  const inserted = await db
    .insert(savedPlans)
    .values({ entryId, name, data: body.data, projectedPoints: projected })
    .returning();
  return NextResponse.json(inserted[0]);
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const id = Number(url.searchParams.get("id"));
  const entryId = Number(url.searchParams.get("entry"));
  if (!Number.isInteger(id) || !Number.isInteger(entryId)) {
    return NextResponse.json({ error: "Invalid params." }, { status: 400 });
  }
  await db
    .delete(savedPlans)
    .where(and(eq(savedPlans.id, id), eq(savedPlans.entryId, entryId)));
  return NextResponse.json({ ok: true });
}
