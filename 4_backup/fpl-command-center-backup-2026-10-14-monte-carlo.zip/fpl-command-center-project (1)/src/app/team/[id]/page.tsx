import { TeamDashboard } from "@/components/team/TeamDashboard";

export default async function TeamPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return <TeamDashboard teamId={id} />;
}
