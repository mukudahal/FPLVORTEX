"use client";

import { useEffect, useMemo, useState } from "react";
import { Card, Pill } from "@/components/ui";
import { PlayerPhoto } from "@/components/PlayerPhoto";
import { TeamBadge } from "@/components/TeamBadge";
import { formatPrice, statusInfo } from "@/lib/helpers";
import type { SlimElement, SlimTeam } from "@/lib/types";

const SEEN_KEY = "fpl-news-last-seen";

const YC_THRESHOLDS: { cards: number; byGw: number; ban: string }[] = [
  { cards: 5, byGw: 19, ban: "1 match" },
  { cards: 10, byGw: 32, ban: "2 matches" },
  { cards: 15, byGw: 38, ban: "3 matches" },
];

function alternatives(
  el: SlimElement,
  elements: SlimElement[],
  squadIds: Set<number>,
): SlimElement[] {
  return elements
    .filter(
      (a) =>
        a.id !== el.id &&
        a.element_type === el.element_type &&
        a.status === "a" &&
        !squadIds.has(a.id) &&
        Math.abs(a.now_cost - el.now_cost) <= 10,
    )
    .sort((a, b) => parseFloat(b.form) - parseFloat(a.form))
    .slice(0, 3);
}

export function NewsView({
  elements,
  teamsMap,
  squadIds,
  currentGw,
}: {
  elements: SlimElement[];
  teamsMap: Map<number, SlimTeam>;
  squadIds: number[];
  currentGw: number;
}) {
  const [lastSeen, setLastSeen] = useState<string | null>(null);
  const [showAll, setShowAll] = useState(true);
  const [expanded, setExpanded] = useState<number | null>(null);
  const squadSet = useMemo(() => new Set(squadIds), [squadIds]);

  useEffect(() => {
    setLastSeen(localStorage.getItem(SEEN_KEY));
    const t = setTimeout(
      () => localStorage.setItem(SEEN_KEY, new Date().toISOString()),
      4000,
    );
    return () => clearTimeout(t);
  }, []);

  const newsItems = useMemo(
    () =>
      elements
        .filter((e) => e.news && e.news_added)
        .sort((a, b) => (b.news_added ?? "").localeCompare(a.news_added ?? "")),
    [elements],
  );

  const visible = showAll
    ? newsItems.slice(0, 40)
    : newsItems.filter((e) => lastSeen && (e.news_added ?? "") > lastSeen);

  const nextThreshold =
    YC_THRESHOLDS.find((t) => currentGw <= t.byGw) ??
    YC_THRESHOLDS[YC_THRESHOLDS.length - 1];
  const ycWatch = elements
    .filter(
      (e) =>
        e.yellow_cards >= nextThreshold.cards - 1 &&
        e.yellow_cards < nextThreshold.cards &&
        e.minutes > 0,
    )
    .sort((a, b) => b.yellow_cards - a.yellow_cards)
    .slice(0, 12);
  const suspended = elements.filter((e) => e.status === "s");

  return (
    <div className="flex flex-col gap-3">
      {/* Card suspension tracker */}
      <Card>
        <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-slate-400">
          Yellow-card suspension watch
        </p>
        <p className="mb-2 text-[10px] text-slate-500">
          Next threshold: {nextThreshold.cards} yellows by GW{nextThreshold.byGw}{" "}
          → {nextThreshold.ban} ban.
        </p>
        {ycWatch.length === 0 && suspended.length === 0 ? (
          <p className="text-sm text-slate-500">Nobody is on the brink.</p>
        ) : (
          <div className="flex flex-wrap gap-1.5">
            {suspended.map((e) => (
              <Pill key={e.id} className="bg-rose-500/20 text-rose-200">
                <TeamBadge
                  code={teamsMap.get(e.team)?.code}
                  shortName={teamsMap.get(e.team)?.short_name}
                  className="h-3.5 w-3.5"
                />
                {e.web_name} — suspended
                {squadSet.has(e.id) ? " · YOURS" : ""}
              </Pill>
            ))}
            {ycWatch.map((e) => (
              <Pill
                key={e.id}
                className={
                  squadSet.has(e.id)
                    ? "bg-amber-400/25 text-amber-100 ring-1 ring-amber-400"
                    : "bg-amber-400/10 text-amber-200"
                }
              >
                <TeamBadge
                  code={teamsMap.get(e.team)?.code}
                  shortName={teamsMap.get(e.team)?.short_name}
                  className="h-3.5 w-3.5"
                />
                {e.web_name} · {e.yellow_cards}/{nextThreshold.cards} YC
                {squadSet.has(e.id) ? " · YOURS" : ""}
              </Pill>
            ))}
          </div>
        )}
      </Card>

      {/* Feed controls */}
      <div className="flex items-center justify-between px-1">
        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          Injuries &amp; Suspensions Feed
        </p>
        <div className="flex rounded-full border border-white/15 p-0.5">
          <button
            onClick={() => setShowAll(false)}
            className={`rounded-full px-2.5 py-1 text-[10px] font-semibold ${
              !showAll ? "bg-[#84d21c] text-[#000000]" : "text-slate-400"
            }`}
          >
            New since last visit
          </button>
          <button
            onClick={() => setShowAll(true)}
            className={`rounded-full px-2.5 py-1 text-[10px] font-semibold ${
              showAll ? "bg-[#84d21c] text-[#000000]" : "text-slate-400"
            }`}
          >
            All
          </button>
        </div>
      </div>

      {visible.length === 0 ? (
        <Card>
          <p className="text-sm text-slate-500">
            {showAll
              ? "No flagged players right now."
              : "Nothing new since your last visit."}
          </p>
        </Card>
      ) : (
        <div className="flex flex-col gap-2">
          {visible.map((e) => {
            const status = statusInfo(e.status);
            const mine = squadSet.has(e.id);
            const isNew = lastSeen && (e.news_added ?? "") > lastSeen;
            const team = teamsMap.get(e.team);
            const isOpen = expanded === e.id;
            const alts = isOpen ? alternatives(e, elements, squadSet) : [];
            const shouldReplace =
              e.status === "i" ||
              e.status === "n" ||
              e.status === "u" ||
              (e.chance_of_playing_next_round !== null &&
                e.chance_of_playing_next_round <= 25);
            return (
              <Card
                key={e.id}
                className={`!p-3 ${mine ? "ring-1 ring-[#84d21c]/50" : ""}`}
              >
                <button
                  className="flex w-full items-start gap-2.5 text-left"
                  onClick={() => setExpanded(isOpen ? null : e.id)}
                >
                  <PlayerPhoto
                    code={e.code}
                    alt={e.web_name}
                    className="h-10 w-8 object-cover"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <TeamBadge
                        code={team?.code}
                        shortName={team?.short_name}
                        className="h-3.5 w-3.5"
                      />
                      <p className="text-sm font-bold">{e.web_name}</p>
                      <span className="text-[10px] text-slate-500">
                        {team?.short_name}
                      </span>
                      {status ? (
                        <Pill className={`${status.className} !px-1.5 !text-[9px]`}>
                          {status.label}
                          {e.chance_of_playing_next_round !== null
                            ? ` ${e.chance_of_playing_next_round}%`
                            : ""}
                        </Pill>
                      ) : null}
                      {mine ? (
                        <Pill className="bg-[#84d21c]/20 !px-1.5 !text-[9px] text-[#84d21c]">
                          YOUR SQUAD
                        </Pill>
                      ) : null}
                      {isNew ? (
                        <Pill className="bg-sky-400/20 !px-1.5 !text-[9px] text-sky-200">
                          NEW
                        </Pill>
                      ) : null}
                    </div>
                    <p className="mt-0.5 text-xs text-slate-300">{e.news}</p>
                    <p className="text-[9px] text-slate-500">
                      {e.news_added
                        ? new Date(e.news_added).toLocaleString(undefined, {
                            day: "numeric",
                            month: "short",
                            hour: "2-digit",
                            minute: "2-digit",
                          })
                        : ""}
                    </p>
                  </div>
                  <span className="text-slate-500">{isOpen ? "▴" : "▾"}</span>
                </button>
                {isOpen ? (
                  <div className="mt-2 border-t border-white/10 pt-2">
                    <p className="mb-1.5 text-[11px] font-semibold">
                      {shouldReplace ? (
                        <span className="text-rose-300">
                          Verdict: REPLACE (Estimate: 80% confidence) — unlikely to feature soon.
                        </span>
                      ) : (
                        <span className="text-amber-300">
                          Verdict: HOLD (Estimate: 70% confidence) — monitor before the deadline.
                        </span>
                      )}
                    </p>
                    <p className="mb-1 text-[10px] uppercase tracking-wider text-slate-500">
                      Similar-price alternatives ({formatPrice(e.now_cost)} ±£1.0m)
                    </p>
                    <div className="flex flex-col gap-1.5">
                      {alts.map((a) => {
                        const aTeam = teamsMap.get(a.team);
                        return (
                          <div
                            key={a.id}
                            className="flex items-center justify-between rounded-lg bg-white/[0.04] px-2 py-1 text-xs"
                          >
                            <span className="flex items-center gap-1.5">
                              <PlayerPhoto
                                code={a.code}
                                alt={a.web_name}
                                className="h-6 w-5 object-cover"
                              />
                              <TeamBadge
                                code={aTeam?.code}
                                shortName={aTeam?.short_name}
                                className="h-3.5 w-3.5"
                              />
                              <span className="font-semibold">{a.web_name}</span>
                              <span className="text-slate-500">
                                {aTeam?.short_name} · {formatPrice(a.now_cost)}
                              </span>
                            </span>
                            <span className="text-slate-400">
                              form{" "}
                              <span className="font-bold text-[#84d21c]">
                                {a.form}
                              </span>
                            </span>
                          </div>
                        );
                      })}
                      {alts.length === 0 ? (
                        <p className="text-xs text-slate-500">
                          No obvious like-for-like replacement.
                        </p>
                      ) : null}
                    </div>
                  </div>
                ) : null}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
