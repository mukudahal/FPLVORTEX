"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { Card, ErrorBox, Pill, Spinner, StatBox } from "@/components/ui";
import { PitchView } from "@/components/team/PitchView";
import { HistoryView } from "@/components/team/HistoryView";
import { TransfersView } from "@/components/team/TransfersView";
import { ExplainView } from "@/components/team/ExplainView";
import { PriceView } from "@/components/team/PriceView";
import { NewsView } from "@/components/team/NewsView";
import { MatchesView } from "@/components/team/MatchesView";
import { ChipsView } from "@/components/team/ChipsView";
import { RivalsView } from "@/components/team/RivalsView";
import { VerdictView } from "@/components/team/VerdictView";
import { AutoOptimizedView } from "@/components/team/AutoOptimizedView";
import { PlannerView } from "@/components/team/PlannerView";
import { CopilotChat } from "@/components/team/CopilotChat";
import { DataModelStatus } from "@/components/DataModelStatus";
import { TabErrorBoundary, VerdictSkeleton } from "@/components/ErrorBoundary";
import { useJson } from "@/lib/useJson";
import { chipLabel, formatRank, saveTeamId } from "@/lib/helpers";
import type {
  EntryResponse,
  Fixture,
  LiveResponse,
  OptimizerResponse,
  PicksResponse,
  SlimBootstrap,
} from "@/lib/types";

type Tab =
  | "review"
  | "analysis"
  | "live"
  | "match"
  | "chips"
  | "rivals"
  | "verdict"
  | "auto"
  | "planner"
  | "season"
  | "transfers"
  | "copilot"
  | "status";

// Shared tab order: Review, Live, Match, Chips, Rivals, Verdict, Auto Optimized, Planner
// (plus GW Analysis, Season, Transfers, and Data & Model Status)
const TABS: [Tab, string][] = [
  ["review", "Review"],
  ["analysis", "GW Analysis"],
  ["live", "Live"],
  ["match", "Match"],
  ["chips", "Chips"],
  ["rivals", "Rivals"],
  ["verdict", "Verdict"],
  ["auto", "Auto Optimized"],
  ["planner", "Planner"],
  ["season", "Season"],
  ["transfers", "Transfers"],
  ["copilot", "Copilot 🏆"],
  ["status", "Data & Model Status"],
];

export function TeamDashboard({ teamId }: { teamId: string }) {
  const [tab, setTab] = useState<Tab>("review");
  const [viewGw, setViewGw] = useState<number | null>(null);
  const [horizon, setHorizon] = useState<number>(5);

  const bootstrap = useJson<SlimBootstrap>("/api/fpl/bootstrap");
  const entry = useJson<EntryResponse>(`/api/fpl/entry/${teamId}`, 120_000);
  const fixtures = useJson<Fixture[]>("/api/fpl/fixtures", 300_000);
  const optimizer = useJson<OptimizerResponse>(
    `/api/optimizer/${teamId}?horizon=${horizon}`,
    180_000,
  );

  const currentGw =
    entry.data?.entry.current_event ?? bootstrap.data?.currentEvent ?? null;
  const nextGw = useMemo(() => {
    const n = bootstrap.data?.nextEvent ?? null;
    if (n) return n;
    return currentGw && currentGw < 38 ? currentGw + 1 : currentGw;
  }, [bootstrap.data, currentGw]);

  useEffect(() => {
    if (viewGw === null && currentGw) setViewGw(currentGw);
  }, [currentGw, viewGw]);

  useEffect(() => {
    if (entry.data) saveTeamId(teamId);
  }, [entry.data, teamId]);

  const gwEvent = useMemo(
    () => bootstrap.data?.events.find((e) => e.id === viewGw) ?? null,
    [bootstrap.data, viewGw],
  );
  const isLiveGw =
    viewGw !== null &&
    viewGw === currentGw &&
    gwEvent !== null &&
    !gwEvent.finished;

  const picks = useJson<PicksResponse>(
    viewGw ? `/api/fpl/entry/${teamId}/picks/${viewGw}` : null,
    isLiveGw ? 60_000 : 0,
  );
  const curPicks = useJson<PicksResponse>(
    currentGw ? `/api/fpl/entry/${teamId}/picks/${currentGw}` : null,
  );
  const live = useJson<LiveResponse>(
    viewGw ? `/api/fpl/live/${viewGw}` : null,
    isLiveGw ? 60_000 : 0,
  );

  const liveMap = useMemo(() => {
    const m = new Map<number, LiveResponse["elements"][number]["stats"]>();
    live.data?.elements.forEach((e) => m.set(e.id, e.stats));
    return m;
  }, [live.data]);

  const elementsMap = useMemo(() => {
    const m = new Map<number, SlimBootstrap["elements"][number]>();
    bootstrap.data?.elements.forEach((e) => m.set(e.id, e));
    return m;
  }, [bootstrap.data]);

  const teamsMap = useMemo(() => {
    const m = new Map<number, SlimBootstrap["teams"][number]>();
    bootstrap.data?.teams.forEach((t) => m.set(t.id, t));
    return m;
  }, [bootstrap.data]);

  const gwFixtures = useMemo(
    () => (fixtures.data ?? []).filter((f) => f.event === viewGw),
    [fixtures.data, viewGw],
  );

  const effectiveCurPicks =
    curPicks.data ??
    (viewGw === currentGw ? picks.data : null) ??
    optimizer.data?.currentPicks ??
    picks.data ??
    null;

  const squadIds = useMemo(
    () =>
      (effectiveCurPicks?.picks ?? []).length > 0
        ? (effectiveCurPicks?.picks ?? []).map((p) => p.element)
        : (optimizer.data?.optimizedNextGw?.squad ?? []),
    [effectiveCurPicks, optimizer.data],
  );
  const squadElements = useMemo(
    () =>
      squadIds
        .map((id) => elementsMap.get(id))
        .filter((e): e is NonNullable<typeof e> => !!e),
    [squadIds, elementsMap],
  );
  const squadTeamIds = useMemo(
    () => new Set(squadElements.map((e) => e.team)),
    [squadElements],
  );

  const livePoints = useMemo(() => {
    if (!picks.data) return null;
    let total = 0;
    for (const p of picks.data.picks) {
      const stats = liveMap.get(p.element);
      if (stats) total += stats.total_points * p.multiplier;
    }
    return total - picks.data.entry_history.event_transfers_cost;
  }, [picks.data, liveMap]);

  // Section 1.2: Overall rank & previous GW overall rank from entry/{id}/history/
  const gkSideStats = useMemo(() => {
    const hist = entry.data?.history.current ?? [];
    const currRow = hist.find((h) => h.event === viewGw);
    const prevRow = hist.find((h) => h.event === (viewGw ?? 0) - 1);
    const pts =
      isLiveGw && livePoints !== null
        ? livePoints
        : (picks.data?.entry_history.points ?? currRow?.points ?? "—");
    return {
      gwPoints: pts,
      overallRank:
        currRow?.overall_rank ??
        picks.data?.entry_history.overall_rank ??
        entry.data?.entry.summary_overall_rank ??
        null,
      previousOverallRank: prevRow?.overall_rank ?? null,
    };
  }, [entry.data, viewGw, isLiveGw, livePoints, picks.data]);

  if (entry.loading || bootstrap.loading) {
    return <Spinner label="Loading team…" />;
  }
  if (entry.error || !entry.data) {
    return (
      <div className="pt-10">
        <ErrorBox
          message={entry.error ?? "Could not load this team."}
          onRetry={entry.refresh}
        />
        <p className="text-center text-sm">
          <Link href="/" className="text-[#84d21c] underline">
            ← Try a different Team ID
          </Link>
        </p>
      </div>
    );
  }
  if (bootstrap.error || !bootstrap.data) {
    return (
      <ErrorBox
        message={bootstrap.error ?? "Could not load FPL data."}
        onRetry={bootstrap.refresh}
      />
    );
  }

  const e = entry.data.entry;
  const eh = picks.data?.entry_history;
  const shownPoints = isLiveGw && livePoints !== null ? livePoints : eh?.points;
  const activeChip = chipLabel(picks.data?.active_chip);

  return (
    <main className="px-3 pt-5">
      {/* Header */}
      <header className="mb-4 px-1">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h1 className="truncate text-xl font-extrabold tracking-tight">
              {e.name}
            </h1>
            <p className="truncate text-sm text-slate-400">
              {e.player_first_name} {e.player_last_name} · #{e.id}
              {e.player_region_name ? ` · ${e.player_region_name}` : ""}
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-1.5">
            {isLiveGw ? (
              <Pill className="bg-[#84d21c]/15 text-[#84d21c]">
                <span className="live-dot h-1.5 w-1.5 rounded-full bg-[#84d21c]" />
                LIVE
              </Pill>
            ) : null}
            <button
              type="button"
              onClick={() => setTab("status")}
              className="rounded-full border border-white/15 bg-white/5 px-2.5 py-1 text-[10px] font-bold text-slate-300 hover:bg-white/10"
              title="Data freshness, model accuracy & solver run time"
            >
              {optimizer.data
                ? `MAE ${optimizer.data.backtest.mae} · ${optimizer.data.solverRunMs}ms`
                : "Model Status"}
            </button>
          </div>
        </div>

        <div className="mt-3 grid grid-cols-3 gap-2">
          <StatBox
            label={`GW${viewGw ?? "?"} Points`}
            value={shownPoints ?? "—"}
            accent
            sub={
              eh && eh.event_transfers_cost > 0
                ? `-${eh.event_transfers_cost} hits`
                : gwEvent?.average_entry_score
                  ? `Avg ${gwEvent.average_entry_score}`
                  : undefined
            }
          />
          <StatBox
            label="Total"
            value={e.summary_overall_points ?? "—"}
            sub={`GW rank ${formatRank(e.summary_event_rank)}`}
          />
          <StatBox
            label="Overall Rank"
            value={formatRank(e.summary_overall_rank)}
            sub={
              eh
                ? `Team £${(eh.value / 10).toFixed(1)}m · Bank £${(eh.bank / 10).toFixed(1)}m`
                : undefined
            }
          />
        </div>

        {activeChip ? (
          <div className="mt-2">
            <Pill className="bg-fuchsia-500/20 text-fuchsia-200">
              ★ {activeChip} active
            </Pill>
          </div>
        ) : null}
      </header>

      {/* Scrollable Tab Bar */}
      <div className="-mx-3 mb-4 overflow-x-auto px-3 pb-1">
        <div className="flex w-max gap-1.5">
          {TABS.map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setTab(key)}
              className={`shrink-0 rounded-full px-3.5 py-2 text-xs font-bold transition ${
                tab === key
                  ? "bg-gradient-to-r from-[#cda228] to-[#84d21c] text-[#000000] shadow-md shadow-[#cda228]/20"
                  : "border border-white/10 bg-white/[0.04] text-slate-300 hover:border-[#cda228]/40 hover:text-white"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* SECTION 1: REVIEW TAB (Pitch + Goalkeeper side stats + GW Analysis below) */}
      {tab === "review" ? (
        <>
          <div className="mb-3 flex items-center justify-between px-1">
            <button
              type="button"
              onClick={() => setViewGw((g) => (g && g > 1 ? g - 1 : g))}
              disabled={!viewGw || viewGw <= (e.started_event ?? 1)}
              className="rounded-full border border-white/15 px-3 py-1 text-sm font-bold text-slate-300 disabled:opacity-30"
            >
              ‹
            </button>
            <div className="text-center">
              <p className="text-sm font-bold">
                Review · Gameweek {viewGw ?? "—"}
              </p>
              {live.lastUpdated && isLiveGw ? (
                <p className="text-[10px] text-slate-500">
                  auto-updating · last{" "}
                  {live.lastUpdated.toLocaleTimeString(undefined, {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              ) : null}
            </div>
            <button
              type="button"
              onClick={() =>
                setViewGw((g) => (g && currentGw && g < currentGw ? g + 1 : g))
              }
              disabled={!viewGw || !currentGw || viewGw >= currentGw}
              className="rounded-full border border-white/15 px-3 py-1 text-sm font-bold text-slate-300 disabled:opacity-30"
            >
              ›
            </button>
          </div>

          {picks.loading ? (
            <Spinner label="Loading squad…" />
          ) : picks.error || !picks.data ? (
            <ErrorBox
              message={picks.error ?? "No squad for this gameweek."}
              onRetry={picks.refresh}
            />
          ) : (
            <PitchView
              picks={picks.data}
              elementsMap={elementsMap}
              teamsMap={teamsMap}
              liveMap={liveMap}
              gwFixtures={gwFixtures}
              gkSideStats={gkSideStats}
            />
          )}

          {picks.data ? (
            <>
              <Card className="mt-3">
                <div className="grid grid-cols-3 gap-2 text-center text-xs text-slate-300">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-slate-500">
                      Bench pts
                    </p>
                    <p className="text-base font-bold">
                      {picks.data.entry_history.points_on_bench}
                    </p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-slate-500">
                      Transfers
                    </p>
                    <p className="text-base font-bold">
                      {picks.data.entry_history.event_transfers}
                      {picks.data.entry_history.event_transfers_cost > 0
                        ? ` (-${picks.data.entry_history.event_transfers_cost})`
                        : ""}
                    </p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-slate-500">
                      GW rank
                    </p>
                    <p className="text-base font-bold">
                      {formatRank(picks.data.entry_history.rank)}
                    </p>
                  </div>
                </div>
              </Card>

              {/* Also render GW Analysis & Hindsight Verdict right below Pitch in Review */}
              <div className="mt-4">
                <ExplainView
                  gw={viewGw ?? currentGw ?? 1}
                  picks={picks.data}
                  elements={bootstrap.data.elements}
                  elementsMap={elementsMap}
                  teamsMap={teamsMap}
                  liveMap={liveMap}
                  gwFixtures={gwFixtures}
                  sellingPrices={optimizer.data?.sellingPrices}
                />
              </div>
            </>
          ) : null}
        </>
      ) : null}

      {/* SECTION 1.3 & 1.4: GW ANALYSIS TAB */}
      {tab === "analysis" ? (
        picks.loading || live.loading ? (
          <Spinner label="Analysing your gameweek…" />
        ) : picks.data ? (
          <ExplainView
            gw={viewGw ?? currentGw ?? 1}
            picks={picks.data}
            elements={bootstrap.data.elements}
            elementsMap={elementsMap}
            teamsMap={teamsMap}
            liveMap={liveMap}
            gwFixtures={gwFixtures}
            sellingPrices={optimizer.data?.sellingPrices}
          />
        ) : (
          <ErrorBox message={picks.error ?? "No picks for this gameweek."} />
        )
      ) : null}

      {/* SECTION 3: LIVE TAB (2-column Price Watch + Injuries & Suspensions below) */}
      {tab === "live" ? (
        <div className="flex flex-col gap-4">
          <PriceView
            squadIds={squadIds}
            elements={bootstrap.data.elements}
            elementsMap={elementsMap}
            teamsMap={teamsMap}
          />
          {currentGw ? (
            <NewsView
              elements={bootstrap.data.elements}
              teamsMap={teamsMap}
              squadIds={squadIds}
              currentGw={currentGw}
            />
          ) : null}
        </div>
      ) : null}

      {/* SECTION 5 (Phase 5): MATCH TAB */}
      {tab === "match" ? (
        fixtures.loading || !fixtures.data ? (
          <Spinner label="Loading fixtures & predicted XIs…" />
        ) : (
          <MatchesView
            fixtures={fixtures.data}
            elements={bootstrap.data.elements}
            teamsMap={teamsMap}
            gw={nextGw ?? currentGw ?? 1}
            squadTeamIds={squadTeamIds}
          />
        )
      ) : null}

      {/* SECTION 4: CHIPS TAB (Full simulation) */}
      {tab === "chips" ? (
        optimizer.loading && !optimizer.data ? (
          <Spinner label="Running MILP chip simulations across remaining gameweeks…" />
        ) : optimizer.error || !optimizer.data ? (
          <ErrorBox
            message={optimizer.error ?? "Could not run chip simulator."}
            onRetry={optimizer.refresh}
          />
        ) : (
          <ChipsView
            optimizer={optimizer.data}
            elementsMap={elementsMap}
            teamsMap={teamsMap}
          />
        )
      ) : null}

      {/* RIVALS TAB */}
      {tab === "rivals" && currentGw ? (
        <RivalsView
          entry={entry.data}
          myPicks={squadIds}
          elementsMap={elementsMap}
          currentGw={currentGw}
        />
      ) : null}

      {/* SECTION 2: VERDICT TAB */}
      {tab === "verdict" ? (
        <TabErrorBoundary
          tabName="Verdict"
          onRetry={() => {
            optimizer.refresh();
            curPicks.refresh();
          }}
        >
          {optimizer.loading && !optimizer.data ? (
            <VerdictSkeleton />
          ) : optimizer.error && !optimizer.data ? (
            <ErrorBox
              message={optimizer.error}
              onRetry={() => {
                optimizer.refresh();
                curPicks.refresh();
              }}
            />
          ) : !optimizer.data ? (
            <Card className="my-4 border-amber-400/40 bg-amber-400/10 text-center">
              <p className="text-sm font-bold text-amber-200">
                Verdict data is empty
              </p>
              <p className="mt-1 text-xs text-amber-100/90">
                Missing optimizer output for Team #{teamId} (GW{nextGw ?? "—"}).
              </p>
              <button
                type="button"
                onClick={() => {
                  optimizer.refresh();
                  curPicks.refresh();
                }}
                className="mt-3 rounded-full bg-gradient-to-r from-[#cda228] to-[#84d21c] px-4 py-1.5 text-xs font-extrabold text-[#000000]"
              >
                Retry Verdict
              </button>
            </Card>
          ) : (
            <VerdictView
              entry={entry.data}
              picks={effectiveCurPicks}
              elements={bootstrap.data.elements}
              elementsMap={elementsMap}
              teamsMap={teamsMap}
              events={bootstrap.data.events}
              optimizer={optimizer.data}
              nextGw={nextGw}
              onRetry={() => {
                optimizer.refresh();
                curPicks.refresh();
              }}
            />
          )}
        </TabErrorBoundary>
      ) : null}

      {/* SECTION 5: AUTO OPTIMIZED TAB */}
      {tab === "auto" ? (
        <TabErrorBoundary tabName="Auto Optimized" onRetry={optimizer.refresh}>
          {optimizer.loading && !optimizer.data ? (
            <Spinner label="Solving optimal squad & lineup…" />
          ) : optimizer.error || !optimizer.data ? (
            <ErrorBox
              message={optimizer.error ?? "Could not load Auto Optimized plan."}
              onRetry={optimizer.refresh}
            />
          ) : (
            <AutoOptimizedView
              optimizer={optimizer.data}
              elementsMap={elementsMap}
              teamsMap={teamsMap}
              horizon={horizon}
              onChangeHorizon={setHorizon}
              onOpenVerdict={() => setTab("verdict")}
              onOpenPlanner={() => setTab("planner")}
            />
          )}
        </TabErrorBoundary>
      ) : null}

      {/* SECTION 6: PLANNER TAB */}
      {tab === "planner" ? (
        <TabErrorBoundary tabName="Planner" onRetry={optimizer.refresh}>
          {optimizer.loading && !optimizer.data ? (
            <Spinner label="Loading planner & solver baseline…" />
          ) : optimizer.error || !optimizer.data || !effectiveCurPicks ? (
            <ErrorBox
              message={optimizer.error ?? "Could not load Planner."}
              onRetry={() => {
                optimizer.refresh();
                curPicks.refresh();
              }}
            />
          ) : (
            <PlannerView
              entryId={e.id}
              picks={effectiveCurPicks}
              elements={bootstrap.data.elements}
              elementsMap={elementsMap}
              teamsMap={teamsMap}
              chips={bootstrap.data.chips}
              history={entry.data.history}
              optimizer={optimizer.data}
              nextGw={nextGw ?? 38}
            />
          )}
        </TabErrorBoundary>
      ) : null}

      {tab === "season" ? (
        <HistoryView
          history={entry.data.history}
          events={bootstrap.data.events}
        />
      ) : null}

      {tab === "transfers" ? (
        <TransfersView
          teamId={teamId}
          elementsMap={elementsMap}
          teamsMap={teamsMap}
        />
      ) : null}

      {tab === "copilot" ? (
        <TabErrorBoundary tabName="Copilot" onRetry={optimizer.refresh}>
          <CopilotChat teamId={teamId} onNavigate={(t) => setTab(t as typeof tab)} />
        </TabErrorBoundary>
      ) : null}

      {tab === "status" ? (
        <DataModelStatus optimizer={optimizer.data} />
      ) : null}
    </main>
  );
}
