"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Card, ErrorBox, Pill } from "@/components/ui";
import { Pitch, type PitchCardItem } from "@/components/Pitch";
import { PlayerPhoto } from "@/components/PlayerPhoto";
import { TeamBadge } from "@/components/TeamBadge";
import { chipLabel, formatPrice, POSITIONS } from "@/lib/helpers";
import { solveLineupTS } from "@/lib/lineup";
import type {
  ChipDef,
  EntryHistory,
  OptimizerResponse,
  PicksResponse,
  SlimElement,
  SlimTeam,
} from "@/lib/types";

interface PlanTransfer {
  out: number;
  in: number;
}
interface PlanGw {
  gw: number;
  transfers: PlanTransfer[];
  chip: string | null; // wildcard | freehit | bboost | 3xc
  starters?: number[]; // 11
  bench?: number[]; // 4: [gk, sub1, sub2, sub3]
  captainId?: number;
  viceId?: number;
}
interface PlanData {
  startGw: number;
  gws: PlanGw[];
}
interface SavedPlanRow {
  id: number;
  name: string;
  data: PlanData;
  projectedPoints: number;
}

const CHIP_OPTIONS = ["wildcard", "freehit", "bboost", "3xc"] as const;

interface SimGw {
  gw: number;
  squad: number[];
  starters: number[];
  bench: number[];
  captainId: number;
  viceId: number;
  bank: number;
  ftBefore: number;
  ftAfter: number;
  hits: number;
  errors: string[];
  projected: number;
  formation: string;
}

function isValidFormation(
  starters: number[],
  elementsMap: Map<number, SlimElement>,
): { valid: boolean; formation: string; reason?: string } {
  if (starters.length !== 11) {
    return { valid: false, formation: "?-?-?", reason: `Starting XI has ${starters.length} players (must be 11).` };
  }
  const counts: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0 };
  for (const id of starters) {
    const t = elementsMap.get(id)?.element_type ?? 0;
    counts[t] = (counts[t] ?? 0) + 1;
  }
  const formation = `${counts[2]}-${counts[3]}-${counts[4]}`;
  if (counts[1] !== 1) return { valid: false, formation, reason: "Must start exactly 1 Goalkeeper." };
  if (counts[2] < 3 || counts[2] > 5) return { valid: false, formation, reason: "Must start 3 to 5 Defenders." };
  if (counts[3] < 2 || counts[3] > 5) return { valid: false, formation, reason: "Must start 2 to 5 Midfielders." };
  if (counts[4] < 1 || counts[4] > 3) return { valid: false, formation, reason: "Must start 1 to 3 Forwards." };
  return { valid: true, formation };
}

export function PlannerView({
  entryId,
  picks,
  elements,
  elementsMap,
  teamsMap,
  chips,
  history,
  optimizer,
  nextGw,
}: {
  entryId: number;
  picks: PicksResponse;
  elements: SlimElement[];
  elementsMap: Map<number, SlimElement>;
  teamsMap: Map<number, SlimTeam>;
  chips: ChipDef[];
  history: EntryHistory;
  optimizer: OptimizerResponse;
  nextGw: number;
}) {
  const baseSquad = useMemo(() => picks.picks.map((p) => p.element), [picks]);
  const baseStarters = useMemo(
    () => picks.picks.filter((p) => p.position <= 11).map((p) => p.element),
    [picks],
  );
  const baseBench = useMemo(
    () =>
      picks.picks
        .filter((p) => p.position >= 12)
        .sort((a, b) => a.position - b.position)
        .map((p) => p.element),
    [picks],
  );
  const baseCap = useMemo(
    () => picks.picks.find((p) => p.is_captain)?.element ?? baseStarters[0],
    [picks, baseStarters],
  );
  const baseVice = useMemo(
    () => picks.picks.find((p) => p.is_vice_captain)?.element ?? baseStarters[1],
    [picks, baseStarters],
  );
  const baseBank = picks.entry_history.bank;

  const horizon = useMemo(
    () => Array.from({ length: 5 }, (_, i) => nextGw + i).filter((g) => g <= 38),
    [nextGw],
  );

  const buildResetPlan = useCallback((): PlanData => {
    return {
      startGw: nextGw,
      gws: horizon.map((g, idx) => ({
        gw: g,
        transfers: [],
        chip: null,
        starters: idx === 0 ? [...baseStarters] : undefined,
        bench: idx === 0 ? [...baseBench] : undefined,
        captainId: idx === 0 ? baseCap : undefined,
        viceId: idx === 0 ? baseVice : undefined,
      })),
    };
  }, [nextGw, horizon, baseStarters, baseBench, baseCap, baseVice]);

  const buildOptimizerPlan = useCallback((): PlanData => {
    return {
      startGw: nextGw,
      gws: horizon.map((g) => {
        const mg = optimizer.multiGwPlan.find((m) => m.gw === g);
        return {
          gw: g,
          transfers: (mg?.transfers ?? []).map((t) => ({
            out: t.outId,
            in: t.inId,
          })),
          chip: mg?.chip ?? null,
          starters: mg ? [...mg.starters] : undefined,
          bench: mg ? [...mg.bench] : undefined,
          captainId: mg?.captainId,
          viceId: mg?.viceId,
        };
      }),
    };
  }, [nextGw, horizon, optimizer.multiGwPlan]);

  const [plan, setPlan] = useState<PlanData>(buildResetPlan);
  const [activeGw, setActiveGw] = useState(nextGw);
  const [selectedPlayerId, setSelectedPlayerId] = useState<number | null>(null);
  const [transferModalOpen, setTransferModalOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [saved, setSaved] = useState<SavedPlanRow[]>([]);
  const [planName, setPlanName] = useState("");
  const [saveMsg, setSaveMsg] = useState<string | null>(null);

  useEffect(() => setPlan(buildResetPlan()), [buildResetPlan]);

  const loadSaved = useCallback(async () => {
    try {
      const res = await fetch(`/api/plans?entry=${entryId}`);
      if (res.ok) setSaved((await res.json()) as SavedPlanRow[]);
    } catch {
      /* ignore */
    }
  }, [entryId]);
  useEffect(() => void loadSaved(), [loadSaved]);

  const chipUsedAlready = useCallback(
    (name: string, gw: number) => {
      const def = chips.find(
        (c) => c.name === name && gw >= c.start_event && gw <= c.stop_event,
      );
      if (!def) return true;
      return history.chips.some(
        (h) =>
          h.name === name &&
          h.event >= def.start_event &&
          h.event <= def.stop_event,
      );
    },
    [chips, history],
  );

  // Selling price lookup: original squad uses optimizer.sellingPrices, newly bought players sell at their buy price
  const getSellPrice = useCallback(
    (id: number) => {
      return optimizer.sellingPrices[id] ?? elementsMap.get(id)?.now_cost ?? 0;
    },
    [optimizer.sellingPrices, elementsMap],
  );

  // ---- Simulate the 5-GW plan with selling prices & formation validation ----
  const sim = useMemo<SimGw[]>(() => {
    let squad = [...baseSquad];
    let bank = baseBank;
    let ft = optimizer.freeTransfersNow;
    let fhSnapshot: { squad: number[]; bank: number } | null = null;
    const out: SimGw[] = [];
    const chipsPlayed = new Set<string>();

    for (const pg of plan.gws) {
      const errors: string[] = [];
      if (fhSnapshot) {
        squad = fhSnapshot.squad;
        bank = fhSnapshot.bank;
        fhSnapshot = null;
      }
      const startSquad = [...squad];
      const startBank = bank;
      const ftBefore = ft;

      if (pg.chip) {
        const key = `${pg.chip}:${pg.gw <= 19 ? "h1" : "h2"}`;
        if (chipUsedAlready(pg.chip, pg.gw))
          errors.push(`${chipLabel(pg.chip)} is not available in this window.`);
        if (chipsPlayed.has(key))
          errors.push(`${chipLabel(pg.chip)} already placed in this half-season.`);
        chipsPlayed.add(key);
      }
      const freeTransfersChip = pg.chip === "wildcard" || pg.chip === "freehit";
      if (pg.chip === "freehit") {
        fhSnapshot = { squad: startSquad, bank: startBank };
      }

      // Apply transfers using selling prices
      let starters = pg.starters
        ? pg.starters.filter((id) => squad.includes(id))
        : [];
      let bench = pg.bench ? pg.bench.filter((id) => squad.includes(id)) : [];

      for (const t of pg.transfers) {
        const outEl = elementsMap.get(t.out);
        const inEl = elementsMap.get(t.in);
        if (!outEl || !inEl) continue;
        if (!squad.includes(t.out)) {
          errors.push(`${outEl.web_name} is not in the squad at GW${pg.gw}.`);
          continue;
        }
        if (squad.includes(t.in)) {
          errors.push(`${inEl.web_name} is already in the squad.`);
          continue;
        }
        if (outEl.element_type !== inEl.element_type) {
          errors.push(
            `${outEl.web_name} → ${inEl.web_name}: position mismatch (must keep 2-5-5-3).`,
          );
          continue;
        }
        const sellPrice = getSellPrice(t.out);
        squad = squad.map((id) => (id === t.out ? t.in : id));
        starters = starters.map((id) => (id === t.out ? t.in : id));
        bench = bench.map((id) => (id === t.out ? t.in : id));
        bank = bank + sellPrice - inEl.now_cost;
      }

      if (bank < 0) {
        errors.push(`Over budget by ${formatPrice(-bank)} (using selling prices).`);
      }

      // Max 3 per club check
      const clubCount = new Map<number, number>();
      squad.forEach((id) => {
        const e = elementsMap.get(id);
        if (e) clubCount.set(e.team, (clubCount.get(e.team) ?? 0) + 1);
      });
      for (const [team, n] of clubCount) {
        if (n > 3) {
          const tName = teamsMap.get(team)?.short_name ?? `Club #${team}`;
          errors.push(`More than 3 players from ${tName} (${n}/3).`);
        }
      }

      // Lineup & formation check
      const gwXPts = optimizer.xPtsByGw[pg.gw] ?? {};
      const autoLu = solveLineupTS(
        squad,
        elementsMap,
        gwXPts,
        pg.chip === "bboost",
        pg.chip === "3xc",
      );

      if (starters.length !== 11 || bench.length !== 4) {
        starters = autoLu.starters;
        bench = autoLu.bench;
      }

      const formCheck = isValidFormation(starters, elementsMap);
      if (!formCheck.valid && formCheck.reason) {
        errors.push(formCheck.reason);
      }

      const captainId =
        pg.captainId && starters.includes(pg.captainId)
          ? pg.captainId
          : autoLu.captainId;
      const viceId =
        pg.viceId && starters.includes(pg.viceId) && pg.viceId !== captainId
          ? pg.viceId
          : autoLu.viceId;

      // Hits & FT banking (max 5)
      const nTr = pg.transfers.length;
      const hits = freeTransfersChip ? 0 : Math.max(0, nTr - ftBefore) * 4;
      const ftAfter = freeTransfersChip
        ? Math.min(5, ftBefore)
        : Math.min(5, Math.max(0, ftBefore - nTr) + 1);
      ft = ftAfter;

      // Projected xPts for this GW
      const xiPts = starters.reduce((s, id) => s + (gwXPts[id] ?? 0), 0);
      const benchPts = bench.reduce((s, id) => s + (gwXPts[id] ?? 0), 0);
      const capExtra = (gwXPts[captainId] ?? 0) * (pg.chip === "3xc" ? 2 : 1);
      const projected =
        Math.round(
          (xiPts + capExtra + (pg.chip === "bboost" ? benchPts : 0) - hits) * 100,
        ) / 100;

      out.push({
        gw: pg.gw,
        squad: [...squad],
        starters,
        bench,
        captainId,
        viceId,
        bank,
        ftBefore,
        ftAfter,
        hits,
        errors,
        projected,
        formation: formCheck.formation,
      });
    }
    return out;
  }, [
    plan,
    baseSquad,
    baseBank,
    optimizer.freeTransfersNow,
    optimizer.xPtsByGw,
    elementsMap,
    teamsMap,
    chipUsedAlready,
    getSellPrice,
  ]);

  const totalProjected = sim.reduce((s, g) => s + g.projected, 0);
  const autoTotalProjected = useMemo(
    () =>
      optimizer.multiGwPlan
        .filter((m) => horizon.includes(m.gw))
        .reduce((s, m) => s + m.projectedXPts, 0),
    [optimizer.multiGwPlan, horizon],
  );
  const diffVsAuto = Math.round((totalProjected - autoTotalProjected) * 100) / 100;
  const totalErrors = sim.reduce((s, g) => s + g.errors.length, 0);

  const activePlanGw = plan.gws.find((g) => g.gw === activeGw);
  const activeSim = sim.find((g) => g.gw === activeGw);
  const activeXPtsMap = optimizer.xPtsByGw[activeGw] ?? {};

  function updateGw(gw: number, fn: (g: PlanGw, simState: SimGw) => PlanGw) {
    if (!activeSim) return;
    setPlan((p) => ({
      ...p,
      gws: p.gws.map((g) => (g.gw === gw ? fn(g, activeSim) : g)),
    }));
  }

  // Handle swapping two players between XI and Bench (or reordering bench)
  function swapStarterAndBench(starterId: number, benchId: number) {
    if (!activeSim) return;
    const sEl = elementsMap.get(starterId);
    const bEl = elementsMap.get(benchId);
    if (!sEl || !bEl) return;

    const nextStarters = activeSim.starters.map((id) =>
      id === starterId ? benchId : id,
    );
    const nextBench = activeSim.bench.map((id) =>
      id === benchId ? starterId : id,
    );
    const check = isValidFormation(nextStarters, elementsMap);
    if (!check.valid) return;

    updateGw(activeGw, (g) => ({
      ...g,
      starters: nextStarters,
      bench: nextBench,
      captainId:
        activeSim.captainId === starterId ? benchId : activeSim.captainId,
      viceId: activeSim.viceId === starterId ? benchId : activeSim.viceId,
    }));
    setSelectedPlayerId(null);
  }

  function moveBenchSlot(benchIdx: number, dir: -1 | 1) {
    if (!activeSim) return;
    // Outfield bench slots are indices 1, 2, 3
    const targetIdx = benchIdx + dir;
    if (benchIdx < 1 || targetIdx < 1 || targetIdx > 3) return;
    const nextBench = [...activeSim.bench];
    const tmp = nextBench[benchIdx];
    nextBench[benchIdx] = nextBench[targetIdx];
    nextBench[targetIdx] = tmp;
    updateGw(activeGw, (g) => ({
      ...g,
      starters: [...activeSim.starters],
      bench: nextBench,
    }));
  }

  // Auto-loaded replacement list when transferring out selectedPlayerId
  const replacementCandidates = useMemo(() => {
    if (!selectedPlayerId || !activeSim) return [];
    const outEl = elementsMap.get(selectedPlayerId);
    if (!outEl) return [];
    const sellPrice = getSellPrice(selectedPlayerId);
    const maxBudget = sellPrice + activeSim.bank;
    const q = search.trim().toLowerCase();

    const clubCount = new Map<number, number>();
    activeSim.squad.forEach((id) => {
      if (id === selectedPlayerId) return;
      const e = elementsMap.get(id);
      if (e) clubCount.set(e.team, (clubCount.get(e.team) ?? 0) + 1);
    });

    return elements
      .filter(
        (e) =>
          e.element_type === outEl.element_type &&
          e.id !== outEl.id &&
          !activeSim.squad.includes(e.id) &&
          e.now_cost <= maxBudget &&
          (clubCount.get(e.team) ?? 0) < 3 &&
          (q
            ? `${e.first_name} ${e.second_name} ${e.web_name}`
                .toLowerCase()
                .includes(q)
            : true),
      )
      .sort((a, b) => (activeXPtsMap[b.id] ?? 0) - (activeXPtsMap[a.id] ?? 0))
      .slice(0, 25);
  }, [
    selectedPlayerId,
    activeSim,
    elements,
    elementsMap,
    getSellPrice,
    search,
    activeXPtsMap,
  ]);

  function applyTransferIn(inId: number) {
    if (!selectedPlayerId || !activeSim) return;
    const outId = selectedPlayerId;
    updateGw(activeGw, (g) => {
      // If outId was itself transferred in earlier in this same GW, replace that transfer
      const existingIdx = g.transfers.findIndex((t) => t.in === outId);
      const nextTransfers =
        existingIdx >= 0
          ? g.transfers.map((t, i) =>
              i === existingIdx ? { out: t.out, in: inId } : t,
            )
          : [...g.transfers, { out: outId, in: inId }];
      return {
        ...g,
        transfers: nextTransfers,
        starters: activeSim.starters.map((id) => (id === outId ? inId : id)),
        bench: activeSim.bench.map((id) => (id === outId ? inId : id)),
        captainId: activeSim.captainId === outId ? inId : activeSim.captainId,
        viceId: activeSim.viceId === outId ? inId : activeSim.viceId,
      };
    });
    setTransferModalOpen(false);
    setSelectedPlayerId(null);
    setSearch("");
  }

  async function savePlan() {
    const name = planName.trim() || `Plan ${saved.length + 1}`;
    setSaveMsg(null);
    const res = await fetch("/api/plans", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        entryId,
        name,
        data: plan,
        projectedPoints: Math.round(totalProjected * 10) / 10,
      }),
    });
    const body = await res.json();
    if (!res.ok) {
      setSaveMsg(body.error ?? "Could not save.");
    } else {
      setSaveMsg(`Saved "${name}".`);
      setPlanName("");
      await loadSaved();
    }
  }

  if (!activePlanGw || !activeSim) {
    return <ErrorBox message="No plannable gameweeks left this season." />;
  }

  const newInThisGw = new Set(activePlanGw.transfers.map((t) => t.in));
  const benchLabels = ["1. GK", "2. 1st Sub", "3. 2nd Sub", "4. 3rd Sub"];

  const toPitchCard = (id: number, benchIdx?: number): PitchCardItem | null => {
    const el = elementsMap.get(id);
    if (!el) return null;
    const team = teamsMap.get(el.team);
    const xp = activeXPtsMap[id] ?? 0;
    const isCap = activeSim.captainId === id;
    const isVice = activeSim.viceId === id;
    const isTC = activePlanGw.chip === "3xc" && isCap;
    const isBench = benchIdx !== undefined;
    const mult = !isBench && isCap ? (isTC ? 3 : 2) : 1;
    const sellP = getSellPrice(id);

    return {
      element: el,
      team,
      isCaptain: isCap,
      isViceCaptain: isVice,
      isTripleCaptain: isTC,
      isNew: newInThisGw.has(id),
      benchLabel: isBench ? benchLabels[benchIdx] : undefined,
      primaryLabel: `${(xp * mult).toFixed(1)} xPts`,
      primaryTone: isCap ? "green" : newInThisGw.has(id) ? "amber" : "white",
      secondaryLabel: `Sell ${formatPrice(sellP)}`,
      selected: selectedPlayerId === id,
      onClick: () => {
        // If a player is already selected and user taps a valid swap partner (starter <-> bench), swap immediately!
        if (selectedPlayerId && selectedPlayerId !== id) {
          const selInStarters = activeSim.starters.includes(selectedPlayerId);
          const tapInStarters = activeSim.starters.includes(id);
          if (selInStarters !== tapInStarters) {
            const stId = selInStarters ? selectedPlayerId : id;
            const bId = selInStarters ? id : selectedPlayerId;
            swapStarterAndBench(stId, bId);
            return;
          }
        }
        setSelectedPlayerId(selectedPlayerId === id ? null : id);
      },
    };
  };

  const pitchStarters = activeSim.starters
    .map((id) => toPitchCard(id))
    .filter((c): c is PitchCardItem => c !== null);
  const pitchBench = activeSim.bench
    .map((id, i) => toPitchCard(id, i))
    .filter((c): c is PitchCardItem => c !== null);

  const selectedEl = selectedPlayerId ? elementsMap.get(selectedPlayerId) : null;
  const selectedIsStarter = selectedPlayerId
    ? activeSim.starters.includes(selectedPlayerId)
    : false;
  const selectedBenchIdx = selectedPlayerId
    ? activeSim.bench.indexOf(selectedPlayerId)
    : -1;

  return (
    <div className="flex flex-col gap-3">
      {/* Top Summary & Comparison vs Auto Optimized */}
      <Card className="!p-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
              {sim.length}-GW Manual Plan Projection (Estimate)
            </p>
            <div className="flex items-baseline gap-2">
              <p className="text-2xl font-extrabold text-[#84d21c]">
                {totalProjected.toFixed(1)} xPts
              </p>
              <span
                className={`text-xs font-bold ${
                  diffVsAuto >= 0 ? "text-[#84d21c]" : "text-amber-300"
                }`}
              >
                ({diffVsAuto >= 0 ? "+" : ""}
                {diffVsAuto.toFixed(1)} vs Auto Optimized{" "}
                {autoTotalProjected.toFixed(1)} xPts)
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            {totalErrors > 0 ? (
              <Pill className="bg-rose-500/20 text-rose-200">
                {totalErrors} issue{totalErrors > 1 ? "s" : ""}
              </Pill>
            ) : (
              <Pill className="bg-[#84d21c]/15 text-[#84d21c]">✓ Valid</Pill>
            )}
          </div>
        </div>

        {/* Section 6 Buttons: Load optimizer plan & Reset */}
        <div className="mt-2.5 flex flex-wrap gap-2 border-t border-white/10 pt-2.5">
          <button
            type="button"
            onClick={() => {
              setPlan(buildOptimizerPlan());
              setSelectedPlayerId(null);
            }}
            className="rounded-xl bg-[#84d21c] px-3 py-1.5 text-xs font-extrabold text-[#000000] transition hover:bg-[#bbe682]"
          >
            ⚡ Load optimizer plan
          </button>
          <button
            type="button"
            onClick={() => {
              setPlan(buildResetPlan());
              setSelectedPlayerId(null);
            }}
            className="rounded-xl border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-200 hover:bg-white/10"
          >
            ↺ Reset
          </button>
          <button
            type="button"
            onClick={() => {
              updateGw(activeGw, (g) => ({ ...g, transfers: [], chip: null }));
              setSelectedPlayerId(null);
            }}
            className="rounded-xl border border-amber-400/40 bg-amber-400/10 px-3 py-1.5 text-xs font-bold text-amber-200 hover:bg-amber-400/20"
          >
            Roll GW{activeGw} Transfer
          </button>
        </div>
      </Card>

      {/* 5-GW Selector Strip */}
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {sim.map((g) => (
          <button
            key={g.gw}
            type="button"
            onClick={() => {
              setActiveGw(g.gw);
              setSelectedPlayerId(null);
            }}
            className={`shrink-0 rounded-xl border px-3 py-2 text-left transition ${
              activeGw === g.gw
                ? "border-[#84d21c] bg-[#84d21c]/15"
                : g.errors.length > 0
                  ? "border-rose-500/50 bg-rose-500/5"
                  : "border-white/10 bg-white/[0.04]"
            }`}
          >
            <p className="text-xs font-extrabold">GW{g.gw}</p>
            <p className="text-[10px] font-semibold text-[#84d21c]">
              {g.projected.toFixed(1)} xPts
            </p>
            <p className="text-[9px] text-slate-400">
              FT {g.ftBefore}→{g.ftAfter}
              {g.hits > 0 ? ` · −${g.hits}` : ""}
            </p>
          </button>
        ))}
      </div>

      {/* Active GW Status & Chip Bar */}
      <Card className="!p-3">
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-sm font-extrabold">GW{activeGw} Squad</span>
            <Pill className="bg-white/10 text-slate-300">
              {activeSim.formation}
            </Pill>
          </div>
          <div className="flex flex-wrap gap-1.5 text-[10px]">
            <Pill className="bg-white/10 text-slate-200">
              Bank {formatPrice(activeSim.bank)}
            </Pill>
            <Pill className="bg-white/10 text-slate-200">
              FTs: {activeSim.ftBefore} now → {activeSim.ftAfter} next
            </Pill>
            {activeSim.hits > 0 ? (
              <Pill className="bg-rose-500/20 text-rose-200">
                −{activeSim.hits} hit
              </Pill>
            ) : null}
          </div>
        </div>

        {/* Chip Selector */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Chip:
          </span>
          <button
            type="button"
            onClick={() => updateGw(activeGw, (g) => ({ ...g, chip: null }))}
            className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${
              activePlanGw.chip === null
                ? "bg-[#84d21c] text-[#000000]"
                : "border border-white/15 text-slate-300"
            }`}
          >
            None
          </button>
          {CHIP_OPTIONS.map((c) => {
            const unavailable = chipUsedAlready(c, activeGw);
            const placedElsewhere = plan.gws.some(
              (g) =>
                g.gw !== activeGw &&
                g.chip === c &&
                (g.gw <= 19) === (activeGw <= 19),
            );
            return (
              <button
                key={c}
                type="button"
                disabled={unavailable || placedElsewhere}
                onClick={() => updateGw(activeGw, (g) => ({ ...g, chip: c }))}
                className={`rounded-full px-2.5 py-1 text-[10px] font-bold disabled:opacity-30 ${
                  activePlanGw.chip === c
                    ? "bg-fuchsia-500 text-white"
                    : "border border-white/15 text-slate-300"
                }`}
              >
                {chipLabel(c)}
              </button>
            );
          })}
        </div>

        {/* Validation Errors */}
        {activeSim.errors.length > 0 ? (
          <div className="mt-2 rounded-xl border border-rose-500/40 bg-rose-500/10 p-2">
            {activeSim.errors.map((err, i) => (
              <p key={i} className="text-xs text-rose-200">
                • {err}
              </p>
            ))}
          </div>
        ) : null}
      </Card>

      {/* Selected Player Action Bar (Transfer, Set Captain/Vice, Swap XI/Bench, Reorder Bench) */}
      {selectedEl ? (
        <Card className="border-[#84d21c]/50 bg-[#1c1532] !p-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <PlayerPhoto
                code={selectedEl.code}
                alt={selectedEl.web_name}
                className="h-10 w-8 object-cover"
              />
              <div>
                <p className="text-sm font-extrabold text-white">
                  {selectedEl.web_name}{" "}
                  <span className="text-xs font-normal text-slate-400">
                    ({POSITIONS[selectedEl.element_type]} · Sell{" "}
                    {formatPrice(getSellPrice(selectedEl.id))} · Now{" "}
                    {formatPrice(selectedEl.now_cost)})
                  </span>
                </p>
                <p className="text-[10px] text-slate-300">
                  GW{activeGw}:{" "}
                  <strong className="text-[#84d21c]">
                    {(activeXPtsMap[selectedEl.id] ?? 0).toFixed(1)} xPts
                  </strong>{" "}
                  (Estimate) · tap another player on {selectedIsStarter ? "Bench" : "Pitch"} to swap
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setSelectedPlayerId(null)}
              className="rounded-full bg-white/10 px-2 py-1 text-xs text-slate-300"
            >
              ✕
            </button>
          </div>

          <div className="mt-2 flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => setTransferModalOpen(true)}
              className="rounded-lg bg-[#84d21c] px-3 py-1.5 text-xs font-extrabold text-[#000000]"
            >
              🔁 Transfer Out
            </button>
            {selectedIsStarter ? (
              <>
                <button
                  type="button"
                  onClick={() => {
                    updateGw(activeGw, (g) => ({
                      ...g,
                      starters: [...activeSim.starters],
                      bench: [...activeSim.bench],
                      captainId: selectedEl.id,
                    }));
                    setSelectedPlayerId(null);
                  }}
                  className="rounded-lg border border-[#84d21c]/40 bg-[#84d21c]/15 px-2.5 py-1.5 text-xs font-bold text-[#84d21c]"
                >
                  Ⓒ Make Captain
                </button>
                <button
                  type="button"
                  onClick={() => {
                    updateGw(activeGw, (g) => ({
                      ...g,
                      starters: [...activeSim.starters],
                      bench: [...activeSim.bench],
                      viceId: selectedEl.id,
                    }));
                    setSelectedPlayerId(null);
                  }}
                  className="rounded-lg border border-white/15 bg-white/10 px-2.5 py-1.5 text-xs font-bold text-slate-200"
                >
                  Ⓥ Make Vice
                </button>
              </>
            ) : selectedBenchIdx >= 1 ? (
              <>
                <button
                  type="button"
                  disabled={selectedBenchIdx <= 1}
                  onClick={() => moveBenchSlot(selectedBenchIdx, -1)}
                  className="rounded-lg border border-white/15 bg-white/10 px-2.5 py-1.5 text-xs font-bold text-slate-200 disabled:opacity-30"
                >
                  ← Move Bench Left
                </button>
                <button
                  type="button"
                  disabled={selectedBenchIdx >= 3}
                  onClick={() => moveBenchSlot(selectedBenchIdx, 1)}
                  className="rounded-lg border border-white/15 bg-white/10 px-2.5 py-1.5 text-xs font-bold text-slate-200 disabled:opacity-30"
                >
                  Move Bench Right →
                </button>
              </>
            ) : null}
          </div>
        </Card>
      ) : (
        <p className="px-1 text-[11px] text-slate-400">
          💡 Tap any player on the pitch or bench below to Transfer Out, set Captain/Vice, swap XI ↔ Bench, or reorder bench slots.
        </p>
      )}

      {/* Interactive Pitch View */}
      <Pitch
        starters={pitchStarters}
        bench={pitchBench}
        benchTitle="Bench (tap a bench player then a starter to swap, or reorder slots)"
      />

      {/* Active GW Planned Transfers List */}
      {activePlanGw.transfers.length > 0 ? (
        <Card className="!p-3">
          <p className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            GW{activeGw} Planned Transfers ({activePlanGw.transfers.length})
          </p>
          <div className="flex flex-col gap-1.5">
            {activePlanGw.transfers.map((t, i) => {
              const outEl = elementsMap.get(t.out);
              const inEl = elementsMap.get(t.in);
              return (
                <div
                  key={i}
                  className="flex items-center justify-between rounded-lg bg-white/[0.05] px-2.5 py-1.5 text-xs"
                >
                  <span>
                    <span className="font-bold text-rose-300">
                      {outEl?.web_name}
                    </span>{" "}
                    (sell {formatPrice(getSellPrice(t.out))}) →{" "}
                    <span className="font-bold text-[#84d21c]">
                      {inEl?.web_name}
                    </span>{" "}
                    (buy {formatPrice(inEl?.now_cost ?? 0)})
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      updateGw(activeGw, (g) => ({
                        ...g,
                        transfers: g.transfers.filter((_, j) => j !== i),
                        starters: undefined,
                        bench: undefined,
                      }))
                    }
                    className="text-slate-400 hover:text-rose-300"
                  >
                    ✕
                  </button>
                </div>
              );
            })}
          </div>
        </Card>
      ) : null}

      {/* Auto-loaded Transfer Replacement Drawer/Modal */}
      {transferModalOpen && selectedEl ? (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/75 backdrop-blur-sm sm:items-center"
          onClick={() => setTransferModalOpen(false)}
        >
          <div
            className="max-h-[82dvh] w-full max-w-lg overflow-y-auto rounded-t-3xl border border-white/15 bg-[#171227] p-4 pb-8 shadow-2xl sm:rounded-3xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-3 flex items-center justify-between">
              <div>
                <p className="text-xs font-extrabold text-white">
                  Replace {selectedEl.web_name} ({POSITIONS[selectedEl.element_type]})
                </p>
                <p className="text-[11px] text-slate-400">
                  Max budget:{" "}
                  <strong className="text-[#84d21c]">
                    {formatPrice(getSellPrice(selectedEl.id) + activeSim.bank)}
                  </strong>{" "}
                  (Sell {formatPrice(getSellPrice(selectedEl.id))} + Bank{" "}
                  {formatPrice(activeSim.bank)}) · filtered by club limit (≤3)
                </p>
              </div>
              <button
                type="button"
                onClick={() => setTransferModalOpen(false)}
                className="rounded-full bg-white/10 px-2.5 py-1 text-xs text-slate-300"
              >
                ✕
              </button>
            </div>

            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search replacement by name…"
              className="mb-2.5 w-full rounded-xl border border-white/15 bg-black/30 px-3 py-2 text-xs text-white placeholder:text-slate-500 focus:border-[#84d21c] focus:outline-none"
            />

            <div className="flex flex-col gap-1.5">
              {replacementCandidates.map((c) => {
                const t = teamsMap.get(c.team);
                const xp = activeXPtsMap[c.id] ?? 0;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => applyTransferIn(c.id)}
                    className="flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-left text-xs hover:bg-white/[0.1]"
                  >
                    <div className="flex items-center gap-2">
                      <PlayerPhoto
                        code={c.code}
                        alt={c.web_name}
                        className="h-8 w-6 object-cover"
                      />
                      <TeamBadge
                        code={t?.code}
                        shortName={t?.short_name}
                        className="h-4 w-4"
                      />
                      <div>
                        <p className="font-bold text-white">{c.web_name}</p>
                        <p className="text-[10px] text-slate-400">
                          {t?.short_name} · {formatPrice(c.now_cost)} · form{" "}
                          {c.form}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="font-extrabold text-[#84d21c]">
                        {xp.toFixed(1)} xPts
                      </span>
                      <p className="text-[9px] text-slate-400">
                        {c.selected_by_percent}% own
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      ) : null}

      {/* Save & Compare up to 3 Plans */}
      <Card>
        <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
          Save &amp; Compare Plans ({saved.length}/3)
        </p>
        <div className="mb-2 flex gap-2">
          <input
            value={planName}
            onChange={(e) => setPlanName(e.target.value)}
            placeholder="Plan name (e.g. Roll to GW7)…"
            className="min-w-0 flex-1 rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-xs focus:border-[#84d21c] focus:outline-none"
          />
          <button
            type="button"
            onClick={() => void savePlan()}
            className="rounded-lg bg-[#84d21c] px-4 text-xs font-extrabold text-[#000000]"
          >
            Save Plan
          </button>
        </div>
        {saveMsg ? <p className="mb-2 text-xs text-amber-200">{saveMsg}</p> : null}
        <div className="flex flex-col gap-1.5">
          {saved.map((s) => {
            const deltaVsAuto =
              Math.round((s.projectedPoints - autoTotalProjected) * 10) / 10;
            return (
              <div
                key={s.id}
                className="flex items-center justify-between rounded-lg bg-white/[0.05] px-3 py-2 text-xs"
              >
                <div>
                  <p className="font-bold text-white">{s.name}</p>
                  <p className="text-[10px] text-slate-400">
                    {s.data.gws.reduce((n, g) => n + g.transfers.length, 0)}{" "}
                    transfers ·{" "}
                    {s.data.gws
                      .filter((g) => g.chip)
                      .map((g) => `${chipLabel(g.chip)} GW${g.gw}`)
                      .join(", ") || "no chips"}{" "}
                    ·{" "}
                    <span
                      className={
                        deltaVsAuto >= 0 ? "text-[#84d21c]" : "text-amber-300"
                      }
                    >
                      {deltaVsAuto >= 0 ? "+" : ""}
                      {deltaVsAuto.toFixed(1)} vs Auto
                    </span>
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-[#84d21c]">
                    {s.projectedPoints.toFixed(1)} xPts
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setPlan(s.data);
                      setActiveGw(s.data.gws[0]?.gw ?? nextGw);
                    }}
                    className="rounded bg-white/10 px-2 py-1 text-[10px] font-semibold"
                  >
                    Load
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      await fetch(`/api/plans?id=${s.id}&entry=${entryId}`, {
                        method: "DELETE",
                      });
                      await loadSaved();
                    }}
                    className="text-slate-500 hover:text-rose-300"
                  >
                    ✕
                  </button>
                </div>
              </div>
            );
          })}
          {saved.length === 0 ? (
            <p className="text-xs text-slate-500">
              No saved plans yet — save up to 3 plans to compare against each other and the Auto Optimized plan.
            </p>
          ) : null}
        </div>
      </Card>
    </div>
  );
}
