"use client";

import { useEffect, useMemo, useState } from "react";
import { Card, ErrorBox, Pill, Spinner } from "@/components/ui";
import { PlayerPhoto } from "@/components/PlayerPhoto";
import { TeamBadge } from "@/components/TeamBadge";
import { useJson } from "@/lib/useJson";
import { formatPrice } from "@/lib/helpers";
import type { PriceResponse, PriceRow } from "@/app/api/price/route";
import type { SlimElement, SlimTeam } from "@/lib/types";

const WATCHLIST_KEY = "fpl-price-watchlist";

function loadWatchlist(): number[] {
  try {
    return JSON.parse(localStorage.getItem(WATCHLIST_KEY) ?? "[]") as number[];
  } catch {
    return [];
  }
}

export function PriceView({
  squadIds,
  elements,
  elementsMap,
  teamsMap,
}: {
  squadIds: number[];
  elements: SlimElement[];
  elementsMap: Map<number, SlimElement>;
  teamsMap: Map<number, SlimTeam>;
}) {
  const [watchlist, setWatchlist] = useState<number[]>([]);
  const [search, setSearch] = useState("");

  useEffect(() => setWatchlist(loadWatchlist()), []);

  const allIds = useMemo(
    () => [...new Set([...squadIds, ...watchlist])],
    [squadIds, watchlist],
  );
  const url =
    allIds.length > 0 ? `/api/price?ids=${allIds.join(",")}` : "/api/price";
  const { data, error, loading, refresh } = useJson<PriceResponse>(url, 120_000);

  const squadSet = useMemo(() => new Set(squadIds), [squadIds]);

  const { risers, fallers, alerts } = useMemo(() => {
    const rows = data?.rows ?? [];
    const r = rows
      .filter((x) => x.direction === "rise" || x.netTransfersEvent > 0)
      .sort((a, b) => b.probability - a.probability);
    const f = rows
      .filter((x) => x.direction === "fall" || (x.direction !== "rise" && x.netTransfersEvent <= 0))
      .sort((a, b) => b.probability - a.probability);
    const al = rows
      .filter(
        (x) =>
          squadSet.has(x.id) && x.probability >= 0.55 && x.direction !== "hold",
      )
      .sort((a, b) => b.probability - a.probability);
    return { risers: r, fallers: f, alerts: al };
  }, [data, squadSet]);

  const searchResults = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (q.length < 2) return [];
    return elements
      .filter((e) => e.element_type <= 4 && e.web_name.toLowerCase().includes(q))
      .slice(0, 6);
  }, [search, elements]);

  function toggleWatch(id: number) {
    setWatchlist((prev) => {
      const next = prev.includes(id)
        ? prev.filter((x) => x !== id)
        : [...prev, id].slice(-25);
      localStorage.setItem(WATCHLIST_KEY, JSON.stringify(next));
      return next;
    });
  }

  if (loading && !data) return <Spinner label="Crunching price signals…" />;
  if (error && !data) return <ErrorBox message={error} onRetry={refresh} />;
  if (!data) return null;

  const renderRow = (r: PriceRow, isRise: boolean) => {
    const el = elementsMap.get(r.id);
    const team = el ? teamsMap.get(el.team) : undefined;
    const inSquad = squadSet.has(r.id);
    const isWatched = watchlist.includes(r.id);
    const pct = Math.round(r.probability * 100);

    return (
      <div
        key={r.id}
        className={`flex items-center justify-between gap-2 rounded-xl border px-2.5 py-2 text-xs transition ${
          inSquad
            ? "border-[#84d21c]/50 bg-[#84d21c]/10 shadow-sm"
            : "border-white/10 bg-white/[0.04]"
        }`}
      >
        <div className="flex min-w-0 flex-1 items-center gap-2">
          {el ? (
            <PlayerPhoto
              code={el.code}
              alt={r.webName}
              className="h-9 w-7 shrink-0 object-cover"
            />
          ) : null}
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-1">
              <TeamBadge
                code={team?.code}
                shortName={team?.short_name}
                className="h-3.5 w-3.5 shrink-0"
              />
              <span className="truncate font-bold text-white">{r.webName}</span>
              {inSquad ? (
                <span className="rounded bg-[#84d21c] px-1 py-0.5 text-[8px] font-extrabold text-[#000000]">
                  MY SQUAD
                </span>
              ) : isWatched ? (
                <button
                  onClick={() => toggleWatch(r.id)}
                  className="text-[9px] text-slate-400 underline"
                >
                  unwatch
                </button>
              ) : null}
            </div>
            <p className="truncate text-[10px] text-slate-400">
              {formatPrice(r.nowCost)} · Net{" "}
              <span
                className={
                  r.netTransfersEvent >= 0 ? "text-[#84d21c]" : "text-rose-300"
                }
              >
                {r.netTransfersEvent >= 0 ? "+" : ""}
                {(r.netTransfersEvent / 1000).toFixed(1)}k
              </span>{" "}
              · {el?.selected_by_percent ?? r.selectedByPercent}% own
            </p>
          </div>
        </div>

        <div className="shrink-0 text-right">
          <div
            className={`text-xs font-extrabold ${
              isRise ? "text-[#84d21c]" : "text-rose-400"
            }`}
          >
            {isRise ? "▲" : "▼"} {pct}%{" "}
            <span className="text-[8px] font-normal text-slate-400">Est.</span>
          </div>
          <div className="text-[9px] text-slate-400">{r.timingWindow}</div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col gap-3">
      {/* Squad Price Alerts */}
      {alerts.length > 0 ? (
        <div className="rounded-2xl border border-amber-400/40 bg-amber-400/10 p-3">
          <p className="mb-1 text-xs font-bold uppercase tracking-wider text-amber-300">
            ⚠ Squad Price Change Alerts (Estimate)
          </p>
          {alerts.map((a) => (
            <p key={a.id} className="text-xs text-amber-100">
              <span className="font-bold">{a.webName}</span> likely to{" "}
              <span
                className={
                  a.direction === "rise"
                    ? "font-bold text-[#84d21c]"
                    : "font-bold text-rose-300"
                }
              >
                {a.direction}
              </span>{" "}
              — {Math.round(a.probability * 100)}% confidence · {a.timingWindow}
            </p>
          ))}
        </div>
      ) : null}

      {/* Running Accuracy & Watchlist Search */}
      <Card className="!p-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
              Price Model Running Accuracy
            </p>
            <p className="text-lg font-extrabold text-[#84d21c]">
              {data.accuracy.pct !== null ? `${data.accuracy.pct}%` : "Calibrating"}
              <span className="ml-2 text-xs font-normal text-slate-400">
                ({data.accuracy.correct}✓ / {data.accuracy.wrong}✗ ·{" "}
                {data.accuracy.pending} pending)
              </span>
            </p>
          </div>
          {data.snapshotAgeMin !== null ? (
            <Pill className="bg-white/10 text-slate-300">
              snapshot {data.snapshotAgeMin}m ago
            </Pill>
          ) : null}
        </div>
        <div className="mt-2">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Add any player to price watchlist…"
            className="w-full rounded-lg border border-white/15 bg-black/30 px-3 py-1.5 text-xs placeholder:text-slate-500 focus:border-[#84d21c] focus:outline-none"
          />
          {searchResults.length > 0 ? (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {searchResults.map((e) => (
                <button
                  key={e.id}
                  onClick={() => {
                    toggleWatch(e.id);
                    setSearch("");
                  }}
                  className="rounded-full border border-white/15 px-2.5 py-1 text-xs font-semibold text-slate-200 hover:bg-white/10"
                >
                  + {e.web_name} {formatPrice(e.now_cost)}
                </button>
              ))}
            </div>
          ) : null}
        </div>
      </Card>

      {/* Section 3: Two Columns Side by Side (stack vertically on small phones) */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {/* LEFT = Likely to Rise */}
        <Card className="!p-3">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-[#84d21c]">
              ▲ Likely to Rise
            </h3>
            <span className="text-[9px] text-slate-400">Sorted by prob %</span>
          </div>
          <div className="flex flex-col gap-1.5">
            {risers.length === 0 ? (
              <p className="text-xs text-slate-500">No risers right now.</p>
            ) : (
              risers.map((r) => renderRow(r, true))
            )}
          </div>
        </Card>

        {/* RIGHT = Likely to Fall */}
        <Card className="!p-3">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-rose-400">
              ▼ Likely to Fall
            </h3>
            <span className="text-[9px] text-slate-400">Sorted by prob %</span>
          </div>
          <div className="flex flex-col gap-1.5">
            {fallers.length === 0 ? (
              <p className="text-xs text-slate-500">No fallers right now.</p>
            ) : (
              fallers.map((r) => renderRow(r, false))
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
