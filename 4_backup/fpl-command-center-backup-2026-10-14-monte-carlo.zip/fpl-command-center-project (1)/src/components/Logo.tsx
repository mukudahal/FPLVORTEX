import Image from "next/image";
import Link from "next/link";
import { LOGO_HEIGHT, LOGO_WIDTH } from "@/lib/logoMeta";

/** Fixed pixel sizes derived from the real artwork's aspect ratio (1774×860). */
function dims(width: number) {
  return { width, height: Math.round((width * LOGO_HEIGHT) / LOGO_WIDTH) };
}
const HEADER = dims(132);
const HERO = dims(360);

/**
 * The artwork already contains the "FPLVORTEX" channel name,
 * so the logo is shown on its own — never with a repeated text wordmark.
 */
export function Logo({
  size = "header",
  className = "",
}: {
  size?: "header" | "hero";
  className?: string;
}) {
  if (size === "hero") {
    return (
      <Image
        src="/logo.png"
        alt="FPL Vortex"
        width={HERO.width}
        height={HERO.height}
        priority
        className={`h-auto w-[300px] max-w-full drop-shadow-[0_0_28px_rgba(132,210,28,0.35)] sm:w-[360px] ${className}`}
      />
    );
  }

  return (
    <Link
      href="/"
      aria-label="FPL Vortex Home"
      className={`inline-flex shrink-0 items-center focus:outline-none ${className}`}
    >
      <Image
        src="/logo.png"
        alt="FPL Vortex"
        width={HEADER.width}
        height={HEADER.height}
        priority
        className="h-auto w-[112px] sm:w-[132px]"
      />
    </Link>
  );
}

export function TopHeader() {
  return (
    <header className="sticky top-0 z-30 border-b border-[#cda228]/35 bg-black/95 backdrop-blur-md">
      <div className="mx-auto flex w-full max-w-lg items-center justify-between gap-2 px-3 py-1.5">
        <Logo size="header" />
        <nav className="flex items-center gap-1 text-[11px] font-semibold text-slate-300">
          <Link
            href="/players"
            className="rounded-lg px-2 py-1 hover:bg-white/5 hover:text-[#dfc373]"
          >
            Players
          </Link>
          <Link
            href="/fixtures"
            className="rounded-lg px-2 py-1 hover:bg-white/5 hover:text-[#dfc373]"
          >
            Fixtures
          </Link>
          <Link
            href="/status"
            className="rounded-lg border border-[#cda228]/50 bg-[#cda228]/15 px-2.5 py-1 text-[#dfc373] hover:bg-[#cda228]/25"
          >
            Status
          </Link>
        </nav>
      </div>
    </header>
  );
}

export function SocialFooter() {
  return (
    <footer className="mt-8 border-t border-[#cda228]/25 pt-4 pb-4 text-center">
      <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-bold">
        {/* Official YouTube logo + @FPLVORTEX */}
        <a
          href="https://www.youtube.com/@FPLVORTEX"
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/[0.05] px-3.5 py-1.5 text-slate-100 transition hover:border-[#FF0000]/60 hover:bg-white/[0.1]"
        >
          <svg viewBox="0 0 24 24" aria-hidden="true" className="h-4 w-4 shrink-0">
            <path
              fill="#FF0000"
              d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814z"
            />
            <path fill="#FFFFFF" d="M9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
          </svg>
          <span>@FPLVORTEX</span>
        </a>

        {/* Official X logo + FPLVORTEXM */}
        <a
          href="https://x.com/FPLVORTEXM"
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/[0.05] px-3.5 py-1.5 text-slate-100 transition hover:border-[#cda228]/60 hover:bg-white/[0.1]"
        >
          <svg
            viewBox="0 0 24 24"
            aria-hidden="true"
            fill="currentColor"
            className="h-3.5 w-3.5 shrink-0 text-white"
          >
            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
          </svg>
          <span>FPLVORTEXM</span>
        </a>
      </div>
      <p className="mt-2 text-[11px] text-slate-500">
        FPL Vortex · Live Fantasy Premier League Analytics &amp; MILP Optimizer
      </p>
    </footer>
  );
}
