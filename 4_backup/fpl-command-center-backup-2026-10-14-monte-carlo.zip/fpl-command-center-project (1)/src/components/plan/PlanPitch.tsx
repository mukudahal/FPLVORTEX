"use client";

import { PlayerPhoto } from "@/components/PlayerPhoto";
import { statusInfo } from "@/lib/helpers";
import { cellsFor, type FxCell, type PlanCtx, type XIResult } from "@/lib/planEngine";
import type { PlanPlayer, PlanTeam } from "@/lib/planTypes";
import { FixturePills, POS, SetPieceBadges, kitColor, money } from "./planUi";

interface PitchProps {
  ctx: PlanCtx;
  lineup: XIResult;
  fxMap: Map<string, FxCell[]>;
  teamsById: Map<number, PlanTeam>;
  idx: number;
  gw: number;
  slot: number | null;
  boughtNow: Set<number>; // transferred in during this gameweek
  boughtEver: Set<number>; // transferred in at any point up to this gameweek
  priceOf: (id: number) => number;
  showXp: boolean;
  onOpen: (id: number) => void;
  onSwap: (id: number) => void;
  onRemove: (id: number) => void;
}

function IconSwap() {
  return (
    <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M7 4v14M7 18l-3-3M7 18l3-3M17 20V6M17 6l-3 3M17 6l3 3" />
    </svg>
  );
}

function IconX() {
  return (
    <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" aria-hidden>
      <path d="M6 6l12 12M18 6L6 18" />
    </svg>
  );
}

function Card({
  p,
  props,
  dim,
}: {
  p: PlanPlayer;
  props: PitchProps;
  dim: boolean;
}) {
  const { ctx, lineup, fxMap, teamsById, idx, gw, slot, boughtNow, boughtEver, priceOf, showXp } = props;
  const team = teamsById.get(p.team);
  const c = kitColor(team?.short);
  const st = statusInfo(p.status);
  const xp = p.xp[idx] ?? 0;
  const slots: FxCell[][] = [0, 1, 2].map((k) => cellsFor(fxMap, p.team, gw + k));
  const selected = slot === p.id;
  const isNewNow = boughtNow.has(p.id);
  const isNew = boughtEver.has(p.id);
  void ctx;

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => props.onOpen(p.id)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          props.onOpen(p.id);
        }
      }}
      aria-label={`${p.name}, ${POS[p.type]}, ${xp.toFixed(1)} expected points`}
      className={`group relative flex w-[62px] shrink-0 cursor-pointer flex-col items-stretch transition sm:w-[84px] ${
        dim ? "pointer-events-none opacity-30 saturate-50" : ""
      }`}
    >
      <div
        className={`relative overflow-hidden rounded-lg border-2 transition ${
          selected
            ? "border-white shadow-[0_0_0_3px_rgba(132,210,28,0.55)]"
            : isNewNow
              ? "border-[#84d21c]"
              : isNew
                ? "border-[#84d21c]/50"
                : "border-white/35 group-hover:border-white/80"
        }`}
        style={{ background: `linear-gradient(165deg, ${c}, ${c}b3 55%, #0b1220)` }}
      >
        <PlayerPhoto code={p.code} alt={p.name} className="w-full" />

        {/* swap (top-left) + remove/cancel (top-right) */}
        <button
          type="button"
          aria-label={`Transfer out ${p.name}`}
          onClick={(e) => {
            e.stopPropagation();
            props.onSwap(p.id);
          }}
          className="absolute left-0.5 top-0.5 flex h-[18px] w-[18px] items-center justify-center rounded-full bg-black/75 text-white ring-1 ring-white/50 hover:bg-[#84d21c] hover:text-black"
        >
          <IconSwap />
        </button>
        <button
          type="button"
          aria-label={isNewNow ? `Cancel transfer of ${p.name}` : `Remove ${p.name}`}
          onClick={(e) => {
            e.stopPropagation();
            props.onRemove(p.id);
          }}
          className="absolute right-0.5 top-0.5 flex h-[18px] w-[18px] items-center justify-center rounded-full bg-black/75 text-white ring-1 ring-white/50 hover:bg-rose-500"
        >
          <IconX />
        </button>

        {lineup.captain === p.id || lineup.vice === p.id ? (
          <span className="absolute right-0.5 top-[26px] flex h-4 w-4 items-center justify-center rounded-full bg-black text-[9px] font-extrabold text-white ring-1 ring-white/80">
            {lineup.captain === p.id ? "C" : "V"}
          </span>
        ) : null}

        {st ? (
          <span className={`absolute left-0.5 top-[24px] rounded px-1 text-[8px] font-bold ${st.className}`}>
            {p.chance != null ? `${p.chance}%` : st.label}
          </span>
        ) : null}

        <div className="absolute bottom-5 left-0.5 flex gap-0.5">
          <SetPieceBadges p={p} tiny />
        </div>

        <div className="absolute inset-x-0 bottom-0 bg-black/65 py-0.5 text-center text-[10px] font-extrabold text-white sm:text-[11px]">
          {showXp ? <span className="text-[#bbe682]">{xp.toFixed(1)}</span> : <>£{money(priceOf(p.id))}</>}
        </div>
      </div>
      <div className="mt-0.5 overflow-hidden rounded-md bg-slate-950/90 ring-1 ring-white/10">
        <p className="truncate px-1 pt-0.5 text-center text-[10px] font-bold text-white sm:text-[11px]">{p.name}</p>
        <FixturePills slots={slots} teamsById={teamsById} />
      </div>
    </div>
  );
}

export function PlanPitch(props: PitchProps) {
  const { ctx, lineup, slot } = props;
  const slotType = slot !== null ? (ctx.players.get(slot)?.type ?? 0) : 0;

  const startersBy = (t: number) =>
    lineup.starters
      .map((id) => ctx.players.get(id))
      .filter((p): p is PlanPlayer => !!p && p.type === t);
  const bench = lineup.bench
    .map((id) => ctx.players.get(id))
    .filter((p): p is PlanPlayer => !!p);

  const row = (list: PlanPlayer[], key: string) => (
    <div key={key} className="relative z-10 flex items-start justify-around gap-1 px-1">
      {list.map((p) => (
        <Card
          key={p.id}
          p={p}
          props={props}
          dim={slot !== null && p.type !== slotType}
        />
      ))}
    </div>
  );

  return (
    <div
      className="relative overflow-hidden px-1 pb-3 pt-2"
      style={{
        background:
          "repeating-linear-gradient(180deg,#23a455 0px,#23a455 56px,#1f9a4f 56px,#1f9a4f 112px)",
      }}
    >
      {/* pitch markings */}
      <div className="pointer-events-none absolute inset-x-[22%] top-0 h-[17%] rounded-b-md border-2 border-t-0 border-white/45" />
      <div className="pointer-events-none absolute inset-x-[34%] top-0 h-[7%] border-2 border-t-0 border-white/45" />
      <div className="pointer-events-none absolute left-1/2 top-[11%] h-10 w-24 -translate-x-1/2 rounded-b-full border-2 border-t-0 border-white/45" />
      <div className="pointer-events-none absolute inset-x-0 top-[70%] h-[2px] bg-white/35" />
      <div className="pointer-events-none absolute left-1/2 top-[62%] h-32 w-32 -translate-x-1/2 rounded-full border-2 border-white/35 sm:h-44 sm:w-44" />

      {/* brand banners either side of the goal */}
      <div className="pointer-events-none relative z-0 mb-[-34px] flex items-start justify-between px-[7%] sm:mb-[-46px]">
        {["FPL VORTEX", "FPL VORTEX"].map((t, i) => (
          <span
            key={i}
            className="mt-3 -skew-x-6 bg-white px-3 py-1 text-[11px] font-black tracking-tight text-slate-900 shadow sm:text-base"
          >
            {t}
          </span>
        ))}
      </div>

      <div className="flex flex-col gap-3 sm:gap-5">
        {row(startersBy(1), "gk")}
        {row(startersBy(2), "def")}
        {row(startersBy(3), "mid")}
        {row(startersBy(4), "fwd")}

        <div className="relative z-10 mx-1 mt-2 rounded-2xl bg-[#04281a]/85 px-1 pb-2 pt-1.5 ring-1 ring-white/10">
          <div className="flex items-start justify-around gap-1">
            {bench.map((p) => (
              <div key={p.id} className="flex flex-col items-center gap-1">
                <span className="text-[9px] font-extrabold tracking-wider text-white/70">
                  {p.type === 1 ? "GK" : POS[p.type].slice(0, 3)}
                </span>
                <Card p={p} props={props} dim={slot !== null && p.type !== slotType} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
