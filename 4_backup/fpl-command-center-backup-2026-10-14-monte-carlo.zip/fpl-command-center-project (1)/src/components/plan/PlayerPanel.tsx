"use client";

import { useMemo, useState, type ReactNode } from "react";
import { PlayerPhoto } from "@/components/PlayerPhoto";
import { statusInfo } from "@/lib/helpers";
import { cellsFor, type FxCell, type PlanCtx } from "@/lib/planEngine";
import type { PlanPlayer, PlanTeam } from "@/lib/planTypes";
import { FdrCell, POS, SetPieceBadges, inputCls, money } from "./planUi";

export type SubTab = "players" | "watchlist" | "lab";
type SortKey = "gain" | "xp" | "xp5" | "price" | "owned" | "form";
type SetPieceFilter = "any" | "pen" | "fk" | "ck";

const PAGE = 40;
const TYPE_TABS = [
  { id: 0, label: "All" },
  { id: 1, label: "GK" },
  { id: 2, label: "Def" },
  { id: 3, label: "Mid" },
  { id: 4, label: "Fwd" },
];

export interface SlotInfo {
  player: PlanPlayer;
  sell: number; // tenths
  budget: number; // tenths available for the replacement
  gains: Map<number, number>; // legal candidate id -> horizon xP gain
  reasons: Map<number, string>; // illegal candidate id -> why
  bestId: number | null;
}

interface Props {
  ctx: PlanCtx;
  teams: PlanTeam[];
  teamsById: Map<number, PlanTeam>;
  fxMap: Map<string, FxCell[]>;
  gw: number;
  idx: number;
  squadSet: Set<number>;
  watch: Set<number>;
  slot: SlotInfo | null;
  sub: SubTab;
  onSub: (s: SubTab) => void;
  onOpen: (id: number) => void;
  onPick: (inId: number) => void;
  onClearSlot: () => void;
  lab: ReactNode;
}

export function PlayerPanel(p: Props) {
  const { ctx, slot } = p;
  const [typeFilter, setTypeFilter] = useState(0);
  const [teamFilter, setTeamFilter] = useState(0);
  const [maxPrice, setMaxPrice] = useState(16);
  const [minPrice, setMinPrice] = useState(0);
  const [search, setSearch] = useState("");
  const [setPiece, setSetPiece] = useState<SetPieceFilter>("any");
  const [sortKey, setSortKey] = useState<SortKey>("xp");
  const [onlyLegal, setOnlyLegal] = useState(true);
  const [limit, setLimit] = useState(PAGE);

  const slotId = slot?.player.id ?? null;
  // entering transfer mode: lock to the position and rank by plan gain.
  // (Adjusting state during render, per React docs, instead of in an effect.)
  const [seenSlot, setSeenSlot] = useState<number | null>(null);
  if (slotId !== seenSlot) {
    setSeenSlot(slotId);
    if (slotId !== null) {
      setTypeFilter(ctx.players.get(slotId)?.type ?? 0);
      setSortKey("gain");
      setTeamFilter(0);
      setSearch("");
      setLimit(PAGE);
    } else {
      setSortKey((k) => (k === "gain" ? "xp" : k));
    }
  }

  const reset = () => {
    setTypeFilter(0);
    setTeamFilter(0);
    setMaxPrice(16);
    setMinPrice(0);
    setSearch("");
    setSetPiece("any");
    setSortKey("xp");
    setLimit(PAGE);
  };

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    const all = [...ctx.players.values()];
    const base =
      p.sub === "watchlist" ? all.filter((x) => p.watch.has(x.id)) : all;
    const list = base.filter((x) => {
      if (slot) {
        if (x.type !== slot.player.type || p.squadSet.has(x.id)) return false;
        if (onlyLegal && slot.reasons.has(x.id)) return false;
      } else if (typeFilter !== 0 && x.type !== typeFilter) return false;
      if (teamFilter !== 0 && x.team !== teamFilter) return false;
      if (x.cost > maxPrice * 10 + 0.001 || x.cost < minPrice * 10 - 0.001) return false;
      if (q && !x.name.toLowerCase().includes(q)) return false;
      if (setPiece === "pen" && x.pen !== 1) return false;
      if (setPiece === "fk" && x.fk !== 1) return false;
      if (setPiece === "ck" && x.ck !== 1) return false;
      return true;
    });
    const score = (x: PlanPlayer): number => {
      switch (sortKey) {
        case "gain":
          return slot?.gains.get(x.id) ?? -999;
        case "xp":
          return x.xp[p.idx] ?? 0;
        case "xp5":
          return x.xp.slice(p.idx, p.idx + 5).reduce((s, v) => s + v, 0);
        case "price":
          return x.cost;
        case "owned":
          return x.owned;
        case "form":
          return x.form;
      }
    };
    return list.sort((a, b) => score(b) - score(a));
  }, [ctx, p.sub, p.watch, p.squadSet, p.idx, slot, onlyLegal, typeFilter, teamFilter, maxPrice, minPrice, search, setPiece, sortKey]);

  const priceOptions = useMemo(() => {
    const o: number[] = [];
    for (let v = 16; v >= 4; v -= 0.5) o.push(v);
    return o;
  }, []);

  const rowGrid =
    "grid grid-cols-[minmax(0,1fr)_36px_40px_140px] sm:grid-cols-[minmax(0,1fr)_46px_38px_42px_150px] items-center gap-2";

  const slotBest = slot?.bestId != null ? ctx.players.get(slot.bestId) : undefined;

  return (
    <div>
      {/* sub tabs */}
      <div className="mb-3 grid grid-cols-3 gap-1 rounded-2xl bg-black/40 p-1">
        {(
          [
            ["players", "Players"],
            ["watchlist", `Watchlist${p.watch.size ? ` (${p.watch.size})` : ""}`],
            ["lab", "Transfer Lab"],
          ] as [SubTab, string][]
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => p.onSub(id)}
            className={`rounded-xl py-2 text-xs font-bold transition ${
              p.sub === id
                ? "bg-[#cda228]/25 text-[#dfc373] ring-1 ring-[#cda228]/50"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {p.sub === "lab" ? (
        p.lab
      ) : (
        <>
          {slot ? (
            <div className="mb-3 rounded-2xl border border-[#84d21c]/40 bg-[#84d21c]/10 p-3 text-xs text-[#d9f2b0]">
              <div className="flex items-start justify-between gap-3">
                <p>
                  Replacing <b>{slot.player.name}</b> · sell £{money(slot.sell)}m ·{" "}
                  <b>£{money(slot.budget)}m available</b>. Ranked by projected gain over the next 5 gameweeks.
                </p>
                <button
                  type="button"
                  onClick={p.onClearSlot}
                  className="shrink-0 rounded-lg border border-white/25 px-2 py-1 font-bold text-white hover:bg-white/10"
                >
                  Cancel
                </button>
              </div>
              {slotBest ? (
                <button
                  type="button"
                  onClick={() => p.onPick(slotBest.id)}
                  className="mt-2 flex w-full items-center justify-between gap-2 rounded-xl bg-[#84d21c] px-3 py-2 text-left font-extrabold text-black hover:brightness-110"
                >
                  <span>
                    Best pick: {slotBest.name} (£{money(slotBest.cost)}m)
                  </span>
                  <span>+{(slot.gains.get(slotBest.id) ?? 0).toFixed(1)} xP · Transfer</span>
                </button>
              ) : (
                <p className="mt-2 font-semibold text-amber-200">
                  No affordable replacement improves your team over this window.
                </p>
              )}
              <label className="mt-2 flex items-center gap-2 font-semibold">
                <input
                  type="checkbox"
                  checked={onlyLegal}
                  onChange={(e) => setOnlyLegal(e.target.checked)}
                />
                Only players I can afford / fit under the 3-per-club limit
              </label>
            </div>
          ) : null}

          {!slot ? (
            <div className="mb-3 grid grid-cols-5 gap-1 rounded-2xl bg-black/40 p-1">
              {TYPE_TABS.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => {
                    setTypeFilter(t.id);
                    setLimit(PAGE);
                  }}
                  className={`rounded-xl py-2 text-xs font-bold transition ${
                    typeFilter === t.id
                      ? "bg-[#cda228]/25 text-[#dfc373] ring-1 ring-[#cda228]/50"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          ) : null}

          <div className="mb-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
            <Field label="Team" onReset={() => setTeamFilter(0)}>
              <select
                className={inputCls}
                value={teamFilter}
                onChange={(e) => {
                  setTeamFilter(Number(e.target.value));
                  setLimit(PAGE);
                }}
              >
                <option value={0}>All teams</option>
                {[...p.teams]
                  .sort((a, b) => a.name.localeCompare(b.name))
                  .map((t) => (
                    <option key={t.id} value={t.id} className="bg-slate-900">
                      {t.name}
                    </option>
                  ))}
              </select>
            </Field>
            <Field label="Max price" onReset={() => setMaxPrice(16)}>
              <select
                className={inputCls}
                value={maxPrice}
                onChange={(e) => {
                  setMaxPrice(Number(e.target.value));
                  setLimit(PAGE);
                }}
              >
                {priceOptions.map((v) => (
                  <option key={v} value={v} className="bg-slate-900">
                    £{v.toFixed(1)}m
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Min price" onReset={() => setMinPrice(0)}>
              <select
                className={inputCls}
                value={minPrice}
                onChange={(e) => {
                  setMinPrice(Number(e.target.value));
                  setLimit(PAGE);
                }}
              >
                <option value={0}>No minimum</option>
                {priceOptions
                  .slice()
                  .reverse()
                  .map((v) => (
                    <option key={v} value={v} className="bg-slate-900">
                      £{v.toFixed(1)}m
                    </option>
                  ))}
              </select>
            </Field>
            <Field label="Player name" onReset={() => setSearch("")}>
              <input
                className={inputCls}
                placeholder="Search"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setLimit(PAGE);
                }}
              />
            </Field>
            <Field label="Set pieces" onReset={() => setSetPiece("any")}>
              <select
                className={inputCls}
                value={setPiece}
                onChange={(e) => {
                  setSetPiece(e.target.value as SetPieceFilter);
                  setLimit(PAGE);
                }}
              >
                <option value="any">Any player</option>
                <option value="pen">Penalty takers</option>
                <option value="fk">Free-kick takers</option>
                <option value="ck">Corner takers</option>
              </select>
            </Field>
            <Field label="Sort by" onReset={() => setSortKey(slot ? "gain" : "xp")}>
              <select
                className={inputCls}
                value={sortKey}
                onChange={(e) => setSortKey(e.target.value as SortKey)}
              >
                {slot ? <option value="gain">Best for my plan</option> : null}
                <option value="xp">xP GW{p.gw}</option>
                <option value="xp5">xP next 5 GWs</option>
                <option value="price">Price (desc)</option>
                <option value="owned">Owned (desc)</option>
                <option value="form">Form</option>
              </select>
            </Field>
          </div>
          {!slot ? (
            <button
              type="button"
              onClick={reset}
              className="mb-2 text-[11px] font-bold text-rose-300 hover:text-rose-200"
            >
              Reset all filters
            </button>
          ) : null}

          {/* header */}
          <div
            className={`${rowGrid} rounded-t-2xl border-b border-white/10 bg-white/[0.04] px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-400`}
          >
            <span>Player</span>
            <span className="hidden text-center sm:block">Owned</span>
            <span className="text-center">xP {p.gw}</span>
            <span className="text-center">£</span>
            <span className="text-center">
              Next 5 · GW{p.gw}–{Math.min(38, p.gw + 4)}
            </span>
          </div>

          <div className="divide-y divide-white/5 rounded-b-2xl bg-black/20">
            {rows.slice(0, limit).map((x) => {
              const st = statusInfo(x.status);
              const out = x.status !== "a" && x.status !== "d";
              const nameCls = out ? "text-rose-400" : x.status === "d" ? "text-amber-300" : "text-white";
              const t = p.teamsById.get(x.team);
              const gain = slot?.gains.get(x.id);
              const reason = slot?.reasons.get(x.id);
              const inSquad = p.squadSet.has(x.id);
              return (
                <div
                  key={x.id}
                  role="button"
                  tabIndex={0}
                  title={reason}
                  onClick={() => (slot && !reason ? p.onPick(x.id) : p.onOpen(x.id))}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") (slot && !reason ? p.onPick(x.id) : p.onOpen(x.id));
                  }}
                  className={`${rowGrid} cursor-pointer px-3 py-2 transition hover:bg-white/[0.06] ${
                    inSquad ? "border-l-2 border-[#cda228] bg-[#cda228]/[0.06]" : ""
                  } ${reason ? "opacity-45" : ""}`}
                >
                  <div className="flex min-w-0 items-center gap-2">
                    <button
                      type="button"
                      aria-label={`Details for ${x.name}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        p.onOpen(x.id);
                      }}
                      className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-extrabold ${
                        st ? st.className : "bg-slate-600 text-white"
                      }`}
                      title={x.news || "Available"}
                    >
                      i
                    </button>
                    <div className="h-8 w-8 shrink-0 overflow-hidden rounded-md bg-white/10">
                      <PlayerPhoto code={x.code} alt={x.name} className="w-full" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1">
                        <p className={`truncate text-sm font-bold ${nameCls}`}>{x.name}</p>
                        {p.watch.has(x.id) ? <span className="text-[10px] text-[#f0cf62]">★</span> : null}
                      </div>
                      <div className="flex items-center gap-1">
                        <p className="truncate text-[10px] italic text-slate-400">
                          {POS[x.type]} · {t?.short}
                        </p>
                        <SetPieceBadges p={x} tiny />
                      </div>
                    </div>
                  </div>
                  <span className="hidden text-center text-xs text-slate-300 sm:block">
                    {x.owned.toFixed(1)}%
                  </span>
                  <span className="text-center text-sm font-bold text-[#bbe682]">
                    {(x.xp[p.idx] ?? 0).toFixed(1)}
                    {gain !== undefined ? (
                      <span className={`block text-[9px] ${gain >= 0 ? "text-emerald-300" : "text-rose-300"}`}>
                        {gain >= 0 ? "+" : ""}
                        {gain.toFixed(1)}
                      </span>
                    ) : null}
                  </span>
                  <span className="text-center text-xs font-bold text-slate-200">{money(x.cost)}</span>
                  <div className="flex justify-between">
                    {Array.from({ length: 5 }, (_, k) => {
                      const g = p.gw + k;
                      return (
                        <FdrCell
                          key={k}
                          cells={g > 38 ? null : cellsFor(p.fxMap, x.team, g)}
                          teamsById={p.teamsById}
                        />
                      );
                    })}
                  </div>
                </div>
              );
            })}
            {rows.length === 0 ? (
              <p className="p-6 text-center text-sm text-slate-400">
                {p.sub === "watchlist"
                  ? "Your watchlist is empty. Open a player and tap the star."
                  : "No players match these filters."}
              </p>
            ) : null}
          </div>

          <div className="mt-3 flex items-center justify-between gap-3 text-xs text-slate-400">
            <span>
              Showing {Math.min(limit, rows.length)} of {rows.length}
            </span>
            {rows.length > limit ? (
              <button
                type="button"
                onClick={() => setLimit(limit + PAGE)}
                className="rounded-xl border border-white/15 bg-white/5 px-4 py-2 font-bold text-slate-100 hover:bg-white/10"
              >
                Show more
              </button>
            ) : null}
          </div>
        </>
      )}
    </div>
  );
}

function Field({
  label,
  onReset,
  children,
}: {
  label: string;
  onReset: () => void;
  children: ReactNode;
}) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-slate-400">
        <span>{label}</span>
        <button type="button" onClick={onReset} className="text-rose-300/80 hover:text-rose-200">
          Reset
        </button>
      </div>
      {children}
    </div>
  );
}
