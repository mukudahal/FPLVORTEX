"use client";

import { useMemo, useState } from "react";
import { PlayerPhoto } from "@/components/PlayerPhoto";
import { fdrClasses, statusInfo } from "@/lib/helpers";
import {
  cellsFor,
  horizonXP,
  validateTransfer,
  type FxCell,
  type PlanCtx,
  type ReplayState,
} from "@/lib/planEngine";
import type { PlanPlayer, PlanTeam } from "@/lib/planTypes";
import { POS, SetPieceBadges, inputCls, money } from "./planUi";

interface Props {
  ctx: PlanCtx;
  player: PlanPlayer;
  state: ReplayState;
  teamsById: Map<number, PlanTeam>;
  fxMap: Map<string, FxCell[]>;
  idx: number;
  inSquad: boolean;
  boughtNow: boolean;
  sellPrice: number;
  watched: boolean;
  onWatch: () => void;
  onClose: () => void;
  onTransferOut: () => void;
  onCancel: () => void;
  onTransferIn: (outId: number) => void;
}

function Tile({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.04] px-2 py-2 text-center">
      <p className="text-[9px] font-bold uppercase tracking-wider text-slate-400">{label}</p>
      <p className="text-base font-extrabold text-white">{value}</p>
    </div>
  );
}

export function PlayerModal(p: Props) {
  const { ctx, player, state } = p;
  const [tab, setTab] = useState<"info" | "fixtures">("info");
  const team = p.teamsById.get(player.team);
  const st = statusInfo(player.status);

  // for a player not in the squad: which squad members could he replace?
  const options = useMemo(() => {
    if (p.inSquad) return [];
    const base = horizonXP(ctx, state.squad, p.idx, 5);
    return state.squad
      .filter((id) => ctx.players.get(id)?.type === player.type)
      .map((outId) => {
        const reason = validateTransfer(ctx, state, outId, player.id);
        let gain = 0;
        if (reason === null) {
          const next = [...state.squad];
          next[next.indexOf(outId)] = player.id;
          gain = horizonXP(ctx, next, p.idx, 5) - base;
        }
        return { outId, reason, gain };
      })
      .sort((a, b) => (a.reason ? 1 : 0) - (b.reason ? 1 : 0) || b.gain - a.gain);
  }, [ctx, state, player, p.inSquad, p.idx]);

  const firstLegal = options.find((o) => o.reason === null);
  const [chosen, setChosen] = useState<number | null>(null);
  const chosenId = chosen ?? firstLegal?.outId ?? options[0]?.outId ?? null;
  const chosenOpt = options.find((o) => o.outId === chosenId);

  return (
    <div
      className="fixed inset-0 z-[110] flex items-start justify-center overflow-y-auto bg-black/65 p-3 pt-16 backdrop-blur-sm"
      onClick={p.onClose}
      role="dialog"
      aria-modal="true"
      aria-label={`${player.name} details`}
    >
      <div
        className="w-full max-w-md rounded-3xl border border-white/15 bg-[#0b1220] p-4 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 shrink-0 overflow-hidden rounded-xl bg-white/10">
            <PlayerPhoto code={player.code} alt={player.name} className="w-full" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-base font-extrabold text-white">{player.name}</p>
            <p className="flex items-center gap-1 text-[11px] text-slate-400">
              {POS[player.type]} · {team?.short} <SetPieceBadges p={player} tiny />
            </p>
          </div>
          <button
            type="button"
            onClick={p.onWatch}
            aria-label={p.watched ? "Remove from watchlist" : "Add to watchlist"}
            className={`h-9 w-9 rounded-xl border text-lg ${p.watched ? "border-[#cda228]/60 bg-[#cda228]/20 text-[#f0cf62]" : "border-white/15 bg-white/5 text-slate-300"}`}
          >
            {p.watched ? "★" : "☆"}
          </button>
          <button
            type="button"
            onClick={p.onClose}
            aria-label="Close"
            className="h-9 w-9 rounded-xl border border-white/15 bg-white/5 text-slate-200 hover:bg-white/10"
          >
            ✕
          </button>
        </div>

        {player.news ? (
          <p className={`mt-3 rounded-xl px-3 py-2 text-xs font-semibold ${st ? st.className : "bg-white/5 text-slate-200"}`}>
            {player.news}
            {player.chance != null ? ` (${player.chance}% chance of playing)` : ""}
          </p>
        ) : null}

        <div className="mt-3 grid grid-cols-2 gap-1 rounded-xl bg-black/40 p-1 text-xs font-bold">
          {(
            [
              ["info", "Player info"],
              ["fixtures", "Fixtures"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={`rounded-lg py-2 ${tab === id ? "bg-[#cda228]/25 text-[#dfc373]" : "text-slate-400"}`}
            >
              {label}
            </button>
          ))}
        </div>

        {tab === "info" ? (
          <>
            <div className="mt-3 grid grid-cols-4 gap-2">
              <Tile label="Price" value={`£${money(player.cost)}`} />
              <Tile label="Owned" value={`${player.owned.toFixed(1)}%`} />
              <Tile label="Form" value={player.form.toFixed(1)} />
              <Tile label="Net xfers" value={`${player.net > 0 ? "+" : ""}${player.net}`} />
            </div>
            <p className="mb-1 mt-4 text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Projected points by gameweek
            </p>
            <div className="flex gap-1 overflow-x-auto pb-1">
              {ctx.gws.map((g, i) => {
                const c = cellsFor(p.fxMap, player.team, g)[0];
                const short = c ? (p.teamsById.get(c.opp)?.short ?? "?") : "";
                return (
                  <div key={g} className="w-12 shrink-0 text-center">
                    <p className="text-[9px] font-bold text-slate-500">GW{g}</p>
                    <div
                      className={`rounded-t py-1 text-[9px] font-bold ${c ? fdrClasses(c.diff) : "bg-slate-800 text-slate-500"}`}
                    >
                      {c ? (c.home ? short : short.toLowerCase()) : "–"}
                    </div>
                    <div className={`rounded-b py-1 text-xs font-extrabold ${i === p.idx ? "bg-[#84d21c] text-black" : "bg-white/[0.06] text-[#bbe682]"}`}>
                      {(player.xp[i] ?? 0).toFixed(1)}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        ) : (
          <ul className="mt-3 max-h-64 space-y-1 overflow-y-auto">
            {ctx.gws.flatMap((g) => {
              const cs = cellsFor(p.fxMap, player.team, g);
              if (cs.length === 0)
                return [
                  <li key={g} className="flex items-center justify-between rounded-lg bg-white/[0.03] px-3 py-2 text-xs text-slate-500">
                    <span>GW{g}</span>
                    <span>Blank</span>
                  </li>,
                ];
              return cs.map((c, j) => (
                <li key={`${g}-${j}`} className="flex items-center justify-between rounded-lg bg-white/[0.04] px-3 py-2 text-xs">
                  <span className="font-bold text-slate-300">GW{g}</span>
                  <span className="text-slate-100">
                    {p.teamsById.get(c.opp)?.name ?? "?"} ({c.home ? "H" : "A"})
                  </span>
                  <span className={`rounded px-2 py-0.5 text-[10px] font-extrabold ${fdrClasses(c.diff)}`}>FDR {c.diff}</span>
                </li>
              ));
            })}
          </ul>
        )}

        {/* actions */}
        <div className="mt-4 space-y-2">
          {p.inSquad ? (
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={p.onTransferOut}
                className="rounded-xl bg-[#84d21c] py-2.5 text-sm font-extrabold text-black hover:brightness-110"
              >
                Transfer out (sell £{money(p.sellPrice)}m)
              </button>
              {p.boughtNow ? (
                <button
                  type="button"
                  onClick={p.onCancel}
                  className="rounded-xl border border-rose-400/50 py-2.5 text-sm font-bold text-rose-200 hover:bg-rose-500/10"
                >
                  Cancel this transfer
                </button>
              ) : (
                <button
                  type="button"
                  onClick={p.onClose}
                  className="rounded-xl border border-white/20 py-2.5 text-sm font-bold text-slate-200 hover:bg-white/10"
                >
                  Close
                </button>
              )}
            </div>
          ) : options.length === 0 ? (
            <p className="rounded-xl bg-white/[0.04] p-3 text-center text-xs text-slate-400">
              No squad player at this position to replace.
            </p>
          ) : (
            <>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Transfer in, replacing
                <select
                  className={`${inputCls} mt-1`}
                  value={chosenId ?? ""}
                  onChange={(e) => setChosen(Number(e.target.value))}
                >
                  {options.map((o) => (
                    <option key={o.outId} value={o.outId} className="bg-slate-900">
                      {ctx.players.get(o.outId)?.name}
                      {o.reason ? ` — ${o.reason}` : ` (${o.gain >= 0 ? "+" : ""}${o.gain.toFixed(1)} xP / 5 GWs)`}
                    </option>
                  ))}
                </select>
              </label>
              <button
                type="button"
                disabled={!chosenOpt || chosenOpt.reason !== null}
                onClick={() => chosenId !== null && p.onTransferIn(chosenId)}
                className="w-full rounded-xl bg-[#84d21c] py-2.5 text-sm font-extrabold text-black hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
              >
                {chosenOpt?.reason ?? `Transfer in ${player.name} (£${money(player.cost)}m)`}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
