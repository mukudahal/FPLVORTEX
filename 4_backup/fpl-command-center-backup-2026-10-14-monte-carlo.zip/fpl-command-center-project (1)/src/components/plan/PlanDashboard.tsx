"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  bestXI,
  buildFxMap,
  lineupAt,
  makeCtx,
  rankReplacements,
  replay,
  sanitize,
  sellOf,
  summarise,
  validateTransfer,
  type TransferMap,
} from "@/lib/planEngine";
import {
  fromSaved,
  loadServerPlan,
  readLocal,
  readWatch,
  saveServerPlan,
  toSaved,
  writeLocal,
  writeWatch,
} from "@/lib/planStorage";
import type { PlanResponse, PlanTeam, PlanTransfer } from "@/lib/planTypes";
import { useJson } from "@/lib/useJson";
import { LabPanel } from "./LabPanel";
import { PlanPitch } from "./PlanPitch";
import { PlayerModal } from "./PlayerModal";
import { PlayerPanel, type SlotInfo, type SubTab } from "./PlayerPanel";
import { SummaryTab } from "./SummaryTab";
import { TickerTab } from "./TickerTab";
import { money } from "./planUi";

type MainTab = "players" | "ticker" | "summary";
type SaveStatus = "synced" | "saving" | "local";

const countTransfers = (tm: TransferMap): number =>
  Object.values(tm).reduce((s, l) => s + l.length, 0);

/* ------------------------------------------------------------------ */
/* shell: loading / error                                             */
/* ------------------------------------------------------------------ */

export function PlanDashboard({ teamId }: { teamId: string }) {
  const { data, error, loading, refresh } = useJson<PlanResponse>(`/api/plan/${teamId}?gws=10`);

  return (
    <div className="fixed inset-0 z-[100] overflow-y-auto bg-[#05080f] text-slate-100">
      {data ? (
        <PlanBoard data={data} teamId={teamId} />
      ) : (
        <>
          <header className="flex items-center justify-between border-b border-[#cda228]/25 bg-black/90 px-4 py-3">
            <Link href="/" className="rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-xs font-bold">
              ‹ Home
            </Link>
            <span className="text-sm font-extrabold">Transfer Plan</span>
            <span className="w-16" />
          </header>
          {error ? (
            <div className="mx-auto mt-16 max-w-md rounded-2xl border border-rose-500/30 bg-rose-500/10 p-5 text-center">
              <p className="text-sm font-semibold text-rose-200">{error}</p>
              <button
                type="button"
                onClick={refresh}
                className="mt-4 rounded-xl bg-[#cda228] px-4 py-2 text-sm font-extrabold text-black"
              >
                Retry
              </button>
            </div>
          ) : (
            <div className="mx-auto mt-24 max-w-sm text-center text-sm text-slate-400">
              <div className="mx-auto mb-4 h-8 w-8 animate-spin rounded-full border-2 border-[#cda228]/30 border-t-[#cda228]" />
              {loading ? "Loading live FPL data and building a 10-gameweek projection…" : "Preparing…"}
            </div>
          )}
        </>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* the planner                                                        */
/* ------------------------------------------------------------------ */

function PlanBoard({ data, teamId }: { data: PlanResponse; teamId: string }) {
  const ctx = useMemo(() => makeCtx(data), [data]);
  const fxMap = useMemo(() => buildFxMap(data.fixtures), [data]);
  const teamsById = useMemo(() => {
    const m = new Map<number, PlanTeam>();
    data.teams.forEach((t) => m.set(t.id, t));
    return m;
  }, [data]);
  const allIds = useMemo(() => [...ctx.players.keys()], [ctx]);

  const startGw = data.nextGw;
  const defaultName = `Transfer Plan (GW${startGw}+)`;

  /* ---- plan state ---- */
  const [name, setName] = useState<string>(() => readLocal(teamId)?.name ?? defaultName);
  const [editingName, setEditingName] = useState(false);
  const [transfers, setTransfers] = useState<TransferMap>(() => {
    const local = readLocal(teamId);
    return local ? sanitize(ctx, fromSaved(local.data)) : {};
  });
  const [past, setPast] = useState<TransferMap[]>([]);
  const [idx, setIdx] = useState(0);
  const [slotId, setSlotId] = useState<number | null>(null);
  const [modalId, setModalId] = useState<number | null>(null);
  const [tab, setTab] = useState<MainTab>("players");
  const [sub, setSub] = useState<SubTab>("players");
  const [showXp, setShowXp] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [toast, setToast] = useState<{ msg: string; tone: "ok" | "err" } | null>(null);
  const [watchList, setWatchList] = useState<number[]>(() => readWatch(teamId));

  const dirty = useRef(false);
  const serverId = useRef<number | null>(null);
  const [hydrated, setHydrated] = useState(false);
  const [status, setStatus] = useState<SaveStatus>("synced");
  const panelRef = useRef<HTMLElement | null>(null);

  const flash = useCallback((msg: string, tone: "ok" | "err" = "ok") => setToast({ msg, tone }), []);
  useEffect(() => {
    if (!toast) return;
    const h = window.setTimeout(() => setToast(null), 3500);
    return () => window.clearTimeout(h);
  }, [toast]);

  const commit = useCallback(
    (next: TransferMap) => {
      dirty.current = true;
      setPast((p) => [...p.slice(-29), transfers]);
      setTransfers(next);
    },
    [transfers],
  );

  /* ---- derived plan numbers ---- */
  const gws = ctx.gws;
  const safeIdx = Math.min(idx, Math.max(0, gws.length - 1));
  const gw = gws[safeIdx];
  const state = useMemo(() => replay(ctx, transfers, gw), [ctx, transfers, gw]);
  const lineup = useMemo(() => lineupAt(ctx, state.squad, safeIdx), [ctx, state, safeIdx]);
  const dream = useMemo(
    () =>
      bestXI(
        allIds,
        (id) => ctx.players.get(id)?.type ?? 0,
        (id) => ctx.players.get(id)?.xp[safeIdx] ?? 0,
      ),
    [allIds, ctx, safeIdx],
  );
  const rating = dream.total > 0 ? Math.round((lineup.total / dream.total) * 100) : 0;
  const ledgerRow = state.ledger.find((l) => l.gw === gw);
  const squadSet = useMemo(() => new Set(state.squad), [state]);

  const boughtNow = useMemo(
    () => new Set((transfers[gw] ?? []).map((t) => t.in).filter((id) => squadSet.has(id))),
    [transfers, gw, squadSet],
  );
  const boughtEver = useMemo(() => {
    const s = new Set<number>();
    for (const g of gws) {
      if (g > gw) break;
      (transfers[g] ?? []).forEach((t) => squadSet.has(t.in) && s.add(t.in));
    }
    return s;
  }, [transfers, gws, gw, squadSet]);

  const squadTeams = useMemo(() => {
    const m = new Map<number, number>();
    state.squad.forEach((id) => {
      const t = ctx.players.get(id)?.team;
      if (t !== undefined) m.set(t, (m.get(t) ?? 0) + 1);
    });
    return m;
  }, [state, ctx]);

  const summary = useMemo(
    () => summarise(ctx, fxMap, state.squad, lineup, gw),
    [ctx, fxMap, state, lineup, gw],
  );

  // projected total over the whole window (stored with the saved plan)
  const planTotal = useMemo(() => {
    let t = 0;
    gws.forEach((g, i) => {
      t += lineupAt(ctx, replay(ctx, transfers, g).squad, i).total;
    });
    return t;
  }, [ctx, gws, transfers]);

  /* ---- transfer actions ---- */
  const doTransfer = useCallback(
    (outId: number, inId: number) => {
      const err = validateTransfer(ctx, state, outId, inId);
      if (err) {
        flash(err, "err");
        return;
      }
      const list = transfers[gw] ?? [];
      const k = list.findIndex((t) => t.in === outId);
      let nextList: PlanTransfer[];
      if (k >= 0) {
        const orig = list[k];
        nextList =
          inId === orig.out
            ? list.filter((_, i) => i !== k)
            : list.map((t, i) => (i === k ? { out: orig.out, in: inId } : t));
      } else {
        nextList = [...list, { out: outId, in: inId }];
      }
      const draft: TransferMap = { ...transfers, [gw]: nextList };
      if (nextList.length === 0) delete draft[gw];
      const clean = sanitize(ctx, draft);
      const dropped = countTransfers(draft) - countTransfers(clean);
      commit(clean);
      setSlotId(null);
      setModalId(null);
      flash(
        dropped > 0
          ? `Transfer made. ${dropped} later transfer${dropped > 1 ? "s" : ""} no longer fit and ${dropped > 1 ? "were" : "was"} removed.`
          : `${ctx.players.get(outId)?.name} → ${ctx.players.get(inId)?.name}`,
      );
    },
    [ctx, state, transfers, gw, commit, flash],
  );

  const cancelBought = useCallback(
    (id: number) => {
      const list = transfers[gw] ?? [];
      const next = list.filter((t) => t.in !== id);
      if (next.length === list.length) return;
      const draft: TransferMap = { ...transfers, [gw]: next };
      if (next.length === 0) delete draft[gw];
      const clean = sanitize(ctx, draft);
      const dropped = countTransfers(draft) - countTransfers(clean);
      commit(clean);
      setModalId(null);
      flash(dropped > 0 ? `Transfer cancelled. ${dropped} dependent later transfer(s) removed.` : "Transfer cancelled.");
    },
    [transfers, gw, ctx, commit, flash],
  );

  const startTransfer = useCallback((id: number) => {
    setSlotId(id);
    setModalId(null);
    setTab("players");
    setSub("players");
    if (typeof window !== "undefined" && window.innerWidth < 1024) {
      window.setTimeout(() => panelRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
    }
  }, []);

  const undo = () => {
    if (past.length === 0) return;
    dirty.current = true;
    setTransfers(past[past.length - 1]);
    setPast(past.slice(0, -1));
    setMenuOpen(false);
    flash("Undid last change.");
  };

  const resetPlan = () => {
    setMenuOpen(false);
    if (countTransfers(transfers) === 0) return;
    if (window.confirm("Clear every planned transfer?")) {
      commit({});
      setSlotId(null);
      flash("Plan cleared.");
    }
  };

  const toggleWatch = (id: number) => {
    setWatchList((cur) => {
      const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
      writeWatch(teamId, next);
      return next;
    });
  };
  const watchSet = useMemo(() => new Set(watchList), [watchList]);

  /* ---- slot (transfer mode) info ---- */
  const slotValid = slotId !== null && squadSet.has(slotId);
  const slotInfo = useMemo<SlotInfo | null>(() => {
    if (!slotValid || slotId === null) return null;
    const pl = ctx.players.get(slotId);
    if (!pl) return null;
    const gains = new Map<number, number>();
    rankReplacements(ctx, state, slotId, safeIdx, 5).forEach((r) => gains.set(r.id, r.gain));
    const reasons = new Map<number, string>();
    for (const c of ctx.players.values()) {
      if (c.type !== pl.type || squadSet.has(c.id) || gains.has(c.id)) continue;
      const why = validateTransfer(ctx, state, slotId, c.id);
      if (why) reasons.set(c.id, why);
    }
    let bestId: number | null = null;
    let bestGain = 0;
    gains.forEach((g, id) => {
      if (g > bestGain) {
        bestGain = g;
        bestId = id;
      }
    });
    const sell = sellOf(ctx, state, slotId);
    return { player: pl, sell, budget: state.bank + sell, gains, reasons, bestId };
  }, [slotValid, slotId, ctx, state, squadSet, safeIdx]);

  /* ---- persistence: load ---- */
  useEffect(() => {
    let alive = true;
    loadServerPlan(teamId)
      .then((row) => {
        if (!alive || !row) return;
        serverId.current = row.id;
        if (!dirty.current) {
          setTransfers(sanitize(ctx, fromSaved(row.data)));
          setName(row.name || defaultName);
        }
      })
      .catch(() => alive && setStatus("local"))
      .finally(() => alive && setHydrated(true));
    return () => {
      alive = false;
    };
  }, [teamId, ctx, defaultName]);

  /* ---- persistence: autosave (debounced) ---- */
  useEffect(() => {
    if (!hydrated || !dirty.current) return;
    setStatus("saving");
    const h = window.setTimeout(async () => {
      const payload = toSaved(startGw, transfers);
      writeLocal(teamId, { name, data: payload });
      try {
        serverId.current = await saveServerPlan({
          teamId,
          name,
          data: payload,
          projectedPoints: Math.round(planTotal),
          id: serverId.current,
        });
        setStatus("synced");
      } catch {
        setStatus("local");
      }
    }, 900);
    return () => window.clearTimeout(h);
  }, [transfers, name, hydrated, teamId, startGw, planTotal]);

  /* ---- keyboard: Esc closes modal / transfer mode ---- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      if (modalId !== null) setModalId(null);
      else if (slotId !== null) setSlotId(null);
      else setMenuOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [modalId, slotId]);

  const modalPlayer = modalId !== null ? ctx.players.get(modalId) : undefined;
  const stat = "rounded-2xl border border-white/10 bg-white/[0.04] px-3 py-2 text-center";
  const statLabel = "text-[10px] font-bold uppercase tracking-wider text-slate-400";

  const mainTabs: [MainTab, string][] = [
    ["players", "Players"],
    ["ticker", "Ticker"],
    ["summary", "GW Summary"],
  ];

  return (
    <>
      {/* top bar */}
      <header className="sticky top-0 z-20 flex items-center justify-between gap-2 border-b border-[#cda228]/25 bg-black/90 px-3 py-2.5 backdrop-blur sm:px-5">
        <Link
          href={`/team/${teamId}`}
          className="shrink-0 rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-xs font-bold text-slate-200 hover:bg-white/10"
        >
          ‹ Save &amp; Exit
        </Link>

        <div className="flex min-w-0 items-center gap-1 rounded-xl bg-white/5 px-3 py-1.5">
          {editingName ? (
            <input
              autoFocus
              value={name}
              maxLength={60}
              onChange={(e) => {
                dirty.current = true;
                setName(e.target.value);
              }}
              onBlur={() => {
                if (!name.trim()) setName(defaultName);
                setEditingName(false);
              }}
              onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()}
              className="w-44 bg-transparent text-sm font-extrabold text-white outline-none sm:w-64"
              aria-label="Plan name"
            />
          ) : (
            <h1 className="truncate text-sm font-extrabold sm:text-base">{name}</h1>
          )}
          <button
            type="button"
            onClick={() => setEditingName((v) => !v)}
            aria-label="Rename plan"
            className="text-slate-400 hover:text-white"
          >
            ✎
          </button>
        </div>

        <span
          className={`flex shrink-0 items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold ${
            status === "synced"
              ? "border-[#84d21c]/40 bg-[#84d21c]/10 text-[#bbe682]"
              : status === "saving"
                ? "border-amber-400/40 bg-amber-400/10 text-amber-200"
                : "border-white/20 bg-white/5 text-slate-300"
          }`}
          title={status === "local" ? "Saved on this device only (server unavailable)" : undefined}
        >
          <span
            className={`h-2 w-2 rounded-full ${
              status === "synced" ? "bg-[#84d21c]" : status === "saving" ? "animate-pulse bg-amber-300" : "bg-slate-400"
            }`}
          />
          {status === "synced" ? "Synced" : status === "saving" ? "Saving…" : "On device"}
        </span>
      </header>

      <main className="mx-auto grid max-w-[1400px] gap-4 p-3 sm:p-5 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,1fr)]">
        {/* LEFT */}
        <section className="overflow-hidden rounded-3xl border border-white/10 bg-slate-950/70">
          <div className="grid grid-cols-2 gap-2 p-3 sm:grid-cols-4">
            <div className={stat}>
              <p className={statLabel}>Transfers</p>
              <p className="text-lg font-extrabold">
                {ledgerRow?.n ?? 0} / {ledgerRow?.ftBefore ?? data.freeTransfers}
              </p>
            </div>
            <div className={stat}>
              <p className={statLabel}>Cost</p>
              <p className={`text-lg font-extrabold ${ledgerRow?.hit ? "text-rose-300" : ""}`}>
                {ledgerRow?.hit ? `-${ledgerRow.hit}` : 0}
              </p>
            </div>
            <div className={stat}>
              <p className={statLabel}>Bank</p>
              <p className="text-lg font-extrabold">{money(state.bank)}</p>
            </div>
            <div
              className={stat}
              title="xP = projected points for your best XI plus captain. Rating = that total as a % of the best possible XI in the game (no budget limit)."
            >
              <p className={statLabel}>xP / Rating</p>
              <p className="text-lg font-extrabold">
                {lineup.total.toFixed(0)} <span className="text-slate-500">/</span>{" "}
                <span className="text-[#dfc373]">{rating}%</span>
              </p>
            </div>
          </div>

          {/* gameweek selector */}
          <div className="relative flex items-center justify-center gap-2 px-3 pb-2">
            <div className="relative">
              <button
                type="button"
                onClick={() => setMenuOpen((v) => !v)}
                aria-label="Plan menu"
                aria-expanded={menuOpen}
                className="h-11 w-11 rounded-xl border border-white/15 bg-white/5 text-lg font-bold hover:bg-white/10"
              >
                •••
              </button>
              {menuOpen ? (
                <div className="absolute left-0 top-12 z-30 w-48 overflow-hidden rounded-xl border border-white/15 bg-[#0b1220] text-sm shadow-2xl">
                  <button
                    type="button"
                    onClick={undo}
                    disabled={past.length === 0}
                    className="block w-full px-3 py-2.5 text-left font-semibold hover:bg-white/10 disabled:opacity-40"
                  >
                    Undo last change
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      setTab("players");
                      setSub("lab");
                    }}
                    className="block w-full px-3 py-2.5 text-left font-semibold hover:bg-white/10"
                  >
                    Auto-optimise…
                  </button>
                  <button
                    type="button"
                    onClick={resetPlan}
                    className="block w-full px-3 py-2.5 text-left font-semibold text-rose-300 hover:bg-white/10"
                  >
                    Reset plan
                  </button>
                </div>
              ) : null}
            </div>

            <button
              type="button"
              onClick={() => setIdx(Math.max(0, safeIdx - 1))}
              disabled={safeIdx === 0}
              aria-label="Previous gameweek"
              className="h-11 w-11 rounded-xl border border-white/15 bg-white/5 text-lg font-bold disabled:opacity-30"
            >
              ←
            </button>
            <div className="relative w-44">
              <select
                value={safeIdx}
                onChange={(e) => setIdx(Number(e.target.value))}
                aria-label="Choose gameweek"
                className="h-11 w-full appearance-none rounded-xl border border-white/15 bg-white/5 px-3 text-center text-base font-extrabold text-white focus:border-[#cda228] focus:outline-none"
              >
                {gws.map((g, i) => (
                  <option key={g} value={i} className="bg-slate-900">
                    Gameweek {g}
                  </option>
                ))}
              </select>
              <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400">▾</span>
            </div>
            <button
              type="button"
              onClick={() => setIdx(Math.min(gws.length - 1, safeIdx + 1))}
              disabled={safeIdx >= gws.length - 1}
              aria-label="Next gameweek"
              className="h-11 w-11 rounded-xl border border-[#84d21c]/50 bg-[#84d21c]/10 text-lg font-bold text-[#bbe682] disabled:opacity-30"
            >
              →
            </button>
            <button
              type="button"
              onClick={() => setShowXp((v) => !v)}
              aria-pressed={showXp}
              aria-label="Toggle price / projected points on cards"
              title="Cards: price ↔ projected points"
              className={`h-11 w-11 rounded-xl border text-lg font-bold ${
                showXp ? "border-[#84d21c]/60 bg-[#84d21c]/15 text-[#bbe682]" : "border-white/15 bg-white/5"
              }`}
            >
              {showXp ? "xP" : "£"}
            </button>
          </div>
          {data.deadlines[gw] ? (
            <p className="pb-2 text-center text-[11px] text-slate-400">
              Deadline{" "}
              {new Date(data.deadlines[gw]).toLocaleString(undefined, {
                weekday: "short",
                day: "numeric",
                month: "short",
                hour: "2-digit",
                minute: "2-digit",
              })}{" "}
              · formation {lineup.formation}
            </p>
          ) : null}

          <PlanPitch
            ctx={ctx}
            lineup={lineup}
            fxMap={fxMap}
            teamsById={teamsById}
            idx={safeIdx}
            gw={gw}
            slot={slotValid ? slotId : null}
            boughtNow={boughtNow}
            boughtEver={boughtEver}
            priceOf={(id) => sellOf(ctx, state, id)}
            showXp={showXp}
            onOpen={setModalId}
            onSwap={startTransfer}
            onRemove={(id) => (boughtNow.has(id) ? cancelBought(id) : startTransfer(id))}
          />
        </section>

        {/* RIGHT */}
        <section
          ref={panelRef}
          className="rounded-3xl border border-white/10 bg-slate-950/70 p-3 sm:p-4 lg:max-h-[calc(100dvh-5.5rem)] lg:overflow-y-auto"
        >
          <div className="mb-3 grid grid-cols-3 gap-1 rounded-2xl bg-black/40 p-1">
            {mainTabs.map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setTab(id)}
                className={`rounded-xl py-2.5 text-sm font-bold transition ${
                  tab === id
                    ? "bg-[#cda228]/25 text-[#dfc373] ring-1 ring-[#cda228]/50"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {tab === "players" ? (
            <PlayerPanel
              ctx={ctx}
              teams={data.teams}
              teamsById={teamsById}
              fxMap={fxMap}
              gw={gw}
              idx={safeIdx}
              squadSet={squadSet}
              watch={watchSet}
              slot={slotInfo}
              sub={sub}
              onSub={setSub}
              onOpen={setModalId}
              onPick={(inId) => slotId !== null && doTransfer(slotId, inId)}
              onClearSlot={() => setSlotId(null)}
              lab={
                <LabPanel
                  ctx={ctx}
                  state={state}
                  transfers={transfers}
                  idx={safeIdx}
                  gw={gw}
                  onApplyPlan={(tm) => {
                    commit(tm);
                    flash("Plan applied. Review it gameweek by gameweek with the arrows.");
                  }}
                  onApplyMove={doTransfer}
                />
              }
            />
          ) : null}
          {tab === "ticker" ? (
            <TickerTab
              key={safeIdx}
              ctx={ctx}
              teams={data.teams}
              teamsById={teamsById}
              fxMap={fxMap}
              idx={safeIdx}
              squadTeams={squadTeams}
              deadlines={data.deadlines}
            />
          ) : null}
          {tab === "summary" ? (
            <SummaryTab
              ctx={ctx}
              teamsById={teamsById}
              fxMap={fxMap}
              gw={gw}
              idx={safeIdx}
              lineup={lineup}
              summary={summary}
              ledger={ledgerRow}
              transfers={transfers[gw] ?? []}
              bank={state.bank}
            />
          ) : null}
        </section>
      </main>

      {modalPlayer ? (
        <PlayerModal
          ctx={ctx}
          player={modalPlayer}
          state={state}
          teamsById={teamsById}
          fxMap={fxMap}
          idx={safeIdx}
          inSquad={squadSet.has(modalPlayer.id)}
          boughtNow={boughtNow.has(modalPlayer.id)}
          sellPrice={sellOf(ctx, state, modalPlayer.id)}
          watched={watchSet.has(modalPlayer.id)}
          onWatch={() => toggleWatch(modalPlayer.id)}
          onClose={() => setModalId(null)}
          onTransferOut={() => startTransfer(modalPlayer.id)}
          onCancel={() => cancelBought(modalPlayer.id)}
          onTransferIn={(outId) => doTransfer(outId, modalPlayer.id)}
        />
      ) : null}

      {toast ? (
        <div
          role="status"
          className={`fixed bottom-4 left-1/2 z-[120] max-w-[92vw] -translate-x-1/2 rounded-xl px-4 py-2.5 text-sm font-bold shadow-2xl ${
            toast.tone === "err" ? "bg-rose-600 text-white" : "bg-[#84d21c] text-black"
          }`}
        >
          {toast.msg}
        </div>
      ) : null}
    </>
  );
}
