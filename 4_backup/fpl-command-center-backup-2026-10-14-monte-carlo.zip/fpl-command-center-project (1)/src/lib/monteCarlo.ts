/**
 * Monte Carlo risk simulation for the transfer optimizer.
 *
 * The optimizer's xPts are averages. This module simulates thousands of possible futures to answer
 * the question that actually matters for a decision: "how likely is this move to beat holding, and
 * by how much could it go wrong?"
 *
 * Design:
 *  - Paired draws. Every player-gameweek is simulated ONCE and reused by every strategy, so two
 *    strategies that share players see identical outcomes for them. Differences between strategies
 *    therefore come only from the players that differ, which keeps comparisons precise.
 *  - Each player-gameweek is built from parts: a minutes state (60+, short appearance or absent) from
 *    the model's own probabilities, clean-sheet points or goals-conceded penalties from a draw shared
 *    by the whole team, cards at the model's rate, and attacking/bonus returns as random events. The
 *    event rate is solved so the simulated mean equals the model's expected points exactly.
 *  - Teammates share a team-and-gameweek factor, so a good attacking day (or a clean sheet) lifts
 *    several of your players together instead of each being independent. Spread is calibrated on the
 *    walk-forward backtest (see MC_CAL).
 *  - Lineups are chosen ex ante from expected points, exactly as a manager would, then scored on the
 *    simulated outcome with formation-valid automatic substitutions and the vice-captain fallback.
 *
 * Everything is deterministic for a given seed, so the same squad always gets the same answer.
 */

import type {
  McBand,
  McCaptainRisk,
  McPathSummary,
  MonteCarloSummary,
} from "./types";

export const MC_DRAWS = 3000;

/**
 * Calibration measured on the walk-forward backtest (GW3-5, 755 player-gameweeks), fitted so the
 * simulated distribution of points matches the real one.
 */
export const MC_CAL: {
  /** Average points per attacking/bonus event, by position (GK, DEF, MID, FWD). */
  eventValue: Record<number, number>;
  /** Overdispersion of event counts (lower = more variable). */
  eventDispersion: number;
  /** A short appearance earns this fraction of a full appearance's expected event returns. */
  subReturnShare: number;
  /** Real short appearances are more common than the model's pSub; scale them up (keeps P(appear)). */
  shortBoost: number;
  /** Lognormal sigma of the shared team-gameweek factor on event rates. */
  teamSigma: number;
  /**
   * Reliability testing on thousands of hypothetical transfers (GW3-5) found raw probabilities too
   * extreme (fitted logistic slope 0.55). Probabilities are pulled toward 50% with this slope.
   */
  probSlope: number;
} = {
  eventValue: { 1: 2.6, 2: 2.6, 3: 2.6, 4: 2.6 },
  eventDispersion: 2,
  subReturnShare: 0.25,
  shortBoost: 2.1,
  teamSigma: 0.3,
  probSlope: 0.6,
};

export interface McPlayerGw {
  /** Expected points for the gameweek (the model's xPts, including blanks and doubles). */
  mean: number;
  /** Per fixture: probability of playing 60+ minutes. */
  p60: number;
  /** Per fixture: probability of a shorter appearance. */
  pSub: number;
  /** Fixtures in the gameweek (0 blank, 1 normal, 2 double). */
  fixtures: number;
  /** Average clean-sheet probability per fixture (GK/DEF/MID). */
  csProb: number;
  /** Expected points lost to cards in the gameweek (zero or positive). */
  cardLoss: number;
  team: number;
  /** 1 GK, 2 DEF, 3 MID, 4 FWD */
  position: number;
}

export interface McLineup {
  starters: number[];
  /** Bench order: backup goalkeeper first, then outfield subs by priority. */
  bench: number[];
  captainId: number;
  viceId: number;
}

export interface McPath {
  id: string;
  label: string;
  hitCost: number;
  lineupAt: (gw: number) => McLineup | null;
}

export interface McOptions {
  gws: number[];
  paths: McPath[];
  holdId: string;
  recommendedId: string;
  playerAt: (pid: number, gw: number) => McPlayerGw | null;
  draws?: number;
  seed: number;
}

/* ---------------------------- random numbers ---------------------------- */

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Mix integers into one well-spread 32-bit seed. */
export function mixSeed(...parts: number[]): number {
  let h = 0x811c9dc5;
  for (const x of parts) {
    h ^= x | 0;
    h = Math.imul(h, 0x01000193);
    h ^= h >>> 13;
    h = Math.imul(h, 0x85ebca6b);
    h ^= h >>> 16;
  }
  return h >>> 0;
}

function normal(rng: () => number): number {
  let u = 0;
  while (u === 0) u = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * rng());
}

/** Marsaglia-Tsang gamma(shape k, scale 1). */
function gammaUnit(k: number, rng: () => number): number {
  if (k < 1) {
    const u = Math.max(rng(), 1e-12);
    return gammaUnit(k + 1, rng) * Math.pow(u, 1 / k);
  }
  const d = k - 1 / 3;
  const c = 1 / Math.sqrt(9 * d);
  for (;;) {
    let x: number;
    let v: number;
    do {
      x = normal(rng);
      v = 1 + c * x;
    } while (v <= 0);
    v = v * v * v;
    const u = rng();
    if (u < 1 - 0.0331 * x * x * x * x) return d * v;
    if (Math.log(u) < 0.5 * x * x + d * (1 - v + Math.log(v))) return d * v;
  }
}

/** Random draws shared by every player of one team in one gameweek. */
export interface McTeamNoise {
  /** Lognormal factor (mean 1) on event rates: a good attacking day lifts teammates together. */
  shock: Float32Array;
  /** Uniforms that decide the team's goals conceded in each fixture (shared by GK, DEF, MID). */
  conc: Float32Array[];
}

export function makeTeamNoise(
  seed: number,
  team: number,
  gw: number,
  draws: number,
  fixtures: number,
): McTeamNoise {
  const rng = mulberry32(mixSeed(seed, team, gw, 7));
  const sg = MC_CAL.teamSigma;
  const shock = new Float32Array(draws);
  for (let i = 0; i < draws; i++) shock[i] = Math.exp(sg * normal(rng) - (sg * sg) / 2);
  const conc: Float32Array[] = [];
  for (let f = 0; f < Math.max(1, fixtures); f++) {
    const u = new Float32Array(draws);
    for (let i = 0; i < draws; i++) u[i] = rng();
    conc.push(u);
  }
  return { shock, conc };
}

/** Goals conceded implied by a uniform draw, for a Poisson(lambda) count. */
function goalsFromUniform(u: number, lambda: number): number {
  let g = 0;
  let p = Math.exp(-lambda);
  let cdf = p;
  while (u >= cdf && g < 12) {
    g += 1;
    p *= lambda / g;
    cdf += p;
  }
  return g;
}

/** E[floor(G/2)] for G ~ Poisson(lambda): expected "-1 per 2 goals conceded" points lost. */
function expectedGcPenalty(lambda: number): number {
  let p = Math.exp(-lambda);
  let e = 0;
  for (let k = 1; k <= 12; k++) {
    p *= lambda / k;
    e += Math.floor(k / 2) * p;
  }
  return e;
}

function poisson(lambda: number, rng: () => number): number {
  if (lambda <= 0) return 0;
  if (lambda > 30) return Math.max(0, Math.round(lambda + Math.sqrt(lambda) * normal(rng)));
  const limit = Math.exp(-lambda);
  let k = 0;
  let p = 1;
  do {
    k += 1;
    p *= rng();
  } while (p > limit);
  return k - 1;
}

const CS_POINTS: Record<number, number> = { 1: 4, 2: 4, 3: 1, 4: 0 };

/**
 * Sample points for ONE player-gameweek: `played` flags and `pts` (0 when absent).
 *
 * Per fixture: pick a minutes state (60+, short appearance, absent). An appearance earns 2 or 1
 * points. A 60+ appearance also earns the clean-sheet points (or loses a point per two goals
 * conceded) decided by the team's shared goals-conceded draw. Cards cost a point at the model's
 * own rate. The rest of the expected points arrive as random attacking/bonus events, with their
 * rate solved so the overall mean equals the model's xPts exactly.
 * Exposed so calibration tests can use exactly the production sampler.
 */
export function samplePlayerGw(
  p: McPlayerGw | null,
  noise: McTeamNoise | null,
  draws: number,
  seed: number,
): { pts: Float32Array; played: Uint8Array } {
  const pts = new Float32Array(draws);
  const played = new Uint8Array(draws);
  if (!p || p.fixtures <= 0) return { pts, played };

  const modelP60 = Math.min(1, Math.max(0, p.p60));
  const modelPSub = Math.min(1 - modelP60, Math.max(0, p.pSub));
  const pApp = modelP60 + modelPSub;
  if (pApp < 1e-4 || p.mean <= 0) return { pts, played };

  const { eventDispersion, subReturnShare, shortBoost } = MC_CAL;
  const eventValue = MC_CAL.eventValue[p.position] ?? 2.6;

  // Real short appearances are more common than the model's pSub; move some mass from 60+.
  const move = Math.min(modelP60, modelPSub * (shortBoost - 1));
  const p60 = modelP60 - move;
  const pSub = modelPSub + move;

  const fx = p.fixtures;
  const perFixture = p.mean / fx;
  const csValue = CS_POINTS[p.position] ?? 0;
  const csProb = csValue > 0 ? Math.min(0.95, Math.max(0.01, p.csProb)) : 0;
  const lambdaC = csProb > 0 ? -Math.log(csProb) : 0;
  const gcPenalised = p.position <= 2;
  // Expected defensive points of a 60+ appearance (clean sheet minus goals-conceded penalty).
  const defMean = csProb > 0 ? csValue * csProb - (gcPenalised ? expectedGcPenalty(lambdaC) : 0) : 0;
  // Card rate per appearance that reproduces the model's expected card loss.
  const cardLossPerFixture = Math.max(0, p.cardLoss) / fx;
  const pCard = Math.min(0.5, cardLossPerFixture / pApp);

  // What is left for random events once appearance, defence and cards are accounted for.
  const residual = perFixture - (2 * p60 + pSub) - p60 * defMean + cardLossPerFixture;
  const rFull = Math.max(0.03, residual / (p60 + subReturnShare * pSub));
  const rSub = subReturnShare * rFull;
  const theta = eventValue / 2; // each event is gamma(2) distributed, mean eventValue

  const rng = mulberry32(seed);
  for (let i = 0; i < draws; i++) {
    let total = 0;
    let appeared = false;
    for (let f = 0; f < fx; f++) {
      const u = rng();
      const state = u < p60 ? 2 : u < p60 + pSub ? 1 : 0;
      if (state === 0) continue;
      appeared = true;
      total += state === 2 ? 2 : 1;

      if (state === 2 && csProb > 0) {
        const uc = noise ? noise.conc[Math.min(f, noise.conc.length - 1)][i] : rng();
        const g = goalsFromUniform(uc, lambdaC);
        if (g === 0) total += csValue;
        else if (gcPenalised) total -= Math.floor(g / 2);
      }
      if (rng() < pCard) total -= 1;

      const rate = state === 2 ? rFull : rSub;
      let lambda = (rate / eventValue) * (noise ? noise.shock[i] : 1);
      lambda *= gammaUnit(eventDispersion, rng) / eventDispersion; // overdispersed event counts
      const n = poisson(lambda, rng);
      if (n > 0) total += gammaUnit(2 * n, rng) * theta;
    }
    if (appeared) {
      played[i] = 1;
      pts[i] = total;
    }
  }
  return { pts, played };
}

/* ------------------------------ lineup scoring ------------------------------ */

export interface McOutcome {
  pts: (pid: number) => number;
  played: (pid: number) => boolean;
  position: (pid: number) => number;
}

/**
 * Points a lineup scores on one realised outcome: starters who played, a backup goalkeeper if the
 * starter did not, formation-valid automatic substitutions in bench order, and the captain's
 * doubling (falling back to the vice-captain if the captain did not play).
 */
export function scoreLineup(l: McLineup, o: McOutcome): number {
  let total = 0;

  const gkStarter = l.starters.find((id) => o.position(id) === 1);
  const benchGk = l.bench.find((id) => o.position(id) === 1);
  const outfield = l.starters.filter((id) => o.position(id) !== 1);

  if (gkStarter !== undefined) {
    if (o.played(gkStarter)) total += o.pts(gkStarter);
    else if (benchGk !== undefined && o.played(benchGk)) total += o.pts(benchGk);
  }

  const counts: Record<number, number> = { 2: 0, 3: 0, 4: 0 };
  const missing: number[] = [];
  for (const id of outfield) {
    counts[o.position(id)] = (counts[o.position(id)] ?? 0) + 1;
    if (o.played(id)) total += o.pts(id);
    else missing.push(id);
  }

  if (missing.length > 0) {
    for (const sub of l.bench) {
      if (missing.length === 0) break;
      const subPos = o.position(sub);
      if (subPos === 1 || !o.played(sub)) continue;
      for (let m = 0; m < missing.length; m++) {
        const outPos = o.position(missing[m]);
        const after = { ...counts };
        after[outPos] -= 1;
        after[subPos] += 1;
        if (after[2] >= 3 && after[3] >= 2 && after[4] >= 1) {
          counts[outPos] -= 1;
          counts[subPos] += 1;
          missing.splice(m, 1);
          total += o.pts(sub);
          break;
        }
      }
    }
  }

  if (o.played(l.captainId)) total += o.pts(l.captainId);
  else if (o.played(l.viceId)) total += o.pts(l.viceId);

  return total;
}

/* -------------------------------- summaries -------------------------------- */

function sortedCopy(a: ArrayLike<number>): Float64Array {
  const out = Float64Array.from(a as ArrayLike<number>);
  out.sort();
  return out;
}

function quantile(sorted: Float64Array, q: number): number {
  const n = sorted.length;
  if (n === 0) return 0;
  return sorted[Math.min(n - 1, Math.max(0, Math.floor(q * n)))];
}

const r2 = (x: number) => Math.round(x * 100) / 100;

/** Pull a raw simulated probability toward 50% by the measured reliability slope. */
export function calibrateProbability(p: number, slope: number = MC_CAL.probSlope): number {
  const c = Math.min(0.995, Math.max(0.005, p));
  const z = Math.log(c / (1 - c)) * slope;
  return 1 / (1 + Math.exp(-z));
}

function band(gw: number, a: ArrayLike<number>): McBand {
  const s = sortedCopy(a);
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum += a[i];
  return { gw, mean: r2(sum / a.length), p10: r2(quantile(s, 0.1)), p90: r2(quantile(s, 0.9)) };
}

/* --------------------------------- main run --------------------------------- */

export function runMonteCarlo(opts: McOptions): MonteCarloSummary {
  const draws = opts.draws ?? MC_DRAWS;
  const { gws, paths, playerAt, seed } = opts;

  const playerCache = new Map<string, { pts: Float32Array; played: Uint8Array }>();
  const noiseCache = new Map<string, McTeamNoise>();
  const infoCache = new Map<string, McPlayerGw | null>();

  const info = (pid: number, gw: number): McPlayerGw | null => {
    const key = `${pid}:${gw}`;
    if (!infoCache.has(key)) infoCache.set(key, playerAt(pid, gw));
    return infoCache.get(key) ?? null;
  };

  const teamNoise = (team: number, gw: number, fixtures: number): McTeamNoise => {
    const key = `${team}:${gw}:${fixtures}`;
    let n = noiseCache.get(key);
    if (!n) {
      n = makeTeamNoise(seed, team, gw, draws, fixtures);
      noiseCache.set(key, n);
    }
    return n;
  };

  const player = (pid: number, gw: number) => {
    const key = `${pid}:${gw}`;
    let d = playerCache.get(key);
    if (!d) {
      const p = info(pid, gw);
      d = samplePlayerGw(p, p ? teamNoise(p.team, gw, p.fixtures) : null, draws, mixSeed(seed, pid, gw, 3));
      playerCache.set(key, d);
    }
    return d;
  };

  // Per path and gameweek: simulated points of the lineup, draw by draw.
  const perGw = new Map<string, Float64Array[]>(); // path id -> [gw index] -> draws
  const totals = new Map<string, Float64Array>();

  for (const path of paths) {
    const series: Float64Array[] = [];
    const total = new Float64Array(draws).fill(-path.hitCost);
    for (const gw of gws) {
      const arr = new Float64Array(draws);
      const lineup = path.lineupAt(gw);
      if (lineup) {
        const ids = [...lineup.starters, ...lineup.bench];
        const sims = new Map(ids.map((id) => [id, player(id, gw)]));
        const pos = new Map(ids.map((id) => [id, info(id, gw)?.position ?? 0]));
        for (let i = 0; i < draws; i++) {
          arr[i] = scoreLineup(lineup, {
            pts: (id) => sims.get(id)?.pts[i] ?? 0,
            played: (id) => (sims.get(id)?.played[i] ?? 0) === 1,
            position: (id) => pos.get(id) ?? 0,
          });
          total[i] += arr[i];
        }
      }
      series.push(arr);
    }
    perGw.set(path.id, series);
    totals.set(path.id, total);
  }

  const hold = totals.get(opts.holdId);
  const holdSeries = perGw.get(opts.holdId);

  const summaries: McPathSummary[] = paths.map((path) => {
    const total = totals.get(path.id) as Float64Array;
    const sorted = sortedCopy(total);
    let sum = 0;
    for (let i = 0; i < draws; i++) sum += total[i];
    const mean = sum / draws;
    let sq = 0;
    for (let i = 0; i < draws; i++) sq += (total[i] - mean) ** 2;

    let deltaMean: number | null = null;
    let deltaP10: number | null = null;
    let deltaP90: number | null = null;
    let probBeatsHold: number | null = null;
    let probBeatsHoldRaw: number | null = null;
    let cumDelta: McBand[] | null = null;

    if (path.id !== opts.holdId && hold && holdSeries) {
      const delta = new Float64Array(draws);
      let wins = 0;
      for (let i = 0; i < draws; i++) {
        delta[i] = total[i] - hold[i];
        if (delta[i] > 1e-9) wins += 1;
        else if (Math.abs(delta[i]) <= 1e-9) wins += 0.5;
      }
      const ds = sortedCopy(delta);
      deltaMean = r2(delta.reduce((a, b) => a + b, 0) / draws);
      deltaP10 = r2(quantile(ds, 0.1));
      deltaP90 = r2(quantile(ds, 0.9));
      probBeatsHoldRaw = Math.round((wins / draws) * 1000) / 1000;
      probBeatsHold = Math.round(calibrateProbability(wins / draws) * 1000) / 1000;

      const mine = perGw.get(path.id) as Float64Array[];
      const running = new Float64Array(draws).fill(-path.hitCost);
      cumDelta = gws.map((gw, j) => {
        for (let i = 0; i < draws; i++) running[i] += mine[j][i] - holdSeries[j][i];
        return band(gw, running);
      });
    }

    return {
      id: path.id,
      label: path.label,
      hitCost: path.hitCost,
      mean: r2(mean),
      median: r2(quantile(sorted, 0.5)),
      sd: r2(Math.sqrt(sq / draws)),
      p10: r2(quantile(sorted, 0.1)),
      p25: r2(quantile(sorted, 0.25)),
      p75: r2(quantile(sorted, 0.75)),
      p90: r2(quantile(sorted, 0.9)),
      deltaMean,
      deltaP10,
      deltaP90,
      probBeatsHold,
      probBeatsHoldRaw,
      perGw: gws.map((gw, j) => band(gw, (perGw.get(path.id) as Float64Array[])[j])),
      cumDelta,
    };
  });

  // Captain risk for the first gameweek, on the recommended path's lineup.
  const captains: McCaptainRisk[] = [];
  const recPath = paths.find((p) => p.id === opts.recommendedId) ?? paths[0];
  const firstGw = gws[0];
  const lu = recPath?.lineupAt(firstGw);
  if (lu) {
    const ranked = [...lu.starters]
      .filter((id) => (info(id, firstGw)?.position ?? 0) !== 1)
      .sort((a, b) => (info(b, firstGw)?.mean ?? 0) - (info(a, firstGw)?.mean ?? 0))
      .slice(0, 4);
    const pick = player(lu.captainId, firstGw).pts;
    for (const id of ranked) {
      const pts = player(id, firstGw).pts;
      const s = sortedCopy(pts);
      let sum = 0, blank = 0, haul = 0, beats = 0;
      for (let i = 0; i < draws; i++) {
        sum += pts[i];
        if (pts[i] <= 2) blank += 1;
        if (pts[i] >= 9) haul += 1;
        if (pts[i] > pick[i]) beats += 1;
      }
      captains.push({
        id,
        mean: r2(sum / draws),
        p10: r2(quantile(s, 0.1)),
        p90: r2(quantile(s, 0.9)),
        pBlank: Math.round((blank / draws) * 1000) / 1000,
        pHaul: Math.round((haul / draws) * 1000) / 1000,
        pBeatsPick: id === lu.captainId ? null : Math.round((beats / draws) * 1000) / 1000,
        isPick: id === lu.captainId,
      });
    }
  }

  return {
    draws,
    horizon: gws.length,
    gws,
    seed,
    recommendedPathId: opts.recommendedId,
    paths: summaries,
    captains,
    assumptions: [
      "Each player's minutes use the model's own probabilities, clean sheets come from a goals-conceded draw shared by a team's defenders, cards use the model's rate, and other points arrive as random events. The spread was calibrated on completed gameweeks.",
      "Teammates share a team-and-gameweek factor, so a strong attacking day lifts several of your players together.",
      "Lineups are picked in advance from expected points, then scored with automatic substitutions and the vice-captain fallback.",
      "Every strategy sees the same simulated results for the players they share, so the comparison between them is precise.",
    ],
  };
}
