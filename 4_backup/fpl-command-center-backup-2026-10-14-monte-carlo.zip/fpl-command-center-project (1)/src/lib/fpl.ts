import { db } from "@/db";
import { apiCache } from "@/db/schema";
import { eq } from "drizzle-orm";

const BASE = "https://fantasy.premierleague.com/api";
const USER_AGENT =
  "FPL-Vortex/1.0 (analytics dashboard; contact: local)";

// ---- rate limiting & in-flight deduplication ----
let queue: Promise<unknown> = Promise.resolve();
let lastRequestAt = 0;
const MIN_GAP_MS = 250;
const inFlight = new Map<string, Promise<unknown>>();

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function throttledFetch(url: string): Promise<Response> {
  const run = async () => {
    const wait = lastRequestAt + MIN_GAP_MS - Date.now();
    if (wait > 0) await sleep(wait);
    lastRequestAt = Date.now();
    return fetch(url, {
      headers: { "User-Agent": USER_AGENT, Accept: "application/json" },
      cache: "no-store",
    });
  };
  const next = queue.then(run, run);
  queue = next.catch((err) => {
    console.error("[FPL Vortex throttledFetch queue error]", url, err);
    return undefined;
  });
  return next;
}

export class FplError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function fetchWithRetry(path: string, attempts = 3): Promise<unknown> {
  const url = `${BASE}/${path}`;
  let lastError: unknown = null;
  for (let i = 0; i < attempts; i++) {
    try {
      const res = await throttledFetch(url);
      if (res.status === 404) {
        throw new FplError(`Not found: ${path}`, 404);
      }
      if (!res.ok) {
        throw new FplError(`FPL API ${res.status} for ${path}`, res.status);
      }
      return await res.json();
    } catch (err) {
      lastError = err;
      if (err instanceof FplError && err.status === 404) throw err;
      console.error(
        `[FPL Vortex fetchWithRetry attempt ${i + 1}/${attempts} failed for ${path}]`,
        err instanceof Error ? err.message : err,
      );
      if (i < attempts - 1) await sleep(500 * Math.pow(2, i));
    }
  }
  throw lastError instanceof Error
    ? lastError
    : new FplError("FPL API unreachable", 502);
}

async function readCache(key: string) {
  try {
    const rows = await db
      .select()
      .from(apiCache)
      .where(eq(apiCache.key, key))
      .limit(1);
    return rows[0] ?? null;
  } catch (err) {
    console.error(`[FPL Vortex readCache error for ${key}]`, err);
    return null;
  }
}

async function writeCache(key: string, data: unknown) {
  try {
    await db
      .insert(apiCache)
      .values({ key, data, fetchedAt: new Date() })
      .onConflictDoUpdate({
        target: apiCache.key,
        set: { data, fetchedAt: new Date() },
      });
  } catch (err) {
    console.error(`[FPL Vortex writeCache error for ${key}]`, err);
  }
}

/** Generic cache accessors for non-FPL data (press summaries, solver cache, etc). */
export async function cacheGet<T>(
  key: string,
  maxAgeSeconds: number,
): Promise<T | null> {
  const row = await readCache(key);
  if (row && Date.now() - row.fetchedAt.getTime() < maxAgeSeconds * 1000) {
    return row.data as T;
  }
  return null;
}

export async function cacheSet(key: string, data: unknown): Promise<void> {
  await writeCache(key, data);
}

/**
 * Fetch an FPL API path with DB-backed caching.
 * Returns cached data if fresh; on upstream failure falls back to stale cache.
 */
export async function fplFetch<T>(path: string, ttlSeconds: number): Promise<T> {
  const cached = await readCache(path);
  if (cached && Date.now() - cached.fetchedAt.getTime() < ttlSeconds * 1000) {
    return cached.data as T;
  }
  const existing = inFlight.get(path);
  if (existing) {
    return (await existing) as T;
  }
  const promise = (async () => {
    try {
      const data = await fetchWithRetry(path);
      await writeCache(path, data);
      return data as T;
    } catch (err) {
      console.error(`[FPL Vortex fplFetch error for ${path}]`, err);
      if (cached && !(err instanceof FplError && err.status === 404)) {
        return cached.data as T;
      }
      throw err;
    } finally {
      inFlight.delete(path);
    }
  })();
  inFlight.set(path, promise);
  return await promise;
}
