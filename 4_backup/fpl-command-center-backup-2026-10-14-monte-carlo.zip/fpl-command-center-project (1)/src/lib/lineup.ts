import type { SlimElement } from "./types";

export interface PredictedPlayer {
  element: SlimElement;
  confidence: number; // 0..100 chance of starting
}

export interface PredictedXI {
  teamId: number;
  players: PredictedPlayer[]; // 11, ordered GK -> FWD
  formation: string;
  source: "model" | "confirmed";
}

/**
 * Pluggable lineup provider interface. The default is our own model.
 * A confirmed-XI provider (e.g. a lineup API) can be plugged in here later:
 * it should return null when no confirmed lineup is published yet, in which
 * case the UI falls back to the model prediction.
 */
export interface LineupProvider {
  getLineup(teamId: number, elements: SlimElement[]): PredictedXI | null;
}

/** Start likelihood from recent starts share, minutes share and fitness flags. */
export function startConfidence(el: SlimElement, gamesPlayed: number): number {
  const gp = Math.max(gamesPlayed, 1);
  const startShare = Math.min(el.starts / gp, 1);
  const minuteShare = Math.min(el.minutes / (gp * 90), 1);
  let conf = 100 * (0.65 * startShare + 0.35 * minuteShare);
  // fitness / availability flags
  if (el.status === "i" || el.status === "s" || el.status === "u" || el.status === "n") {
    conf = Math.min(conf, 5);
  } else if (el.status === "d") {
    const chance = el.chance_of_playing_next_round ?? 50;
    conf = conf * (chance / 100);
  }
  return Math.round(Math.max(0, Math.min(conf, 99)));
}

const MODEL_LIMITS = { 1: [1, 1], 2: [3, 5], 3: [2, 5], 4: [1, 3] } as const;

/** Greedy best-XI: highest confidence while respecting formation limits. */
export const modelProvider: LineupProvider = {
  getLineup(teamId, elements) {
    const squad = elements
      .filter((e) => e.team === teamId && e.element_type >= 1 && e.element_type <= 4)
      .map((e) => ({ element: e, confidence: 0 }));
    if (squad.length < 11) return null;

    const gamesPlayed = Math.max(
      ...elements.filter((e) => e.team === teamId).map((e) => e.starts),
      1,
    );
    squad.forEach((p) => {
      p.confidence = startConfidence(p.element, gamesPlayed);
    });
    squad.sort((a, b) => b.confidence - a.confidence);

    const picked: PredictedPlayer[] = [];
    const count: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0 };

    // Pass 1: fill minimums per position with best candidates
    for (const type of [1, 2, 3, 4] as const) {
      const min = MODEL_LIMITS[type][0];
      for (const p of squad) {
        if (count[type] >= min) break;
        if (p.element.element_type === type && !picked.includes(p)) {
          picked.push(p);
          count[type]++;
        }
      }
    }
    // Pass 2: fill to 11 with best remaining under maximums
    for (const p of squad) {
      if (picked.length >= 11) break;
      const t = p.element.element_type as 1 | 2 | 3 | 4;
      if (!picked.includes(p) && count[t] < MODEL_LIMITS[t][1]) {
        picked.push(p);
        count[t]++;
      }
    }
    if (picked.length < 11) return null;
    picked.sort(
      (a, b) =>
        a.element.element_type - b.element.element_type ||
        b.confidence - a.confidence,
    );
    return {
      teamId,
      players: picked,
      formation: `${count[2]}-${count[3]}-${count[4]}`,
      source: "model",
    };
  },
};

/**
 * Confirmed lineup provider stub — returns null (nothing published).
 * Swap in a real provider (API-Football, Fotmob scrape, etc.) here.
 */
export const confirmedProvider: LineupProvider = {
  getLineup() {
    return null;
  },
};

export function getBestLineup(
  teamId: number,
  elements: SlimElement[],
): PredictedXI | null {
  return (
    confirmedProvider.getLineup(teamId, elements) ??
    modelProvider.getLineup(teamId, elements)
  );
}

export interface SolvedLineup {
  starters: number[];
  bench: number[];
  captainId: number;
  viceId: number;
  xiXPts: number;
  captainXPts: number;
  benchXPts: number;
  totalXPts: number;
  formation: string;
}

/** Pure client-safe valid XI + Captain + Bench solver for a 15-man squad. */
export function solveLineupTS(
  squadIds: number[],
  elementsMap: Map<number, SlimElement>,
  gwXPts: Record<number, number>,
  benchBoost = false,
  tripleCaptain = false,
): SolvedLineup {
  const gks = squadIds
    .filter((id) => elementsMap.get(id)?.element_type === 1)
    .sort((a, b) => (gwXPts[b] ?? 0) - (gwXPts[a] ?? 0));
  const startGk = gks[0] ?? squadIds[0];
  const benchGk = gks[1] ?? startGk;

  const outfield = squadIds.filter((id) => {
    const t = elementsMap.get(id)?.element_type ?? 0;
    return t >= 2 && t <= 4;
  });

  const defs = outfield
    .filter((id) => elementsMap.get(id)?.element_type === 2)
    .sort((a, b) => (gwXPts[b] ?? 0) - (gwXPts[a] ?? 0));
  const mids = outfield
    .filter((id) => elementsMap.get(id)?.element_type === 3)
    .sort((a, b) => (gwXPts[b] ?? 0) - (gwXPts[a] ?? 0));
  const fwds = outfield
    .filter((id) => elementsMap.get(id)?.element_type === 4)
    .sort((a, b) => (gwXPts[b] ?? 0) - (gwXPts[a] ?? 0));

  let bestScore = -Infinity;
  let bestOut: number[] = [];
  let bestForm = "4-4-2";

  for (let d = 3; d <= Math.min(5, defs.length); d++) {
    for (let m = 2; m <= Math.min(5, mids.length); m++) {
      const f = 10 - d - m;
      if (f < 1 || f > Math.min(3, fwds.length)) continue;
      const chosen = [...defs.slice(0, d), ...mids.slice(0, m), ...fwds.slice(0, f)];
      const sc = chosen.reduce((s, id) => s + (gwXPts[id] ?? 0), 0);
      if (sc > bestScore) {
        bestScore = sc;
        bestOut = chosen;
        bestForm = `${d}-${m}-${f}`;
      }
    }
  }

  const starters = [startGk, ...bestOut];
  const benchOut = outfield
    .filter((id) => !bestOut.includes(id))
    .sort((a, b) => (gwXPts[b] ?? 0) - (gwXPts[a] ?? 0));
  const bench = [benchGk, ...benchOut];

  const byXp = [...starters].sort((a, b) => (gwXPts[b] ?? 0) - (gwXPts[a] ?? 0));
  const captainId = byXp[0] ?? startGk;
  const viceId = byXp[1] ?? captainId;

  const xiXPts = Math.round(starters.reduce((s, id) => s + (gwXPts[id] ?? 0), 0) * 100) / 100;
  const benchXPts = Math.round(bench.reduce((s, id) => s + (gwXPts[id] ?? 0), 0) * 100) / 100;
  const captainXPts = Math.round((gwXPts[captainId] ?? 0) * (tripleCaptain ? 2 : 1) * 100) / 100;
  const totalXPts =
    Math.round((xiXPts + captainXPts + (benchBoost ? benchXPts : 0)) * 100) / 100;

  return {
    starters,
    bench,
    captainId,
    viceId,
    xiXPts,
    captainXPts,
    benchXPts,
    totalXPts,
    formation: bestForm,
  };
}
