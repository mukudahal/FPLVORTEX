// Pure planning logic for the /plan dashboard. No React, no I/O — unit-testable.

import type {
  PlanFixture,
  PlanPlayer,
  PlanResponse,
  PlanTransfer,
} from "./planTypes";

export type TransferMap = Record<number, PlanTransfer[]>;

export interface FxCell {
  opp: number;
  home: boolean;
  diff: number;
}

export const MAX_FT = 5;
export const HIT_COST = 4;
export const MAX_PER_CLUB = 3;

/* ------------------------------------------------------------------ */
/* fixtures                                                           */
/* ------------------------------------------------------------------ */

export function buildFxMap(fixtures: PlanFixture[]): Map<string, FxCell[]> {
  const m = new Map<string, FxCell[]>();
  const push = (key: string, cell: FxCell) => {
    const arr = m.get(key);
    if (arr) arr.push(cell);
    else m.set(key, [cell]);
  };
  for (const f of fixtures) {
    push(`${f.h}:${f.gw}`, { opp: f.a, home: true, diff: f.hd });
    push(`${f.a}:${f.gw}`, { opp: f.h, home: false, diff: f.ad });
  }
  return m;
}

export function cellsFor(
  fxMap: Map<string, FxCell[]>,
  team: number,
  gw: number,
): FxCell[] {
  return fxMap.get(`${team}:${gw}`) ?? [];
}

/* ------------------------------------------------------------------ */
/* lineup                                                             */
/* ------------------------------------------------------------------ */

export interface XIResult {
  starters: number[]; // [gk, ...outfield]
  bench: number[]; // [gk, ...outfield by xP]
  captain: number | undefined;
  vice: number | undefined;
  formation: string;
  xi: number;
  capXp: number;
  total: number; // xi + captain bonus
}

/** Best valid XI (+ captain/vice + ordered bench) for any set of players. */
export function bestXI(
  ids: number[],
  typeOf: (id: number) => number,
  xpOf: (id: number) => number,
): XIResult {
  const byType = (t: number) =>
    ids.filter((i) => typeOf(i) === t).sort((a, b) => xpOf(b) - xpOf(a));
  const gks = byType(1);
  const defs = byType(2);
  const mids = byType(3);
  const fwds = byType(4);

  let bestScore = -Infinity;
  let bestOut: number[] = [];
  let bestForm = "4-4-2";
  for (let d = 3; d <= Math.min(5, defs.length); d++) {
    for (let m = 2; m <= Math.min(5, mids.length); m++) {
      const f = 10 - d - m;
      if (f < 1 || f > Math.min(3, fwds.length)) continue;
      const chosen = [
        ...defs.slice(0, d),
        ...mids.slice(0, m),
        ...fwds.slice(0, f),
      ];
      const sc = chosen.reduce((s, id) => s + xpOf(id), 0);
      if (sc > bestScore) {
        bestScore = sc;
        bestOut = chosen;
        bestForm = `${d}-${m}-${f}`;
      }
    }
  }

  const starters = gks.length > 0 ? [gks[0], ...bestOut] : bestOut;
  const chosenSet = new Set(bestOut);
  const benchOut = [...defs, ...mids, ...fwds]
    .filter((id) => !chosenSet.has(id))
    .sort((a, b) => xpOf(b) - xpOf(a));
  const bench = [...(gks.length > 1 ? [gks[1]] : []), ...benchOut];

  const ranked = [...starters].sort((a, b) => xpOf(b) - xpOf(a));
  const captain = ranked[0] as number | undefined;
  const vice = ranked[1] as number | undefined;
  const xi = starters.reduce((s, id) => s + xpOf(id), 0);
  const capXp = captain !== undefined ? xpOf(captain) : 0;
  return { starters, bench, captain, vice, formation: bestForm, xi, capXp, total: xi + capXp };
}

/* ------------------------------------------------------------------ */
/* planning context                                                   */
/* ------------------------------------------------------------------ */

export interface PlanCtx {
  players: Map<number, PlanPlayer>;
  gws: number[];
  baseSquad: number[]; // 15 ids ordered by pick position
  bank0: number; // tenths
  sell0: Record<number, number>; // selling prices of the real squad
  freeNow: number;
}

export function makeCtx(data: PlanResponse): PlanCtx {
  const players = new Map<number, PlanPlayer>();
  data.players.forEach((p) => players.set(p.id, p));
  return {
    players,
    gws: data.gws,
    baseSquad: [...data.picks]
      .sort((a, b) => a.position - b.position)
      .map((p) => p.element),
    bank0: data.bank,
    sell0: data.sellingPrices,
    freeNow: data.freeTransfers,
  };
}

export const xpAt = (ctx: PlanCtx, id: number, idx: number): number =>
  ctx.players.get(id)?.xp[idx] ?? 0;

export const typeOf = (ctx: PlanCtx, id: number): number =>
  ctx.players.get(id)?.type ?? 0;

export function lineupAt(ctx: PlanCtx, squad: number[], idx: number): XIResult {
  return bestXI(
    squad,
    (id) => typeOf(ctx, id),
    (id) => xpAt(ctx, id, idx),
  );
}

/* ------------------------------------------------------------------ */
/* replaying transfers                                                */
/* ------------------------------------------------------------------ */

export interface GwLedger {
  gw: number;
  ftBefore: number;
  n: number; // transfers made this GW
  hit: number; // points cost
  ftAfter: number;
  bankAfter: number;
}

export interface ReplayState {
  squad: number[];
  bank: number;
  buy: Map<number, number>; // price paid for players bought inside the plan
  ledger: GwLedger[];
}

export function sellOf(ctx: PlanCtx, state: Pick<ReplayState, "buy">, id: number): number {
  return state.buy.get(id) ?? ctx.sell0[id] ?? ctx.players.get(id)?.cost ?? 0;
}

/** Apply transfers gameweek by gameweek up to (and including) `uptoGw`. */
export function replay(ctx: PlanCtx, transfers: TransferMap, uptoGw: number): ReplayState {
  const squad = [...ctx.baseSquad];
  const buy = new Map<number, number>();
  let bank = ctx.bank0;
  let ft = ctx.freeNow;
  const ledger: GwLedger[] = [];

  for (const gw of ctx.gws) {
    if (gw > uptoGw) break;
    const list = transfers[gw] ?? [];
    let n = 0;
    for (const t of list) {
      const at = squad.indexOf(t.out);
      const incoming = ctx.players.get(t.in);
      if (at === -1 || !incoming) continue;
      bank += sellOf(ctx, { buy }, t.out) - incoming.cost;
      squad[at] = t.in;
      buy.set(t.in, incoming.cost);
      n++;
    }
    const hit = Math.max(0, n - ft) * HIT_COST;
    const ftAfter = Math.min(MAX_FT, Math.max(0, ft - n) + 1);
    ledger.push({ gw, ftBefore: ft, n, hit, ftAfter, bankAfter: bank });
    ft = ftAfter;
  }
  return { squad, bank, buy, ledger };
}

/** Reason a transfer is not allowed, or null when it is fine. */
export function validateTransfer(
  ctx: PlanCtx,
  state: ReplayState,
  outId: number,
  inId: number,
): string | null {
  const out = ctx.players.get(outId);
  const inc = ctx.players.get(inId);
  if (!out || !inc) return "Unknown player.";
  if (!state.squad.includes(outId)) return `${out.name} is not in your squad.`;
  if (state.squad.includes(inId)) return `${inc.name} is already in your squad.`;
  if (out.type !== inc.type) return "Replacement must play the same position.";
  const clubCount = state.squad.reduce((c, id) => {
    if (id === outId) return c;
    return c + (ctx.players.get(id)?.team === inc.team ? 1 : 0);
  }, 0);
  if (clubCount >= MAX_PER_CLUB) return "Max 3 players from one club.";
  const left = state.bank + sellOf(ctx, state, outId) - inc.cost;
  if (left < 0) return `Over budget by £${(-left / 10).toFixed(1)}m.`;
  return null;
}

/** Replay transfers, dropping any that are no longer valid. */
export function sanitize(ctx: PlanCtx, transfers: TransferMap): TransferMap {
  const clean: TransferMap = {};
  for (const gw of ctx.gws) {
    const wanted = transfers[gw] ?? [];
    if (wanted.length === 0) continue;
    const kept: PlanTransfer[] = [];
    for (const t of wanted) {
      const trial: TransferMap = { ...clean, [gw]: [...kept] };
      const state = replay(ctx, trial, gw);
      if (validateTransfer(ctx, state, t.out, t.in) === null) kept.push(t);
    }
    if (kept.length > 0) clean[gw] = kept;
  }
  return clean;
}

/* ------------------------------------------------------------------ */
/* ranking replacements & auto-plan                                   */
/* ------------------------------------------------------------------ */

export function horizonXP(
  ctx: PlanCtx,
  squad: number[],
  fromIdx: number,
  horizon: number,
): number {
  let total = 0;
  const end = Math.min(ctx.gws.length, fromIdx + horizon);
  for (let i = fromIdx; i < end; i++) total += lineupAt(ctx, squad, i).total;
  return total;
}

export interface Ranked {
  id: number;
  gain: number; // horizon xP gain vs keeping the outgoing player
}

/** Every legal replacement for `outId`, best first. */
export function rankReplacements(
  ctx: PlanCtx,
  state: ReplayState,
  outId: number,
  fromIdx: number,
  horizon: number,
  limit = Infinity,
): Ranked[] {
  const out = ctx.players.get(outId);
  if (!out) return [];
  const base = horizonXP(ctx, state.squad, fromIdx, horizon);
  const at = state.squad.indexOf(outId);
  const ranked: Ranked[] = [];
  for (const cand of ctx.players.values()) {
    if (cand.type !== out.type || cand.id === outId) continue;
    if (validateTransfer(ctx, state, outId, cand.id) !== null) continue;
    const next = [...state.squad];
    next[at] = cand.id;
    ranked.push({ id: cand.id, gain: horizonXP(ctx, next, fromIdx, horizon) - base });
  }
  ranked.sort((a, b) => b.gain - a.gain);
  return ranked.slice(0, limit);
}

export interface AutoStep {
  gw: number;
  out: number;
  in: number;
  gain: number;
  hit: number;
}

export interface AutoOptions {
  horizon: number;
  allowHits: boolean;
  fromIdx: number;
  maxPerGw?: number;
  minGainFree?: number;
  minGainHit?: number;
}

/**
 * Greedy planner: at each gameweek, take the single best swap while its
 * horizon gain beats the roll threshold (free transfer) or hit threshold.
 */
export function autoPlan(
  ctx: PlanCtx,
  existing: TransferMap,
  opts: AutoOptions,
): { transfers: TransferMap; steps: AutoStep[] } {
  const maxPerGw = opts.maxPerGw ?? 2;
  const minFree = opts.minGainFree ?? 1.5;
  const minHit = opts.minGainHit ?? HIT_COST + 2;

  const tm: TransferMap = {};
  for (const gw of ctx.gws.slice(0, opts.fromIdx)) {
    if (existing[gw]) tm[gw] = [...existing[gw]];
  }
  const steps: AutoStep[] = [];

  for (let idx = opts.fromIdx; idx < ctx.gws.length; idx++) {
    const gw = ctx.gws[idx];
    for (let k = 0; k < maxPerGw; k++) {
      const state = replay(ctx, tm, gw);
      const row = state.ledger[state.ledger.length - 1];
      const nowN = tm[gw]?.length ?? 0;
      const isHit = nowN + 1 > row.ftBefore;
      if (isHit && !opts.allowHits) break;

      const base = horizonXP(ctx, state.squad, idx, opts.horizon);
      // shortlist: top candidates per position by horizon xP
      const pool = new Map<number, number[]>();
      for (const t of [1, 2, 3, 4]) {
        const list = [...ctx.players.values()]
          .filter((p) => p.type === t && !state.squad.includes(p.id))
          .map((p) => ({
            id: p.id,
            s: p.xp.slice(idx, idx + opts.horizon).reduce((a, b) => a + b, 0),
          }))
          .sort((a, b) => b.s - a.s)
          .slice(0, 25)
          .map((x) => x.id);
        pool.set(t, list);
      }

      let best: { out: number; inn: number; gain: number } | null = null;
      for (const outId of state.squad) {
        const t = typeOf(ctx, outId);
        const at = state.squad.indexOf(outId);
        for (const cId of pool.get(t) ?? []) {
          if (validateTransfer(ctx, state, outId, cId) !== null) continue;
          const next = [...state.squad];
          next[at] = cId;
          const gain = horizonXP(ctx, next, idx, opts.horizon) - base;
          if (!best || gain > best.gain) best = { out: outId, inn: cId, gain };
        }
      }
      if (!best) break;
      const need = isHit ? minHit : minFree;
      if (best.gain < need) break;
      tm[gw] = [...(tm[gw] ?? []), { out: best.out, in: best.inn }];
      steps.push({ gw, out: best.out, in: best.inn, gain: best.gain, hit: isHit ? HIT_COST : 0 });
    }
  }
  return { transfers: tm, steps };
}

/* ------------------------------------------------------------------ */
/* summary helpers                                                    */
/* ------------------------------------------------------------------ */

export interface GwSummary {
  fixturesLineup: number;
  fixturesSquad: number;
  dgwLineup: number;
  dgwSquad: number;
  blankLineup: number;
  blankSquad: number;
  fdrCounts: number[]; // index 0..4 = difficulty 1..5, over every squad fixture
}

export function summarise(
  ctx: PlanCtx,
  fxMap: Map<string, FxCell[]>,
  squad: number[],
  lineup: XIResult,
  gw: number,
): GwSummary {
  const start = new Set(lineup.starters);
  const out: GwSummary = {
    fixturesLineup: 0,
    fixturesSquad: 0,
    dgwLineup: 0,
    dgwSquad: 0,
    blankLineup: 0,
    blankSquad: 0,
    fdrCounts: [0, 0, 0, 0, 0],
  };
  for (const id of squad) {
    const p = ctx.players.get(id);
    if (!p) continue;
    const cells = cellsFor(fxMap, p.team, gw);
    const inXI = start.has(id);
    out.fixturesSquad += cells.length;
    if (inXI) out.fixturesLineup += cells.length;
    if (cells.length === 0) {
      out.blankSquad++;
      if (inXI) out.blankLineup++;
    }
    if (cells.length >= 2) {
      out.dgwSquad++;
      if (inXI) out.dgwLineup++;
    }
    for (const c of cells) {
      if (c.diff >= 1 && c.diff <= 5) out.fdrCounts[c.diff - 1]++;
    }
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* best single moves right now                                        */
/* ------------------------------------------------------------------ */

export interface Move {
  out: number;
  in: number;
  gain: number;
}

/** Best replacement for each squad player, sorted by horizon gain. */
export function topMoves(
  ctx: PlanCtx,
  state: ReplayState,
  idx: number,
  horizon: number,
  limit = 5,
): Move[] {
  const base = horizonXP(ctx, state.squad, idx, horizon);
  const pool = new Map<number, number[]>();
  for (const t of [1, 2, 3, 4]) {
    pool.set(
      t,
      [...ctx.players.values()]
        .filter((p) => p.type === t && !state.squad.includes(p.id))
        .map((p) => ({
          id: p.id,
          s: p.xp.slice(idx, idx + horizon).reduce((a, b) => a + b, 0),
        }))
        .sort((a, b) => b.s - a.s)
        .slice(0, 30)
        .map((x) => x.id),
    );
  }
  const moves: Move[] = [];
  for (const outId of state.squad) {
    const at = state.squad.indexOf(outId);
    let best: Move | null = null;
    for (const cId of pool.get(typeOf(ctx, outId)) ?? []) {
      if (validateTransfer(ctx, state, outId, cId) !== null) continue;
      const next = [...state.squad];
      next[at] = cId;
      const gain = horizonXP(ctx, next, idx, horizon) - base;
      if (!best || gain > best.gain) best = { out: outId, in: cId, gain };
    }
    if (best && best.gain > 0) moves.push(best);
  }
  return moves.sort((a, b) => b.gain - a.gain).slice(0, limit);
}
