import {
  boolean,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

// Generic cache for FPL API responses (key = API path).
export const apiCache = pgTable("api_cache", {
  key: text("key").primaryKey(),
  data: jsonb("data").notNull(),
  fetchedAt: timestamp("fetched_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// Managers (FPL entries) that have been viewed in this app.
export const managers = pgTable("managers", {
  id: integer("id").primaryKey(), // FPL entry id
  playerName: text("player_name").notNull().default(""),
  teamName: text("team_name").notNull().default(""),
  region: text("region").notNull().default(""),
  overallRank: integer("overall_rank"),
  totalPoints: integer("total_points"),
  viewCount: integer("view_count").notNull().default(1),
  lastViewedAt: timestamp("last_viewed_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// Periodic snapshots of player price/transfer state (Phase 3 momentum model).
export const priceSnapshots = pgTable("price_snapshots", {
  id: serial("id").primaryKey(),
  elementId: integer("element_id").notNull(),
  nowCost: integer("now_cost").notNull(),
  transfersInEvent: integer("transfers_in_event").notNull(),
  transfersOutEvent: integer("transfers_out_event").notNull(),
  selectedByPercent: real("selected_by_percent").notNull(),
  changePercent: real("change_percent"), // FPL's own progress metric if present
  takenAt: timestamp("taken_at", { withTimezone: true }).notNull().defaultNow(),
});

// Every price prediction we make + the real outcome, for running accuracy %.
export const pricePredictions = pgTable("price_predictions", {
  id: serial("id").primaryKey(),
  elementId: integer("element_id").notNull(),
  webName: text("web_name").notNull(),
  direction: text("direction").notNull(), // 'rise' | 'fall'
  probability: real("probability").notNull(), // 0..1 at prediction time
  priceAt: integer("price_at").notNull(), // now_cost when predicted
  predictedAt: timestamp("predicted_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  windowEnds: timestamp("window_ends", { withTimezone: true }).notNull(),
  outcome: text("outcome").notNull().default("pending"), // pending|correct|wrong
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
});

// Saved multi-GW plans (Phase 9). data holds the full plan JSON.
export const savedPlans = pgTable("saved_plans", {
  id: serial("id").primaryKey(),
  entryId: integer("entry_id").notNull(),
  name: text("name").notNull(),
  data: jsonb("data").notNull(),
  projectedPoints: real("projected_points").notNull().default(0),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// FotMob player ID mappings (Update 4: look up once, reuse forever, retry no_match every 7 days).
export const fotmobMappings = pgTable("fotmob_mappings", {
  fplPlayerCode: integer("fpl_player_code").primaryKey(),
  fotmobId: integer("fotmob_id"),
  matchedAt: timestamp("matched_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  status: text("status").notNull(), // 'matched' | 'no_match'
});

// Player image working source resolutions (Update 4 dev status tracking).
export const playerImageResolutions = pgTable("player_image_resolutions", {
  fplPlayerCode: integer("fpl_player_code").primaryKey(),
  source: text("source").notNull(), // 'fpl' | 'fotmob' | 'placeholder' (legacy rows may say 'shirt'; ignored)
  fotmobId: integer("fotmob_id"),
  resolvedAt: timestamp("resolved_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});
